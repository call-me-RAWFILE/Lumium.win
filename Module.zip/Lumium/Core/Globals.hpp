#pragma once
#include <queue>
#include <string>
#include <vector>
#include <lstate.h>
#include <functional>
#include <lstate.h>
#include <string>
#include <queue>
#include <functional>
#include <atomic>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <Windows.h>
#include "Main/Environment/Helper/LuauHelper.hpp"
#include <unordered_set>
#define lua_pushoclosure(L, C) setclvalue(L, L->top, C); incr_top(L)
#define lua_tomutclosure(L, idx) const_cast<Closure*>(reinterpret_cast<const Closure*>(lua_topointer(L, idx)))
inline uintptr_t MaxCapabilities = 0xFFFFFFFFFFFFFFFF;
#include "Main/Security/xorstr.hpp"
namespace SharedVariables
{
    inline uintptr_t LastDataModel;
    inline uintptr_t ScriptContext;
    inline lua_State* ExploitThread;
    inline lua_State* RobloxState;

    inline std::atomic<uint64_t> StateGeneration{ 0 };
    inline std::vector<std::string> ExecutionRequests;
    inline std::mutex ExecutionRequestsMutex;
    inline std::vector<std::string> TeleportQueue;
    inline std::mutex TeleportQueueMutex;

    inline std::queue<std::function<void()>> YieldQueue;
    inline std::mutex YieldQueueMutex;

    inline std::filesystem::path workspace_folder;
    inline std::filesystem::path autoexecute_folder;
    inline std::unordered_set<Closure*> ExecutorClosures;

    inline std::atomic_bool JobStepLocked{ true };
    inline std::mutex JobHookMutex;

    inline uintptr_t LastWaitingHybridScriptsJob = 0;
    inline uintptr_t* OriginalHybridJobVtable = nullptr;
    inline uintptr_t* HybridJobVtable = nullptr;
}

static LuaTable* getcurrenv(lua_State* L)
{
    if (L->ci == L->base_ci)
        return L->gt;
    else
        return curr_func(L)->env;
}

static LUAU_NOINLINE TValue* pseudo2addr(lua_State* L, int idx)
{
    api_check(L, lua_ispseudo(idx));
    switch (idx)
    {
    case LUA_REGISTRYINDEX:
        return registry(L);
    case LUA_ENVIRONINDEX:
    {
        sethvalue(L, &L->global->pseudotemp, getcurrenv(L));
        return &L->global->pseudotemp;
    }
    case LUA_GLOBALSINDEX:
    {
        sethvalue(L, &L->global->pseudotemp, L->gt);
        return &L->global->pseudotemp;
    }
    default:
    {
        Closure* func = curr_func(L);
        idx = LUA_GLOBALSINDEX - idx;
        return (idx <= func->nupvalues) ? &func->c.upvals[idx - 1] : cast_to(TValue*, luaO_nilobject);
    }
    }
}


static LUAU_FORCEINLINE TValue* index2addr(lua_State* L, int idx)
{
    if (idx > 0)
    {
        TValue* o = L->base + (idx - 1);
        api_check(L, idx <= L->ci->top - L->base);
        if (o >= L->top)
            return cast_to(TValue*, luaO_nilobject);
        else
            return o;
    }
    else if (idx > LUA_REGISTRYINDEX)
    {
        api_check(L, idx != 0 && -idx <= L->top - L->base);
        return L->top + idx;
    }
    else
    {
        return pseudo2addr(L, idx);
    }
}
