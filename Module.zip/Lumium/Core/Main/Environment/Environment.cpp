#include "Environment.hpp"
#include <Environment/Unsafe.hpp>
#include <auto/auto.hpp>
#include <Environment/Libraries/Main/Htpp/Http.hpp>
#include <Environment/Libraries/Cache/Cache.hpp>
#include <Environment/Libraries/Main/Crypt/Crypt.hpp>
#include <Environment/Libraries/Main/Input/Input.hpp>
#include <Environment/Libraries/Debug/Debug.hpp>
#include <Environment/Libraries/Main/Script/Script.hpp>
#include <Environment/Libraries/Closures/Closures.hpp>
#include <Environment/Libraries/Misc/Instance.hpp>
#include <Environment/Libraries/WebSocket/Websocket.hpp>
#include <Environment/Libraries/Main/MetaTable/Metatable.hpp>
#include <Environment/Libraries/Filesystem/Filesystem.hpp>
#include <Environment/Libraries/Misc/Miscellaneous.hpp>
#include <Environment/Libraries/Signal/Signals.hpp>
#include <Environment/Libraries/Main/Script/Reflection.hpp>
#include <Environment/Libraries/Other/Regex/Regex.hpp>
#include <Environment/Libraries/Filesystem/FileDialog.hpp>
#include <Environment/Libraries/Other/Actor/Actor.hpp>
#include <Environment/Libraries/Other/Raknet/raknet.hpp>
#include <Roblox/FFlags.hpp>
#include <iostream>
#include <random>

lua_CFunction OriginalIndex;
lua_CFunction OriginalNamecall;
lua_CFunction OriginalNewindex;
namespace Environment {
    std::vector<Closure*> function_array;
}

static bool ContainsEmoji(const std::string& str)
{
    for (size_t i = 0; i < str.size(); i++)
    {
        unsigned char c = (unsigned char)str[i];
        if (c == 0xF0 && i + 3 < str.size())
        {
            unsigned char n1 = (unsigned char)str[i + 1];
            unsigned char n2 = (unsigned char)str[i + 2];
            unsigned char n3 = (unsigned char)str[i + 3];
            if (n1 >= 0x90 && n1 <= 0x9F && n2 >= 0x80 && n2 <= 0xBF && n3 >= 0x80 && n3 <= 0xBF)
                return true;
        }
    }
    return false;
}

int IndexHook(lua_State* L)

{
    if (L->userdata->capabilities == MaxCapabilities && L->userdata->script.expired())
    {
        std::string Key = lua_isstring(L, 2) ? lua_tostring(L, 2) : "";

        if (ContainsEmoji(Key))
        {
            luaL_error(L, OBF("Blocked: vulnerable character detected"));
            return 0;
        }

        for (const char* Function : UnsafeFunction)
        {
            if (Key == Function)
            {
                luaL_error(L, OBF("Function '%s' has been blocked for security reasons"), Function);
                return 0;
            }
        }

        if (Key == OBF("HttpGet") || Key == OBF("HttpGetAsync"))
        {
            lua_pushcclosure(L, Http::HttpGet, nullptr, NULL);
            return 1;
        }
        else if (Key == OBF("HttpPost") || Key == OBF("HttpPostAsync"))
        {
            luaL_error(L, OBF("HttpPost has been blocked for security reasons"));
            return 0;
        }
        else if (Key == OBF("GetObjects"))
        {
            lua_pushcclosure(L, Miscellaneous::GetObjects, nullptr, NULL);
            return 1;
        }
    }

    return OriginalIndex(L);
};

int NamecallHook(lua_State* L)
{
    if (L->userdata->capabilities == MaxCapabilities && L->userdata->script.expired())
    {
        std::string Key = L->namecall->data;

        if (ContainsEmoji(Key))
        {
            luaL_error(L, OBF("Blocked: vulnerable character detected"));
            return 0;
        }

        for (const char* Function : UnsafeFunction)
        {
            if (Key == Function)
            {
                luaL_error(L, OBF("Function '%s' has been blocked for security reasons"), Function);
                return 0;
            }
        }

        if (Key == OBF("HttpGet") || Key == OBF("HttpGetAsync"))
        {
            return Http::HttpGet(L);
        }
        else if (Key == OBF("HttpPost") || Key == OBF("HttpPostAsync"))
        {
            luaL_error(L, OBF("HttpPost has been blocked for security reasons"));
            return 0;
        }
        else if (Key == OBF("GetObjects"))
        {
            return Miscellaneous::GetObjects(L);
        }
    }

    return OriginalNamecall(L);
};

int NewindexHook(lua_State* L)
{
    if (lua_type(L, 1) == LUA_TUSERDATA && lua_type(L, 2) == LUA_TSTRING)
    {
        const char* prop = lua_tostring(L, 2);
        if (strcmp(prop, OBF("OnInvoke")) == 0 || strcmp(prop, OBF("OnClientInvoke")) == 0 || strcmp(prop, OBF("OnServerInvoke")) == 0)
        {
            int top = lua_gettop(L);
            lua_pushstring(L, OBF("__callbacks"));
            lua_rawget(L, LUA_REGISTRYINDEX);
            if (lua_isnil(L, -1))
            {
                lua_pop(L, 1);
                lua_newtable(L);

                lua_newtable(L);
                lua_pushstring(L, OBF("k"));
                lua_setfield(L, -2, OBF("__mode"));
                lua_setmetatable(L, -2);

                lua_pushstring(L, OBF("__callbacks"));
                lua_pushvalue(L, -2);
                lua_rawset(L, LUA_REGISTRYINDEX);
            }

            lua_pushvalue(L, 1);
            lua_rawget(L, -2);
            if (lua_isnil(L, -1))
            {
                lua_pop(L, 1);
                lua_newtable(L);

                lua_pushvalue(L, 1);
                lua_pushvalue(L, -2);
                lua_rawset(L, -4);
            }

            lua_pushstring(L, prop);
            lua_pushvalue(L, 3);
            lua_rawset(L, -3);

            lua_settop(L, top);
        }
    }

    return OriginalNewindex(L);
}

void InitializeHooks(lua_State* L)
{
    int OriginalTop = lua_gettop(L);

    lua_getglobal(L, OBF("game"));
    luaL_getmetafield(L, -1, OBF("__index"));
    if (lua_type(L, -1) == LUA_TFUNCTION || lua_type(L, -1) == LUA_TLIGHTUSERDATA)
    {
        Closure* IndexClosure = clvalue(luaA_toobject(L, -1));
        if (IndexClosure->c.f != IndexHook)
            OriginalIndex = IndexClosure->c.f;
        IndexClosure->c.f = IndexHook;
    }
    lua_pop(L, 1);

    luaL_getmetafield(L, -1, OBF("__newindex"));
    if (lua_type(L, -1) == LUA_TFUNCTION || lua_type(L, -1) == LUA_TLIGHTUSERDATA)
    {
        Closure* NewindexClosure = clvalue(luaA_toobject(L, -1));
        if (NewindexClosure->c.f != NewindexHook)
            OriginalNewindex = NewindexClosure->c.f;
        NewindexClosure->c.f = NewindexHook;
    }
    lua_pop(L, 1);

    luaL_getmetafield(L, -1, OBF("__namecall"));
    if (lua_type(L, -1) == LUA_TFUNCTION || lua_type(L, -1) == LUA_TLIGHTUSERDATA)
    {
        Closure* NamecallClosure = clvalue(luaA_toobject(L, -1));
        if (NamecallClosure->c.f != NamecallHook)
            OriginalNamecall = NamecallClosure->c.f;
        NamecallClosure->c.f = NamecallHook;
    }
    lua_pop(L, 1);

    lua_settop(L, OriginalTop);


}
LUAU_FASTFLAG(LuauCIProto)
void ApplyLuauFlags()
{
    FFlag::LuauCIProto.value = true;
}

void Environment::SetupEnvironment(lua_State* L)
{
    std::memset(L->global->udatadirect, 0, sizeof(L->global->udatadirect));
    std::memset(L->global->udatadirectfields, 0, sizeof(L->global->udatadirectfields));
    Closures::ResetLibraryState();
    Signals::ResetLibraryState();
    Reflection::ResetLibraryState();
    class CTeleportHandler {
    public:
        uintptr_t GetDataModel();
        uintptr_t GetPlaceID(uintptr_t);
    };

    const auto TeleportHandler = std::make_unique<CTeleportHandler>();
    SharedVariables::ExecutorClosures.clear();
    Environment::function_array.clear();
    {
        std::lock_guard<std::mutex> lock(SharedVariables::YieldQueueMutex);
        std::queue<std::function<void()>> empty;
        SharedVariables::YieldQueue.swap(empty);
    }
    {
        std::lock_guard<std::mutex> lock(SharedVariables::ExecutionRequestsMutex);
        SharedVariables::ExecutionRequests.clear();
    }

    luaL_sandboxthread(L);

    Http::RegisterLibrary(L);
    Crypt::RegisterLibrary(L);
    Input::RegisterLibrary(L);
    Debug::RegisterLibrary(L);
    Cache::RegisterLibrary(L);
    Signals::RegisterLibrary(L);
    Script::RegisterLibrary(L);
    Closures::RegisterLibrary(L);
    Instance::RegisterLibrary(L);
    Websocket::Start(L);
    Metatable::RegisterLibrary(L);
    Filesystem::RegisterLibrary(L);
    Reflection::RegisterLibrary(L);
    Miscellaneous::RegisterLibrary(L);
    Regex::RegisterLibrary(L);
    FileDialog::RegisterLibrary(L);
    Actors::RegisterLibrary(L);
    InitializeHooks(L);
    luaL_sandboxthread(L);

    lua_pushvalue(L, LUA_GLOBALSINDEX);
    lua_setglobal(L, OBF("_G"));

    lua_newtable(L);
    lua_setglobal(L, OBF("shared"));

    ApplyLuauFlags();
    Auto::Execute();
}
