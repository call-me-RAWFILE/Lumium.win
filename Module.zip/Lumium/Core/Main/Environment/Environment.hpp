#pragma once

#include <string>
#include <vector>
#include <lstate.h>
#include <lualib.h>
#include <Luau/Compiler.h>
#include <iostream>
#include <Windows.h>
#include <functional>
#include <unordered_map>
#include <Globals.hpp>
#include "Helper/LuauHelper.hpp"
#include "Helper/Manager.hpp"
#include "Helper/Sha3.hpp"

namespace Environment
{
    void SetupEnvironment(lua_State* L);
    extern std::vector<Closure*> function_array;
}
