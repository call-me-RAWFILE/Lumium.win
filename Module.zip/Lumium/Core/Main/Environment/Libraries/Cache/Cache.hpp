#include <lstate.h>
#include <lualib.h>
#include <Utils.hpp>
#include <Globals.hpp>

namespace Cache
{
    inline void luaL_trimstack(lua_State* L, int n) {
        lua_settop(L, n);
    }

    inline int invalidate(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TUSERDATA);

        const auto rawUserdata = *static_cast<void**>(lua_touserdata(L, 1));

        lua_pushlightuserdata(L, (void*)Roblox::PushInstance);
        lua_gettable(L, LUA_REGISTRYINDEX);

        lua_pushlightuserdata(L, reinterpret_cast<void*>(rawUserdata));
        lua_pushnil(L);
        lua_settable(L, -3);

        return 0;
    }

    inline int replace(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TUSERDATA);
        luaL_checktype(L, 2, LUA_TUSERDATA);

        const auto rawUserdata = *static_cast<void**>(lua_touserdata(L, 1));

        lua_pushlightuserdata(L, (void*)Roblox::PushInstance);
        lua_gettable(L, LUA_REGISTRYINDEX);

        lua_pushlightuserdata(L, rawUserdata);
        lua_pushvalue(L, 2);
        lua_settable(L, -3);

        return 0;
    }

    inline int iscached(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TUSERDATA);

        const auto rawUserdata = *static_cast<void**>(lua_touserdata(L, 1));

        lua_pushlightuserdata(L, (void*)Roblox::PushInstance);
        lua_gettable(L, LUA_REGISTRYINDEX);

        lua_pushlightuserdata(L, rawUserdata);
        lua_gettable(L, -2);

        lua_pushboolean(L, lua_type(L, -1) != LUA_TNIL);

        return 1;
    }

    int getreg(lua_State* L) {
        Cache::luaL_trimstack(L, (int)0);

        lua_rawcheckstack(L, 1);
        luaC_threadbarrier(L);

        lua_pushvalue(L, LUA_REGISTRYINDEX);
        return 1;
    };

    inline int compareinstances(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TUSERDATA);
        luaL_checktype(L, 2, LUA_TUSERDATA);

        uintptr_t instance_one = *reinterpret_cast<uintptr_t*>(lua_touserdata(L, 1));
        uintptr_t instance_two = *reinterpret_cast<uintptr_t*>(lua_touserdata(L, 2));

        lua_pushboolean(L, instance_one == instance_two);

        return 1;
    }

    inline void RegisterLibrary(lua_State* L)
    {
        if (!L) return;

        lua_newtable(L);

        Utils::AddTableFunction(L, ENV_OBF("invalidate"), invalidate);
        Utils::AddTableFunction(L, ENV_OBF("iscached"), iscached);
        Utils::AddTableFunction(L, ENV_OBF("replace"), replace);

        lua_setglobal(L, ENV_OBF("cache"));

        Utils::AddFunction(L, ENV_OBF("getreg"), getreg);
        Utils::AddFunction(L, ENV_OBF("compareinstances"), compareinstances);
    }
}