#pragma once

#include <cstring>
#include <string>

#include <lapi.h>
#include <lstring.h>
#include <lstate.h>
#include <lualib.h>
#include <lgc.h>
#include <lmem.h>
#include <lobject.h>
#include <lfunc.h>
#include <ltable.h>
#include <ldebug.h>

#include <Main/Environment/Libraries/Main/Script/Script.hpp>
#include <Exploit/Execution/Execution.hpp>
#include <Utils.hpp>

class debug_library
{
public:
    static void initialize(lua_State* L);
};
namespace Debug
{
    Closure* header_get_function(lua_State* L, bool allowCclosure = false, bool popcl = true)
    {
        luaL_checkany(L, 1);

        if (!(lua_isfunction(L, 1) || lua_isnumber(L, 1)))
        {
            luaL_argerror(L, 1, OBF("function or number"));
        }

        int level = 0;
        if (lua_isnumber(L, 1))
        {
            level = lua_tointeger(L, 1);

            if (level <= 0)
            {
                luaL_argerror(L, 1, OBF("level out of range"));
            }
        }
        else if (lua_isfunction(L, 1))
        {
            level = -lua_gettop(L);
        }

        lua_Debug ar;
        if (!lua_getinfo(L, level, OBF("f"), &ar))
        {
            luaL_argerror(L, 1, OBF("invalid level"));
        }

        if (!lua_isfunction(L, -1))
            luaL_argerror(L, 1, OBF("level does not point to a function"));
        if (lua_iscfunction(L, -1) && !allowCclosure)
            luaL_argerror(L, 1, OBF("level points to c function"));

        if (!allowCclosure && lua_iscfunction(L, -1))
        {
            luaL_argerror(L, 1, OBF("luau function expected"));
        }

        auto function = clvalue(luaA_toobject(L, -1));
        if (popcl)
            lua_pop(L, 1);

        return function;
    }

    inline const char* aux_upvalue_2(Closure* f, int n, TValue** val)
    {
        if (f->isC)
        {
            if (!(1 <= n && n <= f->nupvalues))
                return NULL;
            *val = &f->c.upvals[n - 1];
            return OBF("");
        }
        else
        {
            Proto* p = f->l.p;
            if (!(1 <= n && n <= p->nups))
                return NULL;
            TValue* r = &f->l.uprefs[n - 1];
            *val = ttisupval(r) ? upvalue(r)->v : r;
            if (!(1 <= n && n <= p->sizeupvalues))
                return OBF("");
            return getstr(p->upvalues[n - 1]);
        }
    }

    int debug_getupvalues(lua_State* L)
    {
        luaL_checkany(L, 1);

        header_get_function(L, false, false);
        const int functionIndex = lua_gettop(L);

        lua_newtable(L);
        const int resultTable = lua_gettop(L);

        for (int index = 1;; ++index)
        {
            const char* name = lua_getupvalue(L, functionIndex, index);

            if (!name)
                break;

            lua_rawseti(L, resultTable, index);
        }

        return 1;
    }

    int debug_getupvalue(lua_State* L)
    {
        luaL_checkany(L, 1);

        const int index = static_cast<int>(luaL_checkinteger(L, 2));

        if (index < 1)
            luaL_argerror(L, 2, OBF("upvalue index must be positive"));

        header_get_function(L, false, false);
        const int functionIndex = lua_gettop(L);

        const char* name = lua_getupvalue(L, functionIndex, index);

        if (!name)
            luaL_argerror(L, 2, OBF("upvalue index out of bounds"));

        return 1;
    }

    int debug_setupvalue(lua_State* L)
    {
        const auto Func = header_get_function(L, false, false);
        const auto idx = lua_tointeger(L, 2);

        if (Func->nupvalues <= 0)
        {
            luaL_argerror(L, 1, OBF("function has no upvalues"));
        }

        if (!(idx >= 1 && idx <= Func->nupvalues))
        {
            luaL_argerror(L, 2, OBF("index out of range"));
        }

        lua_pushvalue(L, 3);
        lua_setupvalue(L, -2, idx);
        return 1;
    }

    int debug_getconstants(lua_State* L)
    {
        const auto Func = header_get_function(L);
        const auto p = (Proto*)Func->l.p;

        lua_createtable(L, p->sizek, 0);

        for (int i = 0; i < p->sizek; i++)
        {
            TValue k = p->k[i];

            if (k.tt == LUA_TNIL || k.tt == LUA_TFUNCTION || k.tt == LUA_TTABLE)
            {
                lua_pushnil(L);
            }
            else
            {
                luaC_threadbarrier(L);
                luaA_pushvalue(L, &k);
            }
            lua_rawseti(L, -2, i + 1);
        }

        return 1;
    }

    int debug_getconstant(lua_State* L)
    {
        const auto Func = header_get_function(L);
        const auto idx = luaL_checkinteger(L, 2);
        const auto p = (Proto*)Func->l.p;

        const auto level = -lua_gettop(L);

        if (p->sizek <= 0)
        {
            luaL_argerror(L, 1, OBF("function has no constants"));
        }

        lua_Debug ar;
        if (!lua_getinfo(L, level, OBF("f"), &ar))
            luaL_error(L, OBF("invalid level"));

        if (!(idx >= 1 && idx <= p->sizek))
        {
            luaL_argerror(L, 2, OBF("index out of range"));
        }

        const auto k = &p->k[idx - 1];

        if (k->tt == LUA_TNIL || k->tt == LUA_TTABLE || k->tt == LUA_TFUNCTION)
        {
            lua_pushnil(L);
            return 1;
        }

        luaA_pushvalue(L, k);
        return 1;
    }

    int debug_setconstant(lua_State* L)
    {
        luaL_checkany(L, 3);

        const auto Func = header_get_function(L);
        const auto idx = luaL_checkinteger(L, 2);
        const auto p = (Proto*)Func->l.p;

        if (p->sizek <= 0)
        {
            luaL_argerror(L, 1, OBF("function has no constants"));
        }

        if (!(idx >= 1 && idx <= p->sizek))
        {
            luaL_argerror(L, 2, OBF("index out of range"));
        }

        TValue* k = &p->k[idx - 1];

        if (k->tt == LUA_TFUNCTION || k->tt == LUA_TTABLE)
        {
            return 0;
        }
        else
        {
            if (k->tt == luaA_toobject(L, 3)->tt)
            {
                setobj2s(L, k, luaA_toobject(L, 3));
            }
        }

        return 0;
    }

    int debug_getprotos(lua_State* L)
    {
        Closure* Func = header_get_function(L);
        bool active = !lua_isnoneornil(L, 2) ? (lua_toboolean(L, 2) != 0) : false;

        Proto* p = (Proto*)Func->l.p;
        lua_createtable(L, p->sizep, 0);
        if (!active)
        {
            for (int i = 0; i < p->sizep; i++)
            {
                Proto* proto = p->p[i];
                lua_pushlightuserdata(L, (void*)proto);
                lua_rawseti(L, -2, i + 1);
            }
        }
        else
        {
            for (int i = 0; i < p->sizep; i++)
            {
                Proto* proto = p->p[i];
                Closure* pcl = luaF_newLclosure(L, Func->nupvalues, Func->env, proto);
                luaC_threadbarrier(L);
                setclvalue(L, L->top, pcl);
                L->top++;
                lua_rawseti(L, -2, i + 1);
            }
        }
        return 1;
    }

    Proto* clone_proto(lua_State* L, Proto* proto)
    {
        Proto* clone = luaF_newproto(L);

        clone->sizek = proto->sizek;
        clone->k = luaM_newarray(L, proto->sizek, TValue, proto->memcat);
        for (int i = 0; i < proto->sizek; ++i)
            setobj2n(L, &clone->k[i], &proto->k[i]);

        clone->sizelineinfo = proto->sizelineinfo;
        if (proto->sizelineinfo > 0)
        {
            clone->lineinfo = luaM_newarray(L, proto->sizelineinfo, uint8_t, proto->memcat);
            for (int i = 0; i < proto->sizelineinfo; ++i)
                clone->lineinfo[i] = proto->lineinfo[i];
        }
        else
        {
            clone->lineinfo = NULL;
        }

        clone->locvars = luaM_newarray(L, proto->sizelocvars, LocVar, proto->memcat);
        for (int i = 0; i < proto->sizelocvars; ++i)
        {
            const auto varname = getstr(proto->locvars[i].varname);
            const auto varname_size = strlen(varname);
            clone->locvars[i].varname = luaS_newlstr(L, varname, varname_size);
            clone->locvars[i].endpc = proto->locvars[i].endpc;
            clone->locvars[i].reg = proto->locvars[i].reg;
            clone->locvars[i].startpc = proto->locvars[i].startpc;
        }

        clone->nups = proto->nups;
        clone->sizeupvalues = proto->sizeupvalues;
        clone->sizelineinfo = proto->sizelineinfo;
        clone->linegaplog2 = proto->linegaplog2;
        clone->sizelocvars = proto->sizelocvars;
        clone->linedefined = proto->linedefined;

        if (proto->debugname)
        {
            const auto debugname = getstr(proto->debugname);
            const auto debugname_size = strlen(debugname);
            clone->debugname = luaS_newlstr(L, debugname, debugname_size);
        }

        if (proto->source)
        {
            const auto source = getstr(proto->source);
            const auto source_size = strlen(source);
            clone->source = luaS_newlstr(L, source, source_size);
        }

        clone->numparams = proto->numparams;
        clone->is_vararg = proto->is_vararg;
        clone->maxstacksize = proto->maxstacksize;
        clone->bytecodeid = proto->bytecodeid;

        std::string bytecode = Execution::CompileScript(std::string(OBF("return")));
        luau_load(L, OBF("@cloneproto"), bytecode.c_str(), bytecode.size(), 0);

        Closure* cl = clvalue(luaA_toobject(L, -1));

        clone->sizecode = cl->l.p->sizecode;
        clone->code = luaM_newarray(L, clone->sizecode, Instruction, proto->memcat);
        for (int i = 0; i < cl->l.p->sizecode; i++)
        {
            clone->code[i] = cl->l.p->code[i];
        }
        lua_pop(L, 1);

        clone->codeentry = clone->code;
        clone->debuginsn = 0;

        clone->sizep = proto->sizep;
        clone->p = luaM_newarray(L, proto->sizep, Proto*, proto->memcat);
        for (int i = 0; i < proto->sizep; ++i)
        {
            clone->p[i] = clone_proto(L, proto->p[i]);
        }

        return clone;
    }

    int debug_getproto(lua_State* L)
    {
        luaL_checkany(L, 1);

        const int index = static_cast<int>(luaL_checkinteger(L, 2));
        const bool active = luaL_optboolean(L, 3, false);

        Closure* parentClosure = nullptr;

        if (lua_isfunction(L, 1))
        {
            parentClosure = clvalue(luaA_toobject(L, 1));

            if (!parentClosure || parentClosure->isC)
                luaL_argerror(L, 1, OBF("Lua function expected"));
        }
        else if (lua_isnumber(L, 1))
        {
            const int level = static_cast<int>(luaL_checkinteger(L, 1));

            if (level <= 0)
                luaL_argerror(L, 1, OBF("stack level must be positive"));

            lua_Debug ar{};

            if (!lua_getinfo(L, level, OBF("f"), &ar))
                luaL_argerror(L, 1, OBF("stack level out of bounds"));

            if (!lua_isfunction(L, -1))
            {
                lua_pop(L, 1);
                luaL_argerror(L, 1, OBF("stack level does not contain a function"));
            }

            if (lua_iscfunction(L, -1))
            {
                lua_pop(L, 1);
                luaL_argerror(L, 1, OBF("Lua function expected"));
            }

            parentClosure = clvalue(luaA_toobject(L, -1));
            lua_pop(L, 1);
        }
        else
        {
            luaL_argerror(L, 1, OBF("function or stack level expected"));
        }

        if (!parentClosure || parentClosure->isC || !parentClosure->l.p)
            luaL_argerror(L, 1, OBF("invalid Lua function"));

        Proto* parentProto = parentClosure->l.p;

        if (index < 1 || index > parentProto->sizep || !parentProto->p)
            luaL_argerror(L, 2, OBF("index out of bounds"));

        Proto* wantedProto = parentProto->p[index - 1];

        if (!wantedProto)
            luaL_argerror(L, 2, OBF("proto is unavailable"));

        if (!active)
        {
            Proto* clonedProto = clone_proto(L, wantedProto);

            if (!clonedProto)
                luaL_error(L, OBF("failed to clone proto"));

            luaD_checkstack(L, 1);

            Closure* result = luaF_newLclosure(
                L,
                parentClosure->nupvalues,
                L->gt,
                clonedProto
            );

            if (!result)
                luaL_error(L, OBF("failed to create proto closure"));

            setclvalue(L, L->top, result);
            incr_top(L);
            luaC_threadbarrier(L);

            return 1;
        }

        lua_newtable(L);
        const int outputTable = lua_gettop(L);
        int outputCount = 0;

        lua_pushcfunction(L, Script::getgc, OBF("debug.getproto.internal_getgc"));
        lua_pushboolean(L, true);

        if (lua_pcall(L, 1, 1, 0) != LUA_OK)
        {
            const char* error = lua_tostring(L, -1);
            luaL_error(L, OBF("internal getgc failed: %s"), error ? error : OBF("unknown error"));
        }

        if (!lua_istable(L, -1))
        {
            lua_pop(L, 1);
            luaL_error(L, OBF("internal getgc did not return a table"));
        }

        const int gcTable = lua_gettop(L);
        const int objectCount = static_cast<int>(lua_objlen(L, gcTable));

        for (int i = 1; i <= objectCount; ++i)
        {
            lua_rawgeti(L, gcTable, i);

            if (lua_isfunction(L, -1) && !lua_iscfunction(L, -1))
            {
                Closure* candidate = clvalue(luaA_toobject(L, -1));

                if (candidate && !candidate->isC && candidate->l.p == wantedProto)
                {
                    lua_pushvalue(L, -1);
                    lua_rawseti(L, outputTable, ++outputCount);
                }
            }

            lua_pop(L, 1);
        }

        lua_pop(L, 1);

        return 1;
    }

    bool is_internal_stack_frame(CallInfo* ci)
    {
        if (!ci || !ci->func || !ttisfunction(ci->func))
            return true;

        Closure* closure = clvalue(ci->func);
        if (!closure)
            return true;

        if (closure->isC)
        {
            const char* debugName = static_cast<const char*>(closure->c.debugname);
            return debugName &&
                (strcmp(debugName, OBF("hookfunction")) == 0 ||
                    strcmp(debugName, OBF("newcclosure")) == 0 ||
                    strcmp(debugName, OBF("__lumium_hookfunction_dispatch")) == 0);
        }

        Proto* proto = closure->l.p;
        const char* source = proto && proto->source ? getstr(proto->source) : nullptr;
        return source && strcmp(source, OBF("=hookfunction")) == 0;
    }

    CallInfo* resolve_visible_stack_level(lua_State* target, int level)
    {
        if (!target || level <= 0)
            return nullptr;

        int visibleLevel = 0;
        for (CallInfo* ci = target->ci; ci > target->base_ci;)
        {
            --ci;

            if (is_internal_stack_frame(ci))
                continue;

            if (++visibleLevel == level)
                return ci;
        }

        return nullptr;
    }

    int stack_frame_size(lua_State* target, CallInfo* ci, Closure* closure)
    {
        if (!target || !ci || !ci->base)
            return 0;

        int size = 0;
        if (closure && !closure->isC && closure->l.p)
            size = closure->l.p->maxstacksize;

        if (size <= 0 && ci->top && ci->top > ci->base)
            size = static_cast<int>(ci->top - ci->base);

        if (size <= 0 && target->top > ci->base)
            size = static_cast<int>(target->top - ci->base);

        const int stackAvailable = static_cast<int>((target->stack + target->stacksize) - ci->base);
        if (stackAvailable < size)
            size = stackAvailable;

        return size > 0 ? size : 0;
    }

    bool resolve_stack_target(lua_State* L, int argPos, int& out_level, CallInfo*& out_ci, Closure*& out_cl)
    {
        out_level = 0;
        out_ci = nullptr;
        out_cl = nullptr;

        const int stack_size = static_cast<int>(L->ci - L->base_ci);

        if (lua_isnumber(L, argPos))
        {
            out_level = lua_tointeger(L, argPos);
            out_ci = resolve_visible_stack_level(L, out_level);
            if (!out_ci)
            {
                luaL_argerror(L, argPos, OBF("level out of range"));
                return false;
            }
        }
        else if (lua_isfunction(L, argPos))
        {
            for (int i = 1; i < stack_size; ++i)
            {
                CallInfo* ci = L->ci - i;
                if (is_internal_stack_frame(ci))
                    continue;

                if (!ci->func || !ttisfunction(ci->func))
                    continue;

                Closure* active = clvalue(ci->func);
                Closure* wanted = clvalue(luaA_toobject(L, argPos));
                if (active == wanted)
                {
                    out_level = i;
                    out_ci = ci;
                    break;
                }
            }

            if (out_level == 0)
            {
                luaL_argerror(L, argPos, OBF("function not found in call stack"));
                return false;
            }
        }
        else
        {
            luaL_argerror(L, argPos, OBF("function or number expected"));
            return false;
        }

        if (!out_ci)
        {
            out_ci = resolve_visible_stack_level(L, out_level);
            if (!out_ci)
            {
                luaL_argerror(L, argPos, OBF("invalid level"));
                return false;
            }
        }

        if (!out_ci->func || !ttisfunction(out_ci->func))
        {
            luaL_argerror(L, argPos, OBF("not a function"));
            return false;
        }

        out_cl = clvalue(out_ci->func);
        if (!out_cl)
        {
            luaL_argerror(L, argPos, OBF("not a function"));
            return false;
        }

        if (out_cl->isC)
        {
            luaL_argerror(L, argPos, OBF("luau function expected"));
            return false;
        }

        if (out_ci < L->base_ci || out_ci > L->ci)
        {
            luaL_error(L, OBF("invalid callinfo"));
            return false;
        }

        if (!out_ci->base || !out_ci->top)
        {
            luaL_error(L, OBF("callinfo base/top is null"));
            return false;
        }

        return true;
    }

    int debug_getstack(lua_State* L)
    {
        int arg = 0;
        lua_State* target = L;

        if (lua_isthread(L, 1))
        {
            target = lua_tothread(L, 1);
            if (!target)
                luaL_argerror(L, 1, OBF("invalid thread"));

            arg = 1;
        }

        const int level = luaL_checkinteger(L, arg + 1);
        CallInfo* ci = resolve_visible_stack_level(target, level);
        if (!ci)
            luaL_argerror(L, arg + 1, OBF("level out of range"));

        if (ci < target->base_ci || ci > target->ci)
            luaL_error(L, OBF("invalid callinfo"));

        if (!ci->func || ci->func->tt != LUA_TFUNCTION)
            luaL_error(L, OBF("invalid stack frame"));

        Closure* closure = clvalue(ci->func);
        if (closure && closure->isC)
            luaL_error(L, OBF("cannot get stack of a C function"));

        if (!ci->base)
            luaL_error(L, OBF("callinfo base is null"));

        const int frame_size = stack_frame_size(target, ci, closure);

        if (lua_isnumber(L, arg + 2))
        {
            const int idx = lua_tointeger(L, arg + 2) - 1;

            if (idx < 0 || idx >= frame_size)
            {
                lua_pushnil(L);
                return 1;
            }

            StkId slot = ci->base + idx;
            if (slot < target->stack || slot >= target->stack + target->stacksize)
            {
                lua_pushnil(L);
                return 1;
            }

            luaC_threadbarrier(L);
            luaA_pushvalue(L, slot);
        }
        else
        {
            lua_newtable(L);

            for (int i = 0; i < frame_size; ++i)
            {
                StkId slot = ci->base + i;
                if (slot < target->stack || slot >= target->stack + target->stacksize)
                    break;

                luaC_threadbarrier(L);
                luaA_pushvalue(L, slot);
                lua_rawseti(L, -2, i + 1);
            }
        }

        return 1;
    }

    int debug_setstack(lua_State* L)
    {
        int level = 0;
        CallInfo* ci = nullptr;
        Closure* closure = nullptr;
        if (!resolve_stack_target(L, 1, level, ci, closure))
            return 0;

        const auto idx = luaL_checkinteger(L, 2) - 1;
        const int frame_size = stack_frame_size(L, ci, closure);
        if (idx >= frame_size || idx < 0)
        {
            luaL_argerror(L, 2, OBF("index out of range"));
        }

        const TValue* new_value = luaA_toobject(L, 3);
        if (!new_value)
        {
            luaL_argerror(L, 3, OBF("invalid value"));
        }

        setobj2s(L, ci->base + idx, new_value);
        return 0;
    }


    int debug_getinfo(lua_State* L)
    {
        luaL_checkany(L, 1);

        if (!(lua_isfunction(L, 1) || lua_isnumber(L, 1)))
        {
            luaL_argerror(L, 1, OBF("function or number"));
        }

        int level;
        if (lua_isnumber(L, 1))
        {
            level = lua_tointeger(L, 1);
        }
        else
        {
            level = -lua_gettop(L);
        }

        const char* desc = OBF("sluanf");

        lua_Debug ar;
        if (!lua_getinfo(L, level, desc, &ar))
        {
            luaL_argerror(L, 1, OBF("invalid level"));
        }

        if (!lua_isfunction(L, -1))
        {
            luaL_argerror(L, 1, OBF("level does not point to a function."));
        }

        lua_newtable(L);
        {
            if (std::strchr(desc, 's'))
            {
                lua_pushstring(L, ar.source);
                lua_setfield(L, -2, ENV_OBF("source"));

                lua_pushstring(L, ar.short_src);
                lua_setfield(L, -2, ENV_OBF("short_src"));

                lua_pushstring(L, ar.what);
                lua_setfield(L, -2, ENV_OBF("what"));

                lua_pushinteger(L, ar.linedefined);
                lua_setfield(L, -2, ENV_OBF("linedefined"));
            }

            if (std::strchr(desc, 'l'))
            {
                lua_pushinteger(L, ar.currentline);
                lua_setfield(L, -2, ENV_OBF("currentline"));
            }

            if (std::strchr(desc, 'u'))
            {
                lua_pushinteger(L, ar.nupvals);
                lua_setfield(L, -2, ENV_OBF("nups"));
            }

            if (std::strchr(desc, 'a'))
            {
                lua_pushinteger(L, ar.isvararg);
                lua_setfield(L, -2, ENV_OBF("is_vararg"));

                lua_pushinteger(L, ar.nparams);
                lua_setfield(L, -2, ENV_OBF("numparams"));
            }

            if (std::strchr(desc, 'n'))
            {
                lua_pushstring(L, ar.name);
                lua_setfield(L, -2, ENV_OBF("name"));
            }

            if (std::strchr(desc, 'f'))
            {
                lua_pushvalue(L, -2);
                lua_remove(L, -3);
                lua_setfield(L, -2, ENV_OBF("func"));
            }
        }

        return 1;
    }

    int debug_getregistry(lua_State* L)
    {
        lua_pushvalue(L, LUA_REGISTRYINDEX);
        return 1;
    }
}

void debug_library::initialize(lua_State* L)
{
    lua_getglobal(L, ENV_OBF("debug"));
    if (!lua_istable(L, -1))
    {
        lua_pop(L, 1);
        lua_newtable(L);
    }

    lua_setreadonly(L, -1, false);

    Utils::AddTableFunction(L, ENV_OBF("getproto"), Debug::debug_getproto);
    Utils::AddTableFunction(L, ENV_OBF("getprotos"), Debug::debug_getprotos);
    Utils::AddTableFunction(L, ENV_OBF("getstack"), Debug::debug_getstack);
    Utils::AddTableFunction(L, ENV_OBF("getinfo"), Debug::debug_getinfo);
    Utils::AddTableFunction(L, ENV_OBF("getupvalue"), Debug::debug_getupvalue);
    Utils::AddTableFunction(L, ENV_OBF("getupvalues"), Debug::debug_getupvalues);
    Utils::AddTableFunction(L, ENV_OBF("getconstant"), Debug::debug_getconstant);
    Utils::AddTableFunction(L, ENV_OBF("getconstants"), Debug::debug_getconstants);
    Utils::AddTableFunction(L, ENV_OBF("setconstant"), Debug::debug_setconstant);
    Utils::AddTableFunction(L, ENV_OBF("setstack"), Debug::debug_setstack);
    Utils::AddTableFunction(L, ENV_OBF("setupvalue"), Debug::debug_setupvalue);
    Utils::AddTableFunction(L, ENV_OBF("getregistry"), Debug::debug_getregistry);
    Utils::AddFunction(L, ENV_OBF("setstack"), Debug::debug_setstack);
    Utils::AddFunction(L, ENV_OBF("getstack"), Debug::debug_getstack);
    Utils::AddFunction(L, ENV_OBF("getconstant"), Debug::debug_getconstant);
    Utils::AddFunction(L, ENV_OBF("setconstant"), Debug::debug_setconstant);
    Utils::AddFunction(L, ENV_OBF("getconstants"), Debug::debug_getconstants);
    Utils::AddFunction(L, ENV_OBF("getproto"), Debug::debug_getproto);
    Utils::AddFunction(L, ENV_OBF("getprotos"), Debug::debug_getprotos);
    Utils::AddFunction(L, ENV_OBF("getupvalue"), Debug::debug_getupvalue);
    Utils::AddFunction(L, ENV_OBF("setupvalue"), Debug::debug_setupvalue);
    Utils::AddFunction(L, ENV_OBF("getupvalues"), Debug::debug_getupvalues);

    lua_setreadonly(L, -1, true);
    lua_setglobal(L, ENV_OBF("debug"));
}

namespace Debug
{
    void RegisterLibrary(lua_State* L)
    {
        debug_library::initialize(L);
    }
}
