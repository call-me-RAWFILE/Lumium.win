#pragma once

#include <map>
#include <string>
#include <sstream>
#include <lstate.h>
#include <lualib.h>
#include <optional>
#include <algorithm>
#include <Windows.h>

#include <cpr/cpr.h>
#include <Utils.hpp>
#include <Globals.hpp>
#include <nlohmann/json.hpp>
#include <Main/Yield/Yield.hpp>

enum RequestMethods
{
    H_GET,
    H_HEAD,
    H_POST,
    H_PUT,
    H_DELETE,
    H_OPTIONS
};

std::map<std::string, RequestMethods> RequestMethodMap = {
   { OBF("get"), H_GET },
   { OBF("head"), H_HEAD },
   { OBF("post"), H_POST },
   { OBF("put"), H_PUT },
   { OBF("delete"), H_DELETE },
   { OBF("options"), H_OPTIONS }
};

namespace Http
{
    int HttpGet(lua_State* L)
    {
        std::string Url;

        if (!lua_isstring(L, 1))
        {
            luaL_checkstring(L, 2);
            Url = lua_tostring(L, 2);
        }
        else
        {
            Url = lua_tostring(L, 1);
        }

        if (Url.find(OBF("http://")) != 0 && Url.find(OBF("https://")) != 0)
        {
            luaL_argerror(L, 2, OBF("Invalid protocol (expected 'http://' or 'https://')"));
            return 0;
        }

        std::string GameId;
        lua_getglobal(L, ENV_OBF("game"));
        if (lua_istable(L, -1))
        {
            lua_getfield(L, -1, ENV_OBF("GameId"));
            if (lua_isstring(L, -1))
                GameId = lua_tostring(L, -1);

            lua_pop(L, 1);
        }
        lua_pop(L, 1);

        std::string PlaceId;
        lua_getglobal(L, ENV_OBF("game"));
        if (lua_istable(L, -1))
        {
            lua_getfield(L, -1, ENV_OBF("PlaceId"));
            if (lua_isstring(L, -1))
                PlaceId = lua_tostring(L, -1);

            lua_pop(L, 1);
        }
        lua_pop(L, 1);

        HW_PROFILE_INFO hwProfileInfo;
        std::optional<std::string> HWID;
        if (GetCurrentHwProfile(&hwProfileInfo))
        {
            std::wstring wGuid(hwProfileInfo.szHwProfileGuid);
            std::string Guid(wGuid.begin(), wGuid.end());
            HWID = Guid;
        }

        using Json = nlohmann::json;
        cpr::Header Headers;

        Json SessionIdJson;
        SessionIdJson["GameId"] = GameId;
        SessionIdJson["PlaceId"] = PlaceId;

        std::string domain;
        {
            size_t schemeEnd = Url.find("://");
            if (schemeEnd != std::string::npos)
            {
                size_t hostStart = schemeEnd + 3;
                size_t hostEnd = Url.find_first_of("/:?#", hostStart);
                domain = Url.substr(hostStart, hostEnd - hostStart);
            }
        }

        if (domain.find("luarmor.net") != std::string::npos)
        {
            Headers[OBF("User-Agent")] = OBF("Seliware/1.0");
            Headers[OBF("Seliware-Fingerprint")] = HWID.value_or(OBF("Unknown"));
            Headers[OBF("Accept")] = OBF("*/*");
            Headers[OBF("Accept-Language")] = OBF("en-US,en;q=0.9");
            Headers[OBF("Accept-Encoding")] = OBF("gzip, deflate, br");
            Headers[OBF("Origin")] = OBF("https://luarmor.net");
            Headers[OBF("Referer")] = OBF("https://luarmor.net/");
            Headers[OBF("Sec-Fetch-Dest")] = OBF("empty");
            Headers[OBF("Sec-Fetch-Mode")] = OBF("cors");
            Headers[OBF("Sec-Fetch-Site")] = OBF("same-origin");
            Headers[OBF("Connection")] = OBF("keep-alive");
            Headers[OBF("LUAU-EXECUTOR")] = OBF("Seliware");
            Headers[OBF("LUAU-HWID")] = HWID.value_or(OBF("Unknown"));
        }
        else
        {
            Headers[OBF("User-Agent")] = OBF("Lumium/1.0.0");
        }

        Headers.insert({ OBF("Roblox-Session-Id"), SessionIdJson.dump() });
        Headers.insert({ OBF("Roblox-Place-Id"), PlaceId });
        Headers.insert({ OBF("Roblox-Game-Id"), GameId });
        Headers.insert({ OBF("Exploit-Identifier"), OBF("Lumium/1.0.0") });
        Headers.insert({ OBF("Exploit-Guid"), HWID.value_or(OBF("Unknown")) });
        Headers.insert({ OBF("Accept"), OBF("*/*") });

        return Yielding::YieldExecution(L, [Url, Headers]() -> std::function<int(lua_State*)>
            {
                cpr::Response Result;
                try
                {
                    Result = cpr::Get(cpr::Url{ Url }, cpr::Header(Headers), cpr::VerifySsl(false), cpr::Timeout{ 10000 }, cpr::MaxRedirects{ 10 });
                }
                catch (const std::exception& ex)
                {
                    std::stringstream Error;
                    Error << OBF("HttpGet failed: ") << ex.what();
                    std::string ErrorString = Error.str();
                    return [ErrorString](lua_State* L) -> int
                        {
                            lua_pushstring(L, ErrorString.c_str());
                            return 1;
                        };
                }
                catch (...)
                {
                    return [](lua_State* L) -> int
                        {
                            lua_pushstring(L, OBF("HttpGet failed: unknown exception"));
                            return 1;
                        };
                }

                return [Result, Url](lua_State* L) -> int
                    {
                        if (Result.error.code != cpr::ErrorCode::OK)
                        {
                            std::stringstream Error;
                            Error << OBF("HttpGet failed: ") << Result.error.message << OBF(", Code: ") << Result.status_code;
                            std::string ErrorString = Error.str();
                            lua_pushstring(L, ErrorString.c_str());
                            return 1;
                        }

                        if (Result.status_code != 200)
                        {
                            std::stringstream Error;
                            Error << OBF("HttpGet returned status: ") << Result.status_code << OBF(", Error: ") << Result.error.message;
                            std::string ErrorString = Error.str();
                            lua_pushstring(L, ErrorString.c_str());
                            return 1;
                        }

                        lua_pushlstring(L, Result.text.data(), Result.text.size());
                        return 1;
                    };
            });
    }

    int request(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TTABLE);

        lua_getfield(L, 1, ENV_OBF("Url"));
        if (!lua_isstring(L, -1))
            luaL_error(L, OBF("Missing or invalid 'Url'"));

        std::string Url = lua_tostring(L, -1);
        lua_pop(L, 1);

        if (Url.find(OBF("http://")) != 0 && Url.find(OBF("https://")) != 0)
        {
            luaL_error(L, OBF("Invalid protocol (expected 'http://' or 'https://')"));
            return 0;
        }

        auto Method = H_GET;
        lua_getfield(L, 1, ENV_OBF("Method"));
        if (lua_isstring(L, -1))
        {
            std::string MethodStr = lua_tostring(L, -1);
            std::transform(MethodStr.begin(), MethodStr.end(), MethodStr.begin(), ::tolower);
            if (!RequestMethodMap.count(MethodStr))
                luaL_error(L, OBF("Invalid request method: '%s'"), MethodStr.c_str());

            Method = RequestMethodMap[MethodStr];
        }
        lua_pop(L, 1);

        cpr::Header Headers;
        lua_getfield(L, 1, ENV_OBF("Headers"));
        if (lua_istable(L, -1))
        {
            lua_pushnil(L);
            while (lua_next(L, -2))
            {
                if (!lua_isstring(L, -2) || !lua_isstring(L, -1))
                    luaL_error(L, OBF("'Headers' must have string keys/values"));

                std::string Key = lua_tostring(L, -2);
                if (_stricmp(Key.c_str(), ENV_OBF("Content-Length")) == 0)
                    luaL_error(L, OBF("'Content-Length' cannot be overwritten"));

                Headers[Key] = lua_tostring(L, -1);
                lua_pop(L, 1);
            }
        }
        lua_pop(L, 1);

        cpr::Cookies Cookies;
        lua_getfield(L, 1, ENV_OBF("Cookies"));
        if (lua_istable(L, -1))
        {
            lua_pushnil(L);
            while (lua_next(L, -2))
            {
                if (!lua_isstring(L, -2) || !lua_isstring(L, -1))
                    luaL_error(L, OBF("'Cookies' must have string keys/values"));

                Cookies[lua_tostring(L, -2)] = lua_tostring(L, -1);
                lua_pop(L, 1);
            }
        }
        lua_pop(L, 1);

        std::string Body;
        lua_getfield(L, 1, ENV_OBF("Body"));
        if (lua_isstring(L, -1))
        {
            if (Method == H_GET || Method == H_HEAD)
                luaL_error(L, OBF("'Body' is not allowed for GET/HEAD requests"));

            Body = lua_tostring(L, -1);
        }
        lua_pop(L, 1);

        std::string GameId;
        lua_getglobal(L, ENV_OBF("game"));
        if (lua_istable(L, -1))
        {
            lua_getfield(L, -1, ENV_OBF("GameId"));
            if (lua_isstring(L, -1))
                GameId = lua_tostring(L, -1);

            lua_pop(L, 1);
        }
        lua_pop(L, 1);

        std::string PlaceId;
        lua_getglobal(L, ENV_OBF("game"));
        if (lua_istable(L, -1))
        {
            lua_getfield(L, -1, ENV_OBF("PlaceId"));
            if (lua_isstring(L, -1))
                PlaceId = lua_tostring(L, -1);

            lua_pop(L, 1);
        }
        lua_pop(L, 1);

        HW_PROFILE_INFO hwProfileInfo;
        std::optional<std::string> HWID;
        if (GetCurrentHwProfile(&hwProfileInfo))
        {
            std::wstring wGuid(hwProfileInfo.szHwProfileGuid);
            std::string Guid(wGuid.begin(), wGuid.end());
            HWID = Guid;
        }

        nlohmann::json SessionIdJson;
        SessionIdJson["GameId"] = GameId;
        SessionIdJson["PlaceId"] = PlaceId;

        bool isUserScript = true;
        if (SharedVariables::ExploitThread && L == SharedVariables::ExploitThread)
            isUserScript = false;
        else if (L && L->userdata && L->userdata->capabilities == MaxCapabilities)
            isUserScript = false;

        std::string requestDomain;
        {
            size_t schemeEnd = Url.find("://");
            if (schemeEnd != std::string::npos)
            {
                size_t hostStart = schemeEnd + 3;
                size_t hostEnd = Url.find_first_of("/:?#", hostStart);
                requestDomain = Url.substr(hostStart, hostEnd - hostStart);
            }
        }

        if (requestDomain.find("luarmor.net") != std::string::npos)
        {
            Headers[OBF("User-Agent")] = OBF("Seliware/1.0");
            Headers[OBF("Seliware-Fingerprint")] = HWID.value_or(OBF("Unknown"));
            Headers[OBF("Accept")] = OBF("*/*");
            Headers[OBF("Accept-Language")] = OBF("en-US,en;q=0.9");
            Headers[OBF("Accept-Encoding")] = OBF("gzip, deflate, br");
            Headers[OBF("Origin")] = OBF("https://luarmor.net");
            Headers[OBF("Referer")] = OBF("https://luarmor.net/");
            Headers[OBF("Sec-Fetch-Dest")] = OBF("empty");
            Headers[OBF("Sec-Fetch-Mode")] = OBF("cors");
            Headers[OBF("Sec-Fetch-Site")] = OBF("same-origin");
            Headers[OBF("Connection")] = OBF("keep-alive");
            Headers[OBF("LUAU-EXECUTOR")] = OBF("Seliware");
            Headers[OBF("LUAU-HWID")] = HWID.value_or(OBF("Unknown"));
        }
        else
        {
            Headers.insert({ OBF("User-Agent"), OBF("Lumium/1.0.0") });
            Headers.insert({ OBF("Roblox-Session-Id"), SessionIdJson.dump() });
            Headers.insert({ OBF("Lumium-Fingerprint"), HWID.value_or(OBF("Unknown")) });
        }

        return Yielding::YieldExecution(L, [=]() -> std::function<int(lua_State*)>
            {
                cpr::Response Response;
                try
                {
                    switch (Method)
                    {
                    case H_GET: Response = cpr::Get(cpr::Url{ Url }, Cookies, Headers, cpr::VerifySsl(false), cpr::Timeout{ 10000 }, cpr::MaxRedirects{ 10 }); break;
                    case H_HEAD: Response = cpr::Head(cpr::Url{ Url }, Cookies, Headers, cpr::VerifySsl(false), cpr::Timeout{ 10000 }, cpr::MaxRedirects{ 10 }); break;
                    case H_POST: Response = cpr::Post(cpr::Url{ Url }, cpr::Body{ Body }, Cookies, Headers, cpr::VerifySsl(false), cpr::Timeout{ 10000 }, cpr::MaxRedirects{ 10 }); break;
                    case H_PUT: Response = cpr::Put(cpr::Url{ Url }, cpr::Body{ Body }, Cookies, Headers, cpr::VerifySsl(false), cpr::Timeout{ 10000 }, cpr::MaxRedirects{ 10 }); break;
                    case H_DELETE: Response = cpr::Delete(cpr::Url{ Url }, cpr::Body{ Body }, Cookies, Headers, cpr::VerifySsl(false), cpr::Timeout{ 10000 }, cpr::MaxRedirects{ 10 }); break;
                    case H_OPTIONS: Response = cpr::Options(cpr::Url{ Url }, cpr::Body{ Body }, Cookies, Headers, cpr::VerifySsl(false), cpr::Timeout{ 10000 }, cpr::MaxRedirects{ 10 }); break;
                    default: throw std::runtime_error(OBF("Invalid request method")); break;
                    }
                }
                catch (const std::exception& ex)
                {
                    std::string Err = std::string(OBF("Request failed: ")) + ex.what();
                    return [Err](lua_State* L) -> int
                        {
                            lua_pushstring(L, Err.c_str());
                            return 1;
                        };
                }

                return [Response](lua_State* L) -> int
                    {
                        if (Response.error.code != cpr::ErrorCode::OK)
                        {
                            std::string Err = OBF("Request failed: ") + Response.error.message;
                            lua_pushstring(L, Err.c_str());
                            return 1;
                        }

                        lua_newtable(L);
                        lua_pushboolean(L, Response.status_code >= 200 && Response.status_code < 300);
                        lua_setfield(L, -2, ENV_OBF("Success"));

                        lua_pushinteger(L, Response.status_code);
                        lua_setfield(L, -2, ENV_OBF("StatusCode"));

                        std::string Phrase;
                        switch (Response.status_code)
                        {
                        case 100: Phrase = std::string(OBF("Continue")); break;
                        case 101: Phrase = std::string(OBF("Switching Protocols")); break;
                        case 102: Phrase = std::string(OBF("Processing")); break;
                        case 103: Phrase = std::string(OBF("Early Hints")); break;

                        case 200: Phrase = std::string(OBF("OK")); break;
                        case 201: Phrase = std::string(OBF("Created")); break;
                        case 202: Phrase = std::string(OBF("Accepted")); break;
                        case 203: Phrase = std::string(OBF("Non-Authoritative Information")); break;
                        case 204: Phrase = std::string(OBF("No Content")); break;
                        case 205: Phrase = std::string(OBF("Reset Content")); break;
                        case 206: Phrase = std::string(OBF("Partial Content")); break;
                        case 207: Phrase = std::string(OBF("Multi-Status")); break;
                        case 208: Phrase = std::string(OBF("Already Reported")); break;
                        case 226: Phrase = std::string(OBF("IM Used")); break;

                        case 300: Phrase = std::string(OBF("Multiple Choices")); break;
                        case 301: Phrase = std::string(OBF("Moved Permanently")); break;
                        case 302: Phrase = std::string(OBF("Found")); break;
                        case 303: Phrase = std::string(OBF("See Other")); break;
                        case 304: Phrase = std::string(OBF("Not Modified")); break;
                        case 305: Phrase = std::string(OBF("Use Proxy")); break;
                        case 307: Phrase = std::string(OBF("Temporary Redirect")); break;
                        case 308: Phrase = std::string(OBF("Permanent Redirect")); break;

                        case 400: Phrase = std::string(OBF("Bad Request")); break;
                        case 401: Phrase = std::string(OBF("Unauthorized")); break;
                        case 402: Phrase = std::string(OBF("Payment Required")); break;
                        case 403: Phrase = std::string(OBF("Forbidden")); break;
                        case 404: Phrase = std::string(OBF("Not Found")); break;
                        case 405: Phrase = std::string(OBF("Method Not Allowed")); break;
                        case 406: Phrase = std::string(OBF("Not Acceptable")); break;
                        case 407: Phrase = std::string(OBF("Proxy Authentication Required")); break;
                        case 408: Phrase = std::string(OBF("Request Timeout")); break;
                        case 409: Phrase = std::string(OBF("Conflict")); break;
                        case 410: Phrase = std::string(OBF("Gone")); break;
                        case 411: Phrase = std::string(OBF("Length Required")); break;
                        case 412: Phrase = std::string(OBF("Precondition Failed")); break;
                        case 413: Phrase = std::string(OBF("Payload Too Large")); break;
                        case 414: Phrase = std::string(OBF("URI Too Long")); break;
                        case 415: Phrase = std::string(OBF("Unsupported Media Type")); break;
                        case 416: Phrase = std::string(OBF("Range Not Satisfiable")); break;
                        case 417: Phrase = std::string(OBF("Expectation Failed")); break;
                        case 418: Phrase = std::string(OBF("I'm a teapot")); break;
                        case 422: Phrase = std::string(OBF("Unprocessable Entity")); break;
                        case 423: Phrase = std::string(OBF("Locked")); break;
                        case 424: Phrase = std::string(OBF("Failed Dependency")); break;
                        case 426: Phrase = std::string(OBF("Upgrade Required")); break;
                        case 428: Phrase = std::string(OBF("Precondition Required")); break;
                        case 429: Phrase = std::string(OBF("Too Many Requests")); break;
                        case 431: Phrase = std::string(OBF("Request Header Fields Too Large")); break;
                        case 451: Phrase = std::string(OBF("Unavailable For Legal Reasons")); break;

                        case 500: Phrase = std::string(OBF("Internal Server Error")); break;
                        case 501: Phrase = std::string(OBF("Not Implemented")); break;
                        case 502: Phrase = std::string(OBF("Bad Gateway")); break;
                        case 503: Phrase = std::string(OBF("Service Unavailable")); break;
                        case 504: Phrase = std::string(OBF("Gateway Time-out")); break;
                        case 505: Phrase = std::string(OBF("HTTP Version Not Supported")); break;
                        case 506: Phrase = std::string(OBF("Variant Also Negotiates")); break;
                        case 507: Phrase = std::string(OBF("Insufficient Storage")); break;
                        case 508: Phrase = std::string(OBF("Loop Detected")); break;
                        case 510: Phrase = std::string(OBF("Not Extended")); break;
                        case 511: Phrase = std::string(OBF("Network Authentication Required")); break;

                        default: Phrase = std::string(); break;
                        }
                        lua_pushstring(L, Phrase.c_str());
                        lua_setfield(L, -2, ENV_OBF("StatusMessage"));

                        lua_newtable(L);
                        for (auto& Header : Response.header)
                        {
                            lua_pushstring(L, Header.first.c_str());
                            lua_pushstring(L, Header.second.c_str());
                            lua_settable(L, -3);
                        }
                        lua_setfield(L, -2, ENV_OBF("Headers"));

                        lua_newtable(L);
                        for (auto& C : Response.cookies.map_)
                        {
                            lua_pushstring(L, C.first.c_str());
                            lua_pushstring(L, C.second.c_str());
                            lua_settable(L, -3);
                        }
                        lua_setfield(L, -2, ENV_OBF("Cookies"));

                        lua_pushlstring(L, Response.text.data(), Response.text.size());
                        lua_setfield(L, -2, ENV_OBF("Body"));

                        return 1;
                    };
            });
    }

    void RegisterLibrary(lua_State* L)
    {
        Utils::AddFunction(L, ENV_OBF("HttpGet"), Http::HttpGet);
        Utils::AddFunction(L, ENV_OBF("request"), Http::request);
        Utils::AddFunction(L, ENV_OBF("http_request"), Http::request);

        lua_newtable(L);
        Utils::AddTableFunction(L, ENV_OBF("request"), Http::request);
        lua_setglobal(L, ENV_OBF("http"));
    }
}
