#pragma once

#include <Windows.h>
#include <lstate.h>
#include <lobject.h>
#include <lfunc.h>
#include <lstring.h>
#include <ltable.h>
#include <lapi.h>
#include <lgc.h>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <string>
#include <lualib.h>

#include <Utils.hpp>
#include <Globals.hpp>
#include <Main/Environment/Helper/LuauHelper.hpp>
#include <Main/Environment/Libraries/Closures/Closures.hpp>



namespace Metatable {
    inline int getrawmetatable(lua_State* LS) {

        if (LS->userdata == nullptr)
            return 0;

        luaL_checkany(LS, 1);

        if (!lua_getmetatable(LS, 1))
            lua_pushnil(LS);

        return 1;
    };

    int setreadonly(lua_State* L) {
        luaL_checktype(L, 1, LUA_TTABLE);
        luaL_checktype(L, 2, LUA_TBOOLEAN);
        hvalue(luaA_toobject(L, 1))->readonly = lua_toboolean(L, 2);
        return 0;
    }

    int isreadonly(lua_State* L) {
        luaL_checktype(L, 1, LUA_TTABLE);
        lua_pushboolean(L, hvalue(luaA_toobject(L, 1))->readonly);
        return 1;
    }


    int setrawmetatable(lua_State* L)
    {
        luaL_checkany(L, 1);

        const int metatableType = lua_type(L, 2);

        if (metatableType != LUA_TTABLE && metatableType != LUA_TNIL)
            luaL_typeerror(L, 2, OBF("table or nil"));

        lua_settop(L, 2);
        lua_setmetatable(L, 1);

        lua_pushvalue(L, 1);
        return 1;
    }

    int makereadonly(lua_State* L) {

        luaL_checktype(L, 1, LUA_TTABLE);

        LuaTable* table = hvalue(luaA_toobject(L, 1));

        table->readonly = true;

        return 0;
    }
    int makewriteable(lua_State* L) {

        luaL_checktype(L, 1, LUA_TTABLE);

        LuaTable* table = hvalue(luaA_toobject(L, 1));

        table->readonly = false;

        return 0;
    }

    inline int getnamecallmethod(lua_State* L)
    {
        const char* namecall = lua_namecallatom(L, nullptr);

        if (!namecall)
        {
            lua_pushnil(L);
            return 1;
        }

        lua_pushstring(L, namecall);
        return 1;
    }

    inline int hookmetamethod(lua_State* L)
    {
        luaL_checkany(L, 1);
        luaL_checktype(L, 2, LUA_TSTRING);
        luaL_checktype(L, 3, LUA_TFUNCTION);

        const char* metamethod = lua_tostring(L, 2);

        if (!lua_getmetatable(L, 1)) {
            luaL_argerror(L, 1, OBF("object has no metatable"));
        }
        int mt_idx = lua_gettop(L);

        bool wasReadonly = lua_getreadonly(L, mt_idx);
        if (wasReadonly) {
            lua_setreadonly(L, mt_idx, false);
        }

        lua_getfield(L, mt_idx, metamethod);
        if (lua_isnil(L, -1)) {
            lua_pop(L, 1);
            if (wasReadonly) lua_setreadonly(L, mt_idx, true);
            luaL_argerror(L, 2, OBF("metamethod does not exist"));
        }
        int old_method = lua_gettop(L);

        lua_pushvalue(L, 3);
        lua_setfield(L, mt_idx, metamethod);

        if (wasReadonly) {
            lua_setreadonly(L, mt_idx, true);
        }

        lua_pushvalue(L, old_method);
        return 1;
    }

    inline void RegisterLibrary(lua_State* L)
    {
        Utils::AddFunction(L, ENV_OBF("hookmetamethod"), hookmetamethod);
        Utils::AddFunction(L, ENV_OBF("getnamecallmethod"), getnamecallmethod);
        Utils::AddFunction(L, ENV_OBF("setreadonly"), setreadonly);
        Utils::AddFunction(L, ENV_OBF("isreadonly"), isreadonly);
        Utils::AddFunction(L, ENV_OBF("getrawmetatable"), getrawmetatable);
        Utils::AddFunction(L, ENV_OBF("setrawmetatable"), setrawmetatable);
        Utils::AddFunction(L, ENV_OBF("makereadonly"), makereadonly);
        Utils::AddFunction(L, ENV_OBF("makewriteable"), makewriteable);
    }
}