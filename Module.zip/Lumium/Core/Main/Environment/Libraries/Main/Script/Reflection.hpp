#include <lstate.h>
#include <lualib.h>
#include <Utils.hpp>
#include <Globals.hpp>
#include <Roblox/Offsets.hpp>
#include <Windows.h>
#include <unordered_map>
#include <string>

static bool IsRobloxInstance(lua_State* L, int idx)
{
    if (!lua_isuserdata(L, idx)) return false;
    lua_getglobal(L, "typeof");
    lua_pushvalue(L, idx);
    if (lua_pcall(L, 1, 1, 0) != LUA_OK) { lua_pop(L, 1); return false; }
    bool ok = lua_isstring(L, -1) && strcmp(lua_tostring(L, -1), "Instance") == 0;
    lua_pop(L, 1);
    return ok;
}

    static std::unordered_map<uintptr_t, std::unordered_map<uintptr_t, bool>> scriptable_overrides;

namespace Reflection
{

    struct CallbackRecord
    {
        int FunctionRef = LUA_NOREF;
        uint64_t Generation = 0;
    };

    inline std::unordered_map<uintptr_t, std::unordered_map<uintptr_t, bool>> scriptable_overrides;
    inline std::unordered_map<uintptr_t, bool> original_scriptable_flags;
    inline std::unordered_map<uintptr_t, std::unordered_map<std::string, CallbackRecord>> callback_values;
    inline bool can_read(uintptr_t address, size_t size = sizeof(uintptr_t)) noexcept;

    inline uintptr_t get_instance_prop_by_name(lua_State* L, uintptr_t instance, const char* propName)
    {
        if (!instance || !can_read(instance + 0x18, sizeof(uintptr_t)))
            return 0;

        uintptr_t classDescriptor = *reinterpret_cast<uintptr_t*>(instance + 0x18);
        if (!classDescriptor)
            return 0;

        uintptr_t super = classDescriptor;
        while (super) {
            if (!can_read(super + 0x28, sizeof(uintptr_t)))
                break;

            uintptr_t propertiesStart = *reinterpret_cast<uintptr_t*>(super + 0x28);
            if (propertiesStart) {
                for (uint32_t i = 0; i < 512; ++i) {
                    uintptr_t entry = propertiesStart + (i * 0x10);
                    if (!can_read(entry, sizeof(uintptr_t)))
                        break;

                    uintptr_t prop = *reinterpret_cast<uintptr_t*>(entry);
                    if (!prop)
                        continue;

                    uintptr_t namePtr = *reinterpret_cast<uintptr_t*>(prop + 0x8);
                    if (!namePtr || !can_read(namePtr, 1))
                        continue;

                    const char* name = reinterpret_cast<const char*>(namePtr);
                    if (name && _stricmp(name, propName) == 0)
                        return prop;
                }
            }

            if (!can_read(super + 0x8, sizeof(uintptr_t)))
                break;
            uintptr_t parent = *reinterpret_cast<uintptr_t*>(super + 0x8);
            if (!parent || parent == super)
                break;
            super = parent;
        }

        return 0;
    }


    inline void TrackCallbackValue(lua_State* L, int instanceIndex, int propertyIndex, int valueIndex)
    {
        if (!L || !lua_isuserdata(L, instanceIndex) || !lua_isstring(L, propertyIndex) ||
            !lua_isfunction(L, valueIndex))
            return;

        uintptr_t instance = 0;
        void* userdata = lua_touserdata(L, instanceIndex);
        if (!userdata || !can_read(reinterpret_cast<uintptr_t>(userdata)) ||
            !(instance = *reinterpret_cast<uintptr_t*>(userdata)))
            return;

        const char* property = lua_tostring(L, propertyIndex);
        if (!property || !property[0])
            return;

        lua_pushvalue(L, valueIndex);
        const int functionRef = lua_ref(L, -1);
        lua_pop(L, 1);
        callback_values[instance][property] = {
            functionRef,
            SharedVariables::StateGeneration.load()
        };
    }


    inline bool can_read(uintptr_t address, size_t size) noexcept
    {
        if (address < 0x10000)
            return false;

        MEMORY_BASIC_INFORMATION mbi = {};
        if (VirtualQuery(reinterpret_cast<void*>(address), &mbi, sizeof(mbi)) == 0)
            return false;

        if (mbi.State != MEM_COMMIT || (mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD)))
            return false;

        uintptr_t regionEnd = reinterpret_cast<uintptr_t>(mbi.BaseAddress) + mbi.RegionSize;
        return address + size >= address && address + size <= regionEnd;
    }

    inline uintptr_t seh_read_ptr(uintptr_t addr) noexcept {
        __try { return *reinterpret_cast<uintptr_t*>(addr); }
        __except (EXCEPTION_EXECUTE_HANDLER) { return 0; }
    }
    inline bool seh_write_u32(uintptr_t addr, uint32_t val) noexcept {
        __try { *reinterpret_cast<uint32_t*>(addr) = val; return true; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }
    inline uint32_t seh_read_u32(uintptr_t addr) noexcept {
        __try { return *reinterpret_cast<uint32_t*>(addr); }
        __except (EXCEPTION_EXECUTE_HANDLER) { return 0; }
    }

    template<typename T>
    static bool read_value(std::uintptr_t address, T& result)
    {
        static_assert(std::is_trivially_copyable_v<T>);

        if (!address || !can_read(address, sizeof(T)))
            return false;

        std::memcpy(&result, reinterpret_cast<const void*>(address), sizeof(T));
        return true;
    }

    inline bool resolve_property(lua_State* L, uintptr_t& out_instance, uintptr_t& out_prop)
    {
        out_instance = 0;
        out_prop = 0;

        void* userdata = lua_touserdata(L, 1);
        if (!userdata || !can_read(reinterpret_cast<uintptr_t>(userdata)))
            return false;

        out_instance = *reinterpret_cast<uintptr_t*>(userdata);
        if (!out_instance || !can_read(out_instance + Offsets::Instance::ClassDescriptor))
            return false;

        const char* prop_name = lua_tostring(L, 2);
        if (!prop_name)
            return false;

        uintptr_t class_desc = *reinterpret_cast<uintptr_t*>(out_instance + Offsets::Instance::ClassDescriptor);
        if (!class_desc || !can_read(class_desc + 472, sizeof(uintptr_t)))
            return false;

        uintptr_t name_key = 0;
        __try { name_key = Roblox::HashLookup(prop_name); }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
        if (!name_key)
            return false;

        uintptr_t result = 0;
        __try { result = Roblox::GetProperty(class_desc + 472, &name_key); }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }

        if (result)
        {
            uintptr_t prop_desc = seh_read_ptr(result);
            if (prop_desc && can_read(prop_desc + Offsets::Instance::PropertyDescriptorBitFlags, sizeof(uint32_t)))
            {
                out_prop = prop_desc;
                return true;
            }
        }

        return false;
    }

    inline bool read_scriptable_flag(uintptr_t prop) noexcept
    {
        if (!can_read(prop + Offsets::Instance::PropertyDescriptorBitFlags, sizeof(uint32_t)))
            return false;

        return seh_read_u32(prop + Offsets::Instance::PropertyDescriptorBitFlags) & 0x10;
    }

    inline void write_scriptable_flag(uintptr_t prop, bool state) noexcept
    {
        if (!can_read(prop + Offsets::Instance::PropertyDescriptorBitFlags, sizeof(uint32_t)))
            return;

        uint32_t flags = seh_read_u32(prop + Offsets::Instance::PropertyDescriptorBitFlags);
        seh_write_u32(prop + Offsets::Instance::PropertyDescriptorBitFlags, (flags & ~0x10u) | (state ? 0x10u : 0));
    }

    inline void ResetLibraryState()
    {
        for (auto& [prop, wasScriptable] : original_scriptable_flags)
        {
            write_scriptable_flag(prop, wasScriptable);
        }
        scriptable_overrides.clear();
        original_scriptable_flags.clear();
        callback_values.clear();
    }

    inline int isscriptable(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TUSERDATA);
        luaL_checktype(L, 2, LUA_TSTRING);

        uintptr_t inst, prop;
        if (!resolve_property(L, inst, prop)) {
            lua_pushboolean(L, false);
            return 1;
        }

        if (!prop) {
            lua_pushboolean(L, false);
            return 1;
        }

        auto instIt = scriptable_overrides.find(inst);
        if (instIt != scriptable_overrides.end()) {
            auto propIt = instIt->second.find(prop);
            if (propIt != instIt->second.end()) {
                lua_pushboolean(L, propIt->second);
                return 1;
            }
        }

        auto origIt = original_scriptable_flags.find(prop);
        if (origIt != original_scriptable_flags.end()) {
            lua_pushboolean(L, origIt->second);
            return 1;
        }

        lua_pushboolean(L, read_scriptable_flag(prop));
        return 1;
    }

    inline int setscriptable(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TUSERDATA);
        luaL_checktype(L, 2, LUA_TSTRING);
        luaL_checktype(L, 3, LUA_TBOOLEAN);

        uintptr_t inst, prop;
        if (!resolve_property(L, inst, prop)) {
            lua_pushboolean(L, false);
            return 1;
        }

        if (!prop) {
            lua_pushboolean(L, false);
            return 1;
        }

        bool wasScriptable;
        auto origItSS = original_scriptable_flags.find(prop);
        if (origItSS != original_scriptable_flags.end())
            wasScriptable = origItSS->second;
        else {
            wasScriptable = read_scriptable_flag(prop);
            original_scriptable_flags[prop] = wasScriptable;
        }

        bool state = lua_toboolean(L, 3) != 0;

        write_scriptable_flag(prop, state);

        scriptable_overrides[inst][prop] = state;

        lua_pushboolean(L, wasScriptable);
        return 1;
    }

    namespace Checker {
        static bool CheckPointer(uintptr_t Address) {
            __try {
                if (Address < 0x10000) {
                    return false;
                }

                MEMORY_BASIC_INFORMATION MemoryInfo = {};
                if (VirtualQuery(reinterpret_cast<LPCVOID>(Address), &MemoryInfo, sizeof(MemoryInfo)) == 0) {
                    return false;
                }

                if (MemoryInfo.State != MEM_COMMIT) {
                    return false;
                }

                if (MemoryInfo.Protect & (PAGE_GUARD | PAGE_NOACCESS)) {
                    return false;
                }

                return (MemoryInfo.Protect & (PAGE_READONLY | PAGE_READWRITE | PAGE_WRITECOPY |
                    PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY)) != 0;
            }
            __except (EXCEPTION_EXECUTE_HANDLER) {
                return false;
            }
        }
    }

    inline int get_property_type(uintptr_t prop) {
        uintptr_t ttype = seh_read_ptr(prop + 0x68);
        if (!ttype || !Checker::CheckPointer(ttype))
            return -1;
        return *reinterpret_cast<int*>(ttype + 0x30);
    }

    inline uintptr_t get_property_getter(uintptr_t prop) {
        uintptr_t get_set_impl = seh_read_ptr(prop + 0x90);
        if (!get_set_impl || !Checker::CheckPointer(get_set_impl))
            return 0;

        uintptr_t get_set_vft = seh_read_ptr(get_set_impl);
        if (!get_set_vft || !Checker::CheckPointer(get_set_vft))
            return 0;

        return seh_read_ptr(get_set_vft + 0x18);
    }

    inline uintptr_t get_property_setter(uintptr_t prop) {
        uintptr_t get_set_impl = seh_read_ptr(prop + 0x90);
        if (!get_set_impl || !Checker::CheckPointer(get_set_impl))
            return 0;

        uintptr_t get_set_vft = seh_read_ptr(get_set_impl);
        if (!get_set_vft || !Checker::CheckPointer(get_set_vft))
            return 0;

        return seh_read_ptr(get_set_vft + 0x20);
    }

    typedef void(__fastcall* BinaryStringGetter)(uintptr_t, void*, uintptr_t);
    typedef void(__fastcall* BinaryStringSetter)(uintptr_t, void*, uintptr_t);

    inline int protected_getfield(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TUSERDATA);
        const char* property = luaL_checkstring(L, 2);
        lua_getfield(L, 1, property);
        return 1;
    }

    inline int protected_setfield(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TUSERDATA);
        const char* property = luaL_checkstring(L, 2);
        luaL_checkany(L, 3);
        lua_pushvalue(L, 3);
        lua_setfield(L, 1, property);
        return 0;
    }

    inline bool push_property_value(lua_State* L, int instanceIndex, int propertyIndex)
    {
        instanceIndex = lua_absindex(L, instanceIndex);
        propertyIndex = lua_absindex(L, propertyIndex);
        const int top = lua_gettop(L);

        lua_pushcfunction(L, protected_getfield, "gethiddenproperty_get");
        lua_pushvalue(L, instanceIndex);
        lua_pushvalue(L, propertyIndex);

        if (lua_pcall(L, 2, 1, 0) != LUA_OK)
        {
            lua_settop(L, top);
            return false;
        }

        return true;
    }

    inline bool push_tags_fallback(lua_State* L, int instanceIndex)
    {
        instanceIndex = lua_absindex(L, instanceIndex);
        const int top = lua_gettop(L);

        lua_getfield(L, instanceIndex, "GetTags");
        if (!lua_isfunction(L, -1))
        {
            lua_settop(L, top);
            return false;
        }

        lua_pushvalue(L, instanceIndex);
        if (lua_pcall(L, 1, 1, 0) != LUA_OK)
        {
            lua_settop(L, top);
            return false;
        }

        return true;
    }

    inline bool set_property_value(lua_State* L, int instanceIndex, int propertyIndex, int valueIndex)
    {
        instanceIndex = lua_absindex(L, instanceIndex);
        propertyIndex = lua_absindex(L, propertyIndex);
        valueIndex = lua_absindex(L, valueIndex);
        const int top = lua_gettop(L);

        lua_pushcfunction(L, protected_setfield, "sethiddenproperty_set");
        lua_pushvalue(L, instanceIndex);
        lua_pushvalue(L, propertyIndex);
        lua_pushvalue(L, valueIndex);

        if (lua_pcall(L, 3, 0, 0) != LUA_OK)
        {
            lua_settop(L, top);
            return false;
        }

        lua_settop(L, top);
        return true;
    }

    inline bool call_string_getter_seh(uintptr_t getter_addr, void* getset, void* inst, std::string* output)
    {
        using Fn = void(__fastcall*)(void*, void*, void*);
        __try
        {
            reinterpret_cast<Fn>(getter_addr)(getset, output, inst);
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            return false;
        }
        return true;
    }

    inline bool call_content_getter_seh(uintptr_t getter_addr, void* getset, void* inst, std::string& output)
    {
        using Fn = void(__fastcall*)(void*, void*, void*);
        void* obj = nullptr;
        __try
        {
            reinterpret_cast<Fn>(getter_addr)(getset, &obj, inst);
            uintptr_t base = reinterpret_cast<uintptr_t>(obj);
            if (!base || !Checker::CheckPointer(base + 0x28))
                return false;

            size_t size = *reinterpret_cast<size_t*>(base + 0x20);
            size_t cap = *reinterpret_cast<size_t*>(base + 0x28);
            const char* data = (cap > 0xF)
                ? *reinterpret_cast<const char**>(base + 0x10)
                : reinterpret_cast<const char*>(base + 0x10);
            if (!data)
                return false;
            output.assign(data, size);
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            return false;
        }
        return true;
    }

    inline bool push_property_value_direct_impl(lua_State* L, void* getset, void* inst, uintptr_t getter_addr, int prop_type)
    {
        __try
        {
            switch (prop_type)
            {
            case 1:
            {
                using Fn = bool(__fastcall*)(void*, void*);
                lua_pushboolean(L, reinterpret_cast<Fn>(getter_addr)(getset, inst) ? 1 : 0);
                return true;
            }
            case 2:
            {
                using Fn = int(__fastcall*)(void*, void*);
                lua_pushinteger(L, reinterpret_cast<Fn>(getter_addr)(getset, inst));
                return true;
            }
            case 4:
            {
                using Fn = float(__fastcall*)(void*, void*);
                lua_pushnumber(L, reinterpret_cast<Fn>(getter_addr)(getset, inst));
                return true;
            }
            case 5:
            {
                using Fn = double(__fastcall*)(void*, void*);
                lua_pushnumber(L, reinterpret_cast<Fn>(getter_addr)(getset, inst));
                return true;
            }
            case 29:
            {
                using Fn = void(__fastcall*)(void*, void*, void*);
                uint64_t tmp = 0;
                reinterpret_cast<Fn>(getter_addr)(getset, &tmp, inst);
                lua_pushinteger(L, static_cast<int>(static_cast<uint32_t>(tmp)));
                return true;
            }
            }
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
        }
        return false;
    }

    inline bool push_property_value_direct(lua_State* L, uintptr_t instance, uintptr_t prop_desc)
    {
        uintptr_t getter_addr = get_property_getter(prop_desc);
        if (!getter_addr)
            return false;

        int prop_type = get_property_type(prop_desc);
        if (prop_type < 0)
            return false;

        uintptr_t get_set_impl = seh_read_ptr(prop_desc + 0x90);
        if (!get_set_impl || !Checker::CheckPointer(get_set_impl))
            return false;

        void* getset = reinterpret_cast<void*>(get_set_impl);
        void* inst = reinterpret_cast<void*>(instance);

        if (prop_type == 6)
        {
            std::string str_result;
            if (!call_string_getter_seh(getter_addr, getset, inst, &str_result))
                return false;
            lua_pushlstring(L, str_result.c_str(), str_result.size());
            return true;
        }

        if (prop_type == 63)
        {
            std::string str_result;
            if (!call_content_getter_seh(getter_addr, getset, inst, str_result))
                return false;
            lua_pushlstring(L, str_result.c_str(), str_result.size());
            return true;
        }

        return push_property_value_direct_impl(L, getset, inst, getter_addr, prop_type);
    }

    struct ScopedFlagGuard
    {
        uintptr_t prop_desc = 0;
        uint32_t saved_flags = 0;
        bool active = false;

        void arm(uintptr_t prop)
        {
            if (!can_read(prop + Offsets::Instance::PropertyDescriptorBitFlags, sizeof(uint32_t)))
                return;
            saved_flags = seh_read_u32(prop + Offsets::Instance::PropertyDescriptorBitFlags);
            if (!seh_write_u32(prop + Offsets::Instance::PropertyDescriptorBitFlags, 0x10))
                return;
            prop_desc = prop;
            active = true;
        }

        void disarm()
        {
            if (!active) return;
            seh_write_u32(prop_desc + Offsets::Instance::PropertyDescriptorBitFlags, saved_flags);
            active = false;
        }

        ~ScopedFlagGuard() { disarm(); }
    };

    inline int gethiddenproperty(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TUSERDATA);
        luaL_checktype(L, 2, LUA_TSTRING);

        uintptr_t inst, prop;
        if (!resolve_property(L, inst, prop)) {
            lua_pushnil(L);
            lua_pushboolean(L, false);
            return 2;
        }

        if (!prop) {
            lua_pushnil(L);
            lua_pushboolean(L, false);
            return 2;
        }

        const char* prop_name = lua_tostring(L, 2);
        if (!prop_name) {
            lua_pushnil(L);
            lua_pushboolean(L, false);
            return 2;
        }

        bool wasScriptable;
        auto origIt = original_scriptable_flags.find(prop);
        if (origIt != original_scriptable_flags.end())
            wasScriptable = origIt->second;
        else
            wasScriptable = read_scriptable_flag(prop);

        if (push_property_value_direct(L, inst, prop))
        {
            lua_pushboolean(L, !wasScriptable);
            return 2;
        }

        if (!wasScriptable)
        {
            ScopedFlagGuard guard;
            guard.arm(prop);

            if (guard.active)
            {
                lua_pushcfunction(L, protected_getfield, "gethiddenproperty");
                lua_pushvalue(L, 1);
                lua_pushstring(L, prop_name);

                if (lua_pcall(L, 2, 1, 0) != LUA_OK)
                {
                    lua_pop(L, 1);
                    guard.disarm();
                    lua_pushnil(L);
                    lua_pushboolean(L, !wasScriptable);
                    return 2;
                }

                if (lua_isnil(L, -1))
                {
                    lua_pop(L, 1);
                    std::string getter = "Get";
                    getter += prop_name;
                    lua_getfield(L, 1, getter.c_str());
                    if (lua_isfunction(L, -1))
                    {
                        lua_pushvalue(L, 1);
                        if (lua_pcall(L, 1, 1, 0) != LUA_OK)
                        {
                            lua_pop(L, 1);
                            lua_pushnil(L);
                        }
                    }
                    else
                    {
                        lua_pop(L, 1);
                        lua_pushnil(L);
                    }
                }

                guard.disarm();
                lua_pushboolean(L, !wasScriptable);
                return 2;
            }
        }

        lua_getfield(L, 1, prop_name);
        if (lua_isnil(L, -1))
        {
            lua_pop(L, 1);
            std::string getter = "Get";
            getter += prop_name;
            lua_getfield(L, 1, getter.c_str());
            if (lua_isfunction(L, -1))
            {
                lua_pushvalue(L, 1);
                if (lua_pcall(L, 1, 1, 0) != LUA_OK)
                {
                    lua_pop(L, 1);
                    lua_pushnil(L);
                }
            }
            else
            {
                lua_pop(L, 1);
                lua_pushnil(L);
            }
        }

        lua_pushboolean(L, !wasScriptable);
        return 2;
    }

    inline int sethiddenproperty(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TUSERDATA);
        luaL_checktype(L, 2, LUA_TSTRING);
        luaL_checkany(L, 3);

        uintptr_t inst, prop;
        if (!resolve_property(L, inst, prop) || !prop) {
            lua_pushboolean(L, false);
            return 1;
        }

        bool wasScriptable;
        auto origIt2 = original_scriptable_flags.find(prop);
        if (origIt2 != original_scriptable_flags.end())
            wasScriptable = origIt2->second;
        else
            wasScriptable = read_scriptable_flag(prop);

        ScopedFlagGuard guard;
        if (!wasScriptable)
            guard.arm(prop);

        const char* prop_name = lua_tostring(L, 2);
        bool didSet = prop_name && set_property_value(L, 1, 2, 3);

        guard.disarm();

        lua_pushboolean(L, didSet && !wasScriptable);
        return 1;
    }

    int getcallbackvalue(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TUSERDATA);
        luaL_checktype(L, 2, LUA_TSTRING);

        std::uintptr_t TrackedInstance = 0;
        void* userdata = lua_touserdata(L, 1);

        if (userdata)
            read_value(reinterpret_cast<std::uintptr_t>(userdata), TrackedInstance);

        const char* PropertyName = lua_tostring(L, 2);

        if (TrackedInstance && PropertyName)
        {
            const auto InstanceIt = callback_values.find(TrackedInstance);

            if (InstanceIt != callback_values.end())
            {
                const auto CallbackIt = InstanceIt->second.find(PropertyName);

                if (CallbackIt != InstanceIt->second.end() &&
                    CallbackIt->second.Generation == SharedVariables::StateGeneration.load())
                {
                    lua_getref(L, CallbackIt->second.FunctionRef);

                    if (lua_isfunction(L, -1))
                        return 1;

                    lua_pop(L, 1);
                }
            }
        }

        std::uintptr_t instance = 0;
        std::uintptr_t descriptor = 0;

        if (!resolve_property(L, instance, descriptor))
            luaL_argerror(L, 2, "callback property does not exist");

        constexpr std::uintptr_t CallbackOffsetInDescriptor = 0x80;
        constexpr std::uintptr_t HolderSelfOffset = 0x38;
        constexpr std::uintptr_t CallbackOwnerOffset = 0x18;
        constexpr std::uintptr_t CallbackFunctionOffset = 0x38;
        constexpr std::uintptr_t LiveThreadRefOffset = 0x18;
        constexpr std::uintptr_t FunctionRefIdOffset = 0x34;

        constexpr std::uintptr_t AlternateBackPointerOffset = 0x190;
        constexpr std::uintptr_t AlternateHolderAdjustment = 0x1C8;

        std::int32_t relative = 0;

        if (!read_value(descriptor + CallbackOffsetInDescriptor, relative) || relative == 0)
        {
            lua_pushnil(L);
            return 1;
        }

        std::uintptr_t holder = static_cast<std::uintptr_t>(static_cast<std::intptr_t>(instance) + static_cast<std::intptr_t>(relative));

        std::uintptr_t HolderSelf = 0;

        if (!read_value(holder + HolderSelfOffset, HolderSelf))
        {
            lua_pushnil(L);
            return 1;
        }

        if (!HolderSelf || HolderSelf != holder)
        {
            if (holder < AlternateHolderAdjustment)
            {
                lua_pushnil(L);
                return 1;
            }

            std::uintptr_t AlternateSelf = 0;

            if (holder < AlternateBackPointerOffset ||
                !read_value(holder - AlternateBackPointerOffset, AlternateSelf) || !AlternateSelf)
            {
                lua_pushnil(L);
                return 1;
            }

            holder -= AlternateHolderAdjustment;

            if (AlternateSelf != holder)
            {
                lua_pushnil(L);
                return 1;
            }
        }

        std::uintptr_t owner = 0;
        std::uintptr_t callback = 0;
        std::uintptr_t liveThreadRef = 0;
        std::uint32_t functionRef = 0;

        if (!read_value(
            holder + CallbackOwnerOffset,
            owner) ||
            !owner ||
            !read_value(owner + CallbackFunctionOffset, callback) || !callback || !read_value(callback + LiveThreadRefOffset, liveThreadRef) || !liveThreadRef || !read_value(liveThreadRef + FunctionRefIdOffset, functionRef) ||
            functionRef == 0)
        {
            lua_pushnil(L);
            return 1;
        }

        lua_getref(L, static_cast<int>(functionRef));

        if (!lua_isfunction(L, -1))
        {
            lua_pop(L, 1);
            lua_pushnil(L);
        }

        return 1;
    }


    inline void RegisterLibrary(lua_State* L)
    {
        if (!L) return;

        Utils::AddFunction(L, "isscriptable", isscriptable);
        Utils::AddFunction(L, "setscriptable", setscriptable);
        Utils::AddFunction(L, "getcallbackvalue", getcallbackvalue);
        Utils::AddFunction(L, "getcallbackmember", getcallbackvalue);
        Utils::AddFunction(L, "gethiddenproperty", gethiddenproperty);
        Utils::AddFunction(L, "sethiddenproperty", sethiddenproperty);
    }
}