#pragma once

#include <Windows.h>
#include <lstate.h>
#include <lgc.h>
#include <lualib.h>
#include <string>
#include <sstream>
#include <map>
#include <unordered_map>
#include <unordered_set>
#include <bitset>
#include <vector>
#include <cmath>
#include <wininet.h>
#include <urlmon.h>
#include <cpr/cpr.h>
#include <luacode.h>
#include <winhttp.h>
#include <zstd/xxhash.h>
#include <zstd/zstd.h>
#include <Main/Environment/Libraries/Closures/Closures.hpp>

#pragma comment(lib, "zstd_static.lib")

#include <Utils.hpp>
#include <Globals.hpp> 
#include <Main/Yield/Yield.hpp> 
#include <Roblox/Offsets.hpp>
#include <Exploit/TaskScheduler/TaskScheduler.hpp>
#include <lmem.h>
#include <ltable.h>

#pragma comment(lib, "wininet.lib")
#pragma comment(lib, "urlmon.lib")
#pragma comment(lib, "winhttp.lib")

static LuaTable* RenvCache = nullptr;
static lua_State* RenvCacheState = nullptr;

typedef void(__fastcall* PushInstanceWeakPtrT)(lua_State* L, std::weak_ptr<uintptr_t>);

namespace HelperFuncs
{
    __forceinline bool CheckMemory(uintptr_t address) {
        if (address < 0x10000 || address > 0x7FFFFFFFFFFF) {
            return false;
        }

        MEMORY_BASIC_INFORMATION mbi;
        if (VirtualQuery(reinterpret_cast<void*>(address), &mbi, sizeof(mbi)) == 0) {
            return false;
        }

        if (mbi.Protect & PAGE_NOACCESS || mbi.State != MEM_COMMIT) {
            return false;
        }

        return true;
    }
}

namespace Script
{
    inline int ScriptError(lua_State* L, const char* message)
    {
        const char* error = message ? message : OBF("script error");
        int top = lua_gettop(L);
        lua_getglobal(L, ENV_OBF("error"));
        if (lua_isfunction(L, -1))
        {
            lua_pushstring(L, error);
            lua_call(L, 1, 0);
            return 0;
        }

        lua_settop(L, top);
        lua_pushnil(L);
        lua_pushstring(L, error);
        return 2;
    }

    inline uint32_t Rotl32(uint32_t value, int shift)
    {
        return (value << shift) | (value >> (32 - shift));
    }

    inline uint32_t XXHash32(const uint8_t* data, size_t len, uint32_t seed)
    {
        constexpr uint32_t Prime1 = 2654435761U;
        constexpr uint32_t Prime2 = 2246822519U;
        constexpr uint32_t Prime3 = 3266489917U;
        constexpr uint32_t Prime4 = 668265263U;
        constexpr uint32_t Prime5 = 374761393U;

        const uint8_t* ptr = data;
        const uint8_t* end = data + len;
        uint32_t h32 = 0;

        auto read32 = [](const uint8_t* p) -> uint32_t {
            return uint32_t(p[0]) | (uint32_t(p[1]) << 8) | (uint32_t(p[2]) << 16) | (uint32_t(p[3]) << 24);
            };

        if (len >= 16)
        {
            const uint8_t* limit = end - 16;
            uint32_t v1 = seed + Prime1 + Prime2;
            uint32_t v2 = seed + Prime2;
            uint32_t v3 = seed;
            uint32_t v4 = seed - Prime1;

            do
            {
                v1 = Rotl32(v1 + read32(ptr) * Prime2, 13) * Prime1; ptr += 4;
                v2 = Rotl32(v2 + read32(ptr) * Prime2, 13) * Prime1; ptr += 4;
                v3 = Rotl32(v3 + read32(ptr) * Prime2, 13) * Prime1; ptr += 4;
                v4 = Rotl32(v4 + read32(ptr) * Prime2, 13) * Prime1; ptr += 4;
            } while (ptr <= limit);

            h32 = Rotl32(v1, 1) + Rotl32(v2, 7) + Rotl32(v3, 12) + Rotl32(v4, 18);
        }
        else
        {
            h32 = seed + Prime5;
        }

        h32 += static_cast<uint32_t>(len);

        while (ptr + 4 <= end)
        {
            h32 = Rotl32(h32 + read32(ptr) * Prime3, 17) * Prime4;
            ptr += 4;
        }

        while (ptr < end)
        {
            h32 = Rotl32(h32 + (*ptr) * Prime5, 11) * Prime1;
            ++ptr;
        }

        h32 ^= h32 >> 15;
        h32 *= Prime2;
        h32 ^= h32 >> 13;
        h32 *= Prime3;
        h32 ^= h32 >> 16;
        return h32;
    }

    inline bool ReadProtectedString(uintptr_t address, std::string& out)
    {
        out.clear();
        if (!HelperFuncs::CheckMemory(address + 0x28))
            return false;

        uintptr_t data = *reinterpret_cast<uintptr_t*>(address + 0x10);
        size_t len = *reinterpret_cast<size_t*>(address + 0x20);
        if (len == 0 || len > 64 * 1024 * 1024)
            return false;

        if (!HelperFuncs::CheckMemory(data) || !HelperFuncs::CheckMemory(data + len - 1))
            return false;

        out.assign(reinterpret_cast<const char*>(data), len);
        return true;
    }

    inline bool DecodeCompressedBytecode(const std::string& compressed, std::string& output, std::string& error)
    {
        output.clear();
        error.clear();

        if (compressed.size() < 8)
        {
            error = std::string(OBF("Compressed data too short"));
            return false;
        }

        std::vector<uint8_t> data(compressed.begin(), compressed.end());
        uint8_t key[4] = {
            static_cast<uint8_t>(data[0] ^ 0x52),
            static_cast<uint8_t>((data[1] ^ 0x53) - 41),
            static_cast<uint8_t>((data[2] ^ 0x42) - 82),
            static_cast<uint8_t>((data[3] ^ 0x31) - 123),
        };

        for (size_t i = 0; i < data.size(); ++i)
            data[i] ^= static_cast<uint8_t>(key[i & 3] + 41 * i);

        uint32_t expectedHash = uint32_t(key[0]) | (uint32_t(key[1]) << 8) | (uint32_t(key[2]) << 16) | (uint32_t(key[3]) << 24);
        uint32_t actualHash = XXH32(data.data(), data.size(), 42);
        if (actualHash != expectedHash)
        {
            error = std::string(OBF("Hash mismatch during decompression"));
            return false;
        }

        uint32_t decompressedSize =
            uint32_t(data[4]) | (uint32_t(data[5]) << 8) | (uint32_t(data[6]) << 16) | (uint32_t(data[7]) << 24);
        if (decompressedSize == 0 || decompressedSize > 64 * 1024 * 1024)
        {
            error = std::string(OBF("Invalid decompressed size"));
            return false;
        }

        output.resize(decompressedSize);
        size_t result = ZSTD_decompress(output.data(), output.size(), data.data() + 8, data.size() - 8);
        if (ZSTD_isError(result))
        {
            error = std::string(OBF("ZSTD decompression error: ")) + ZSTD_getErrorName(result);
            output.clear();
            return false;
        }

        output.resize(result);
        return true;
    }

    inline bool GetInstanceClassName(lua_State* L, int index, std::string& className)
    {
        int top = lua_gettop(L);
        lua_getfield(L, index, ENV_OBF("ClassName"));
        if (!lua_isstring(L, -1))
        {
            lua_settop(L, top);
            return false;
        }

        const char* value = lua_tostring(L, -1);
        className = value ? value : "";
        lua_settop(L, top);
        return true;
    }

    inline std::string read_bytecode(uintptr_t addr) {
        uintptr_t str = addr + 0x10;
        size_t len = *(size_t*)(str + 0x10);
        size_t cap = *(size_t*)(str + 0x18);
        uintptr_t data_ptr = (cap > 0x0f) ? *(uintptr_t*)(str + 0x00) : str;
        return std::string(reinterpret_cast<const char*>(data_ptr), len);
    }

    inline std::map<void*, std::string> ScriptHashes;

    bool IsValidScriptClass(const char* className)
    {
        if (!className) return false;
        return strcmp(className, ENV_OBF("LocalScript")) == 0 ||
            strcmp(className, ENV_OBF("ModuleScript")) == 0 ||
            strcmp(className, ENV_OBF("Script")) == 0;
    }

    inline std::string Blake2Hash(const char* data, size_t len)
    {
        if (!data || len == 0) return std::string(96, '0');

        uint64_t h[8] = {
            0x6a09e667f3bcc908ULL, 0xbb67ae8584caa73bULL,
            0x3c6ef372fe94f82bULL, 0xa54ff53a5f1d36f1ULL,
            0x510e527fade682d1ULL, 0x9b05688c2b3e6c1fULL,
            0x1f83d9abfb41bd6bULL, 0x5be0cd19137e2179ULL
        };

        for (size_t i = 0; i < len; i++) {
            uint64_t val = static_cast<unsigned char>(data[i]);
            h[i % 8] ^= val;
            h[i % 8] = (h[i % 8] << 7) | (h[i % 8] >> 57);
            h[(i + 1) % 8] += val;
        }

        for (int round = 0; round < 12; round++) {
            for (int i = 0; i < 8; i++) {
                h[i] ^= h[(i + 1) % 8];
                h[i] = (h[i] << 13) | (h[i] >> 51);
            }
        }

        char output[97];
        for (int i = 0; i < 6; i++) {
            sprintf_s(output + (i * 16), 17, OBF("%016llx"), h[i]);
        }
        output[96] = '\0';

        return std::string(output);
    }

    inline int getscriptbytecode(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TUSERDATA);

        std::string className;
        if (!GetInstanceClassName(L, 1, className))
            return ScriptError(L, OBF("Invalid Instance"));

        if (className != OBF("ModuleScript") && className != OBF("LocalScript") &&
            className != OBF("Script") && className != OBF("CoreScript"))
            return ScriptError(L, OBF("Script expected"));

        uintptr_t instance = *reinterpret_cast<uintptr_t*>(lua_touserdata(L, 1));
        if (!HelperFuncs::CheckMemory(instance + 0x1B0))
        {
            lua_pushnil(L);
            return 1;
        }

        uintptr_t holder = 0;
        if (className == OBF("ModuleScript"))
            holder = *reinterpret_cast<uintptr_t*>(instance + Offsets::Scripts::ModuleScriptByteCode);
        else
            holder = *reinterpret_cast<uintptr_t*>(instance + Offsets::Scripts::LocalScriptByteCode);

        if (!HelperFuncs::CheckMemory(holder + 0x28))
        {
            lua_pushnil(L);
            return 1;
        }

        std::string compressed;
        if (!ReadProtectedString(holder, compressed))
        {
            lua_pushnil(L);
            return 1;
        }

        std::string bytecode;
        std::string error;
        if (!DecodeCompressedBytecode(compressed, bytecode, error))
        {
            lua_pushnil(L);
            return 1;
        }

        lua_pushlstring(L, bytecode.data(), bytecode.size());
        return 1;
    }

    static int getscripthash(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TUSERDATA);
        void* userdata_block = lua_touserdata(L, 1);
        uintptr_t script_pointer = userdata_block ? *(uintptr_t*)userdata_block : 0;
        if (!script_pointer) { lua_pushnil(L); return 1; }

        lua_getfield(L, 1, ENV_OBF("ClassName"));
        std::string className = lua_tostring(L, -1);
        lua_pop(L, 1);

        uintptr_t protectedString = 0;
        if (className == OBF("ModuleScript")) {
            protectedString = *reinterpret_cast<uintptr_t*>(script_pointer + Offsets::Scripts::ModuleScriptByteCode);
        }
        else {
            protectedString = *reinterpret_cast<uintptr_t*>(script_pointer + Offsets::Scripts::LocalScriptByteCode);
        }

        if (!protectedString) { lua_pushnil(L); return 1; }
        std::string raw = read_bytecode(protectedString);
        if (raw.empty()) { lua_pushnil(L); return 1; }

        std::string h = Blake2Hash(raw.data(), raw.size());
        if (h.empty()) { lua_pushnil(L); return 1; }
        lua_pushlstring(L, h.data(), h.size());
        return 1;
    }

    inline bool IsModuleScriptValue(lua_State* L, int index)
    {
        if (!lua_isuserdata(L, index))
            return false;

        index = lua_absindex(L, index);
        const int top = lua_gettop(L);

        lua_getfield(L, index, ENV_OBF("ClassName"));
        const bool isModule = lua_isstring(L, -1) &&
            strcmp(lua_tostring(L, -1), ENV_OBF("ModuleScript")) == 0;

        lua_settop(L, top);
        return isModule;
    }

    int getloadedmodules(lua_State* L) {
        lua_normalisestack(L, 0);
        lua_newtable(L);
        const int candidateTable = lua_gettop(L);

        struct GCOContext {
            lua_State* pLua;
            int itemsFound;
            int tableIndex;
            std::unordered_map<uintptr_t, bool> map;
        } gcCtx{ L, 0, candidateTable };

        const auto oldThreshold = L->global->GCthreshold;
        L->global->GCthreshold = SIZE_MAX;

        luaM_visitgco(L, &gcCtx, [](void* ctx, lua_Page*, GCObject* pGcObj) -> bool {
            auto* c = static_cast<GCOContext*>(ctx);
            auto* cL = c->pLua;

            if (isdead(cL->global, pGcObj)) return false;
            if (pGcObj->gch.tt != LUA_TFUNCTION) return false;

            Closure* closure = gco2cl(pGcObj);
            if (Closures::IsExecutorClosure(closure))
                return false;

            cL->top->value.gc = pGcObj;
            cL->top->tt = LUA_TFUNCTION;
            ++cL->top;

            lua_getfenv(cL, -1);
            if (!lua_isnil(cL, -1)) {
                    lua_getfield(cL, -1, ENV_OBF("script"));
                if (lua_isuserdata(cL, -1)) {
                    void* script_userdata = lua_touserdata(cL, -1);
                    uintptr_t script_addr = script_userdata ?
                        *reinterpret_cast<uintptr_t*>(script_userdata) : 0;

                    if (script_addr && IsModuleScriptValue(cL, -1) &&
                        c->map.emplace(script_addr, true).second) {
                        lua_rawseti(cL, c->tableIndex, ++c->itemsFound);
                    }
                    else {
                        lua_pop(cL, 1);
                    }
                }
                else lua_pop(cL, 1);
            }
            lua_pop(cL, 2);
            return false;
            });

        L->global->GCthreshold = oldThreshold;
        return 1;
    }




    __forceinline int getscripts(lua_State* L) {
        struct instancecontext {
            lua_State* L;
            int n;
        } Context = { L, 0 };
        lua_createtable(L, 0, 0);
        const auto ullOldThreshold = L->global->GCthreshold;
        L->global->GCthreshold = SIZE_MAX;
        luaM_visitgco(L, &Context, [](void* ctx, lua_Page* page, GCObject* gco) -> bool {
            auto gCtx = static_cast<instancecontext*>(ctx);
            if (isdead(gCtx->L->global, gco)) return false;
            if (gco->gch.tt == LUA_TUSERDATA) {
                TValue* top = gCtx->L->top;
                top->value.p = reinterpret_cast<void*>(gco);
                top->tt = LUA_TUSERDATA;
                gCtx->L->top++;
                if (!strcmp(luaL_typename(gCtx->L, -1), ENV_OBF("Instance"))) {
                    lua_getfield(gCtx->L, -1, ENV_OBF("ClassName"));
                    const char* cls = lua_isstring(gCtx->L, -1) ? lua_tolstring(gCtx->L, -1, 0) : nullptr;
                    if (cls && (!strcmp(cls, ENV_OBF("LocalScript")) || !strcmp(cls, ENV_OBF("ModuleScript")) || !strcmp(cls, ENV_OBF("CoreScript")))) {
                        lua_pop(gCtx->L, 1);
                        gCtx->n++;
                        lua_rawseti(gCtx->L, -2, gCtx->n);
                    }
                    else if (cls && !strcmp(cls, ENV_OBF("Script"))) {
                        lua_pop(gCtx->L, 1);
                        lua_getfield(gCtx->L, -1, ENV_OBF("RunContext"));
                        if (lua_isuserdata(gCtx->L, -1) || lua_isstring(gCtx->L, -1)) {
                            lua_getfield(gCtx->L, -1, ENV_OBF("Name"));
                            const char* runContext = lua_isstring(gCtx->L, -1) ? lua_tostring(gCtx->L, -1) : nullptr;
                            lua_pop(gCtx->L, 1);
                            if (runContext && !strcmp(runContext, ENV_OBF("Client"))) {
                                lua_pop(gCtx->L, 1);
                                gCtx->n++;
                                lua_rawseti(gCtx->L, -2, gCtx->n);
                            }
                            else {
                                lua_pop(gCtx->L, 2);
                            }
                        }
                        else {
                            lua_pop(gCtx->L, 2);
                        }
                    }
                    else {
                        lua_pop(gCtx->L, 2);
                    }
                }
                else {
                    lua_pop(gCtx->L, 1);
                }
            }
            return true;
            });
        L->global->GCthreshold = ullOldThreshold;
        return 1;
    }

    uintptr_t GetInstancePropertyByName(const uintptr_t instance, const std::string& targetPropertyName)
    {
        const uintptr_t classDescriptor =
            *reinterpret_cast<uintptr_t*>(instance + 0x18);

        const uintptr_t propertiesStart =
            *reinterpret_cast<uintptr_t*>(classDescriptor + 0x28);

        for (uint32_t i = 0; i < 80; ++i)
        {
            const uintptr_t entry =
                propertiesStart + (i * 0x10);

            const uintptr_t prop =
                *reinterpret_cast<uintptr_t*>(entry);

            if (!prop)
                continue;

            const uintptr_t namePtr =
                *reinterpret_cast<uintptr_t*>(prop + 0x8);

            if (!namePtr)
                continue;

            const char* name =
                reinterpret_cast<const char*>(namePtr);

            if (name && targetPropertyName == name)
                return prop;
        }

        return 0;
    }

    inline void PushGCObjects(lua_State* L, bool includeTables)
    {
        lua_newtable(L);
        lua_newtable(L);

        lua_pushstring(L, OBF("kvs"));
        lua_setfield(L, -2, ENV_OBF("__mode"));
        lua_setmetatable(L, -2);

        typedef struct {
            lua_State* luaThread;
            bool includeTables;
            int itemsFound;
        } GCOContext;

        auto GCContext = GCOContext{ L, includeTables, 0 };

        const auto oldGCThreshold = L->global->GCthreshold;
        L->global->GCthreshold = SIZE_MAX;

        luaM_visitgco(L, &GCContext, [](void* ctx, lua_Page* page, GCObject* gcObj) -> bool {
            const auto context = static_cast<GCOContext*>(ctx);
            const auto luaThread = context->luaThread;

            if (isdead(luaThread->global, gcObj))
                return false;

            const auto gcObjectType = gcObj->gch.tt;
            if (gcObjectType == LUA_TFUNCTION || gcObjectType == LUA_TTHREAD || gcObjectType == LUA_TUSERDATA ||
                gcObjectType == LUA_TLIGHTUSERDATA || gcObjectType == LUA_TBUFFER ||
                (gcObjectType == LUA_TTABLE && context->includeTables)) {
                luaThread->top->value.gc = gcObj;
                luaThread->top->tt = gcObjectType;
                incr_top(luaThread);

                const auto newTableIndex = ++context->itemsFound;
                lua_rawseti(luaThread, -2, newTableIndex);
            }

            return false;
            });

        L->global->GCthreshold = oldGCThreshold;
    }

    inline int getgc(lua_State* L) {
        PushGCObjects(L, luaL_optboolean(L, 1, false));
        return 1;
    };

    namespace FilterGCUtils
    {
        inline bool lua_equal_tuff(lua_State* L, int a, int b)
        {
            const int ta = lua_type(L, a);
            const int tb = lua_type(L, b);

            if (ta != tb)
                return false;

            if (ta == LUA_TNUMBER)
            {
                const lua_Number na = lua_tonumber(L, a);
                const lua_Number nb = lua_tonumber(L, b);

                if (std::isnan(na) && std::isnan(nb))
                    return true;

                return na == nb;
            }

            return lua_equal(L, a, b);
        }

        inline bool tableHasKeys(lua_State* L, int tableIndex, int keysIndex)
        {
            if (!lua_istable(L, keysIndex))
                return true;

            tableIndex = lua_absindex(L, tableIndex);
            keysIndex = lua_absindex(L, keysIndex);

            lua_pushnil(L);
            while (lua_next(L, keysIndex) != 0)
            {
                lua_pushvalue(L, -1);
                lua_rawget(L, tableIndex);
                const bool hasKey = !lua_isnil(L, -1);
                lua_pop(L, 2);

                if (!hasKey)
                {
                    lua_pop(L, 1);
                    return false;
                }
            }

            return true;
        }

        inline bool tableHasValues(lua_State* L, int tableIndex, int valuesIndex)
        {
            if (!lua_istable(L, valuesIndex))
                return true;

            tableIndex = lua_absindex(L, tableIndex);
            valuesIndex = lua_absindex(L, valuesIndex);

            lua_newtable(L);
            const int tempTableIndex = lua_gettop(L);
            int valueCount = 0;

            lua_pushnil(L);
            while (lua_next(L, tableIndex) != 0)
            {
                lua_rawseti(L, tempTableIndex, ++valueCount);
            }

            lua_pushnil(L);
            while (lua_next(L, valuesIndex) != 0)
            {
                bool found = false;

                for (int i = 1; i <= valueCount; ++i)
                {
                    lua_rawgeti(L, tempTableIndex, i);
                    const bool equal = lua_equal_tuff(L, -1, -2);
                    lua_pop(L, 1);

                    if (equal)
                    {
                        found = true;
                        break;
                    }
                }

                lua_pop(L, 1);
                if (!found)
                {
                    lua_pop(L, 2);
                    return false;
                }
            }

            lua_pop(L, 1);
            return true;
        }

        inline bool tableHasKeyValuePairs(lua_State* L, int tableIndex, int pairsIndex)
        {
            if (!lua_istable(L, pairsIndex))
                return true;

            tableIndex = lua_absindex(L, tableIndex);
            pairsIndex = lua_absindex(L, pairsIndex);

            lua_pushnil(L);
            while (lua_next(L, pairsIndex) != 0)
            {
                lua_pushvalue(L, -2);
                lua_rawget(L, tableIndex);
                const bool equal = lua_equal_tuff(L, -1, -2);
                lua_pop(L, 2);

                if (!equal)
                {
                    lua_pop(L, 1);
                    return false;
                }
            }

            return true;
        }

        inline bool tableHasMetatable(lua_State* L, int tableIndex, int expectedMT)
        {
            if (lua_isnil(L, expectedMT))
                return true;

            tableIndex = lua_absindex(L, tableIndex);
            expectedMT = lua_absindex(L, expectedMT);

            if (!lua_getmetatable(L, tableIndex))
                return false;

            const bool equal = lua_equal_tuff(L, -1, expectedMT);
            lua_pop(L, 1);
            return equal;
        }

        inline std::string getFunctionName(lua_State* L, int funcIndex)
        {
            funcIndex = lua_absindex(L, funcIndex);

            lua_Debug ar{};
            lua_pushvalue(L, funcIndex);
            if (lua_getinfo(L, -1, OBF("n"), &ar) && ar.name)
            {
                std::string result(ar.name);
                lua_pop(L, 1);
                return result;
            }
            lua_pop(L, 1);

            lua_pushvalue(L, funcIndex);
            const char* str = lua_tostring(L, -1);
            std::string result = str ? std::string(str) : "";
            lua_pop(L, 1);
            return result;
        }

        inline bool functionHasConstants(lua_State* L, int funcIndex, int constantsIndex)
        {
            if (!lua_istable(L, constantsIndex))
                return true;

            if (lua_iscfunction(L, funcIndex))
                return false;

            funcIndex = lua_absindex(L, funcIndex);
            constantsIndex = lua_absindex(L, constantsIndex);

            lua_getglobal(L, ENV_OBF("debug"));
            if (lua_isnil(L, -1))
            {
                lua_pop(L, 1);
                return false;
            }

            lua_getfield(L, -1, ENV_OBF("getconstants"));
            if (lua_isnil(L, -1))
            {
                lua_pop(L, 2);
                return false;
            }

            lua_pushvalue(L, funcIndex);
            if (lua_pcall(L, 1, 1, 0) != 0)
            {
                lua_pop(L, 2);
                return false;
            }

            const int actualConstants = lua_gettop(L);

            lua_pushnil(L);
            while (lua_next(L, constantsIndex) != 0)
            {
                bool found = false;

                lua_pushnil(L);
                while (lua_next(L, actualConstants) != 0)
                {
                    if (lua_equal_tuff(L, -1, -3))
                    {
                        found = true;
                        lua_pop(L, 2);
                        break;
                    }

                    lua_pop(L, 1);
                }

                lua_pop(L, 1);
                if (!found)
                {
                    lua_pop(L, 3);
                    return false;
                }
            }

            lua_pop(L, 2);
            return true;
        }

        inline bool functionHasUpvalues(lua_State* L, int funcIndex, int upvaluesIndex)
        {
            if (!lua_istable(L, upvaluesIndex))
                return true;

            funcIndex = lua_absindex(L, funcIndex);
            upvaluesIndex = lua_absindex(L, upvaluesIndex);

            lua_getglobal(L, ENV_OBF("debug"));
            if (lua_isnil(L, -1))
            {
                lua_pop(L, 1);
                return false;
            }

            lua_getfield(L, -1, ENV_OBF("getupvalues"));
            if (lua_isnil(L, -1))
            {
                lua_pop(L, 2);
                return false;
            }

            lua_pushvalue(L, funcIndex);
            if (lua_pcall(L, 1, 1, 0) != 0)
            {
                lua_pop(L, 2);
                return false;
            }

            const int actualUpvalues = lua_gettop(L);

            lua_pushnil(L);
            while (lua_next(L, upvaluesIndex) != 0)
            {
                bool found = false;

                lua_pushnil(L);
                while (lua_next(L, actualUpvalues) != 0)
                {
                    if (lua_equal_tuff(L, -1, -3))
                    {
                        found = true;
                        lua_pop(L, 2);
                        break;
                    }

                    lua_pop(L, 1);
                }

                lua_pop(L, 1);
                if (!found)
                {
                    lua_pop(L, 3);
                    return false;
                }
            }

            lua_pop(L, 2);
            return true;
        }
    }

    inline int filtergc(lua_State* L)
    {
        luaL_checkany(L, 1);

        constexpr int filterOptions = 2;
        const bool returnOne = lua_toboolean(L, 3);

        if (lua_isfunction(L, 1))
        {
            lua_newtable(L);
            const int matchesIndex = lua_gettop(L);
            int matchCount = 0;

            PushGCObjects(L, true);
            const int gcTable = lua_gettop(L);

            lua_pushnil(L);
            while (lua_next(L, gcTable) != 0)
            {
                lua_pushvalue(L, 1);
                lua_pushvalue(L, -2);

                if (lua_pcall(L, 1, 1, 0) == 0)
                {
                    if (lua_toboolean(L, -1))
                    {
                        lua_pop(L, 1);
                        lua_pushvalue(L, -1);
                        lua_rawseti(L, matchesIndex, ++matchCount);
                    }
                    else
                    {
                        lua_pop(L, 1);
                    }
                }
                else
                {
                    lua_pop(L, 1);
                }

                lua_pop(L, 1);
            }

            lua_pop(L, 1);
            return 1;
        }

        const char* filterType = luaL_checkstring(L, 1);

        lua_newtable(L);
        const int matchesIndex = lua_gettop(L);
        int matchCount = 0;

        if (strcmp(filterType, ENV_OBF("table")) == 0)
        {
            PushGCObjects(L, true);
            const int gcTable = lua_gettop(L);

            lua_pushnil(L);
            while (lua_next(L, gcTable) != 0)
            {
                if (lua_istable(L, -1))
                {
                    bool passed = true;
                    const int currentTable = lua_gettop(L);

                    if (passed && lua_istable(L, filterOptions))
                    {
                        lua_getfield(L, filterOptions, ENV_OBF("Keys"));
                        if (!lua_isnil(L, -1))
                            passed = FilterGCUtils::tableHasKeys(L, currentTable, lua_gettop(L));
                        lua_pop(L, 1);
                    }

                    if (passed && lua_istable(L, filterOptions))
                    {
                        lua_getfield(L, filterOptions, ENV_OBF("Values"));
                        if (!lua_isnil(L, -1))
                            passed = FilterGCUtils::tableHasValues(L, currentTable, lua_gettop(L));
                        lua_pop(L, 1);
                    }

                    if (passed && lua_istable(L, filterOptions))
                    {
                        lua_getfield(L, filterOptions, ENV_OBF("KeyValuePairs"));
                        if (!lua_isnil(L, -1))
                            passed = FilterGCUtils::tableHasKeyValuePairs(L, currentTable, lua_gettop(L));
                        lua_pop(L, 1);
                    }

                    if (passed && lua_istable(L, filterOptions))
                    {
                        lua_getfield(L, filterOptions, ENV_OBF("Metatable"));
                        if (!lua_isnil(L, -1))
                            passed = FilterGCUtils::tableHasMetatable(L, currentTable, lua_gettop(L));
                        lua_pop(L, 1);
                    }

                    if (passed)
                    {
                        if (returnOne)
                            return 1;

                        lua_pushvalue(L, currentTable);
                        lua_rawseti(L, matchesIndex, ++matchCount);
                    }
                }

                lua_pop(L, 1);
            }

            lua_pop(L, 1);
        }
        else if (strcmp(filterType, ENV_OBF("function")) == 0)
        {
            bool ignoreExecutor = true;
            if (lua_istable(L, filterOptions))
            {
                        lua_getfield(L, filterOptions, ENV_OBF("IgnoreExecutor"));
                if (!lua_isnil(L, -1))
                    ignoreExecutor = lua_toboolean(L, -1);
                lua_pop(L, 1);
            }

            PushGCObjects(L, false);
            const int gcTable = lua_gettop(L);

            lua_pushnil(L);
            while (lua_next(L, gcTable) != 0)
            {
                if (lua_isfunction(L, -1))
                {
                    bool passed = true;
                    const int currentFunc = lua_gettop(L);
                    const bool isCClosure = lua_iscfunction(L, currentFunc);

                    if (passed && lua_istable(L, filterOptions))
                    {
                        lua_getfield(L, filterOptions, ENV_OBF("Name"));
                        if (!lua_isnil(L, -1))
                        {
                            const char* requiredName = lua_tostring(L, -1);
                            const std::string funcName = FilterGCUtils::getFunctionName(L, currentFunc);
                            passed = requiredName && funcName.find(requiredName) != std::string::npos;
                        }
                        lua_pop(L, 1);
                    }

                    if (passed && ignoreExecutor)
                    {
                        Closure* closure = clvalue(luaA_toobject(L, currentFunc));
                        if (Closures::IsExecutorClosure(closure))
                            passed = false;
                    }

                    if (isCClosure && lua_istable(L, filterOptions))
                    {
                        lua_getfield(L, filterOptions, ENV_OBF("Hash"));
                        const bool hasHash = !lua_isnil(L, -1);
                        lua_pop(L, 1);

                        lua_getfield(L, filterOptions, ENV_OBF("Constants"));
                        const bool hasConstants = !lua_isnil(L, -1);
                        lua_pop(L, 1);

                        lua_getfield(L, filterOptions, ENV_OBF("Upvalues"));
                        const bool hasUpvalues = !lua_isnil(L, -1);
                        lua_pop(L, 1);

                        if (hasHash || hasConstants || hasUpvalues)
                            passed = false;
                    }

                    if (passed && !isCClosure && lua_istable(L, filterOptions))
                    {
                        lua_getfield(L, filterOptions, ENV_OBF("Hash"));
                        if (!lua_isnil(L, -1))
                        {
                            const char* requiredHash = lua_tostring(L, -1);
                            Closure* closure = clvalue(luaA_toobject(L, currentFunc));

                            if (closure->isC)
                            {
                                passed = false;
                            }
                            else
                            {
                                Proto* proto = closure->l.p;
                                const std::vector<unsigned char> protoBytes = Crypt::getProtoBytes(proto);
                                const std::string hash = sha384(std::string(
                                    reinterpret_cast<const char*>(protoBytes.data()),
                                    protoBytes.size()));

                                passed = requiredHash && hash == requiredHash;
                            }
                        }
                        lua_pop(L, 1);
                    }

                    if (passed && !isCClosure && lua_istable(L, filterOptions))
                    {
                        lua_getfield(L, filterOptions, ENV_OBF("Constants"));
                        if (!lua_isnil(L, -1))
                            passed = FilterGCUtils::functionHasConstants(L, currentFunc, lua_gettop(L));
                        lua_pop(L, 1);
                    }

                    if (passed && !isCClosure && lua_istable(L, filterOptions))
                    {
                        lua_getfield(L, filterOptions, ENV_OBF("Upvalues"));
                        if (!lua_isnil(L, -1))
                            passed = FilterGCUtils::functionHasUpvalues(L, currentFunc, lua_gettop(L));
                        lua_pop(L, 1);
                    }

                    if (passed)
                    {
                        if (returnOne)
                            return 1;

                        lua_pushvalue(L, currentFunc);
                        lua_rawseti(L, matchesIndex, ++matchCount);
                    }
                }

                lua_pop(L, 1);
            }

            lua_pop(L, 1);
        }
        else
        {
            luaL_error(L, OBF("Expected type 'function' or 'table', got '%s'"), filterType);
        }

        if (returnOne)
        {
            lua_pushnil(L);
            return 1;
        }

        return 1;
    }

    int getrenv(lua_State* L)
    {
        lua_check(L, 0);
        lua_State* RobloxState = L->global->mainthread;

        if (RenvCacheState != RobloxState)
        {
            RenvCache = nullptr;
            RenvCacheState = RobloxState;
        }

        if (!RenvCache)
        {
            LuaTable* clone = luaH_clone(L, RobloxState->gt);

            lua_rawcheckstack(L, 2);
            luaC_threadbarrier(L);
            luaC_threadbarrier(RobloxState);
            L->top->value.p = clone;
            L->top->tt = LUA_TTABLE;
            L->top++;

            lua_pushvalue(L, -1);
            lua_ref(L, -1);
            lua_pop(L, 1);

            lua_rawgeti(L, LUA_REGISTRYINDEX, 2);
            lua_setfield(L, -2, ENV_OBF("_G"));
            lua_rawgeti(L, LUA_REGISTRYINDEX, 4);
            lua_setfield(L, -2, ENV_OBF("shared"));

            RenvCache = clone;
            lua_pop(L, 1);
        }

        lua_rawcheckstack(L, 1);
        luaC_threadbarrier(L);
        L->top->value.p = RenvCache;
        L->top->tt = LUA_TTABLE;
        L->top++;

        return 1;
    }

    inline void PushTable(lua_State* L, LuaTable* Table)
    {
        luaC_threadbarrier(L);
        sethvalue(L, L->top, Table);
        incr_top(L);
    }

    int getcallingscript(lua_State* L)
    {
        for (CallInfo* Frame = L->ci; Frame >= L->base_ci; --Frame)
        {
            if (!ttisfunction(Frame->func))
                continue;

            Closure* Function = clvalue(Frame->func);
            if (!Function->env)
                continue;

            PushTable(L, Function->env);
            lua_getfield(L, -1, ENV_OBF("script"));
            lua_remove(L, -2);

            if (!lua_isnil(L, -1))
                return 1;

            lua_pop(L, 1);
        }

        lua_pushnil(L);
        return 1;
    }

    int getsenv(lua_State* L) {
        luaL_checktype(L, 1, LUA_TUSERDATA);

        auto script = *reinterpret_cast<std::uintptr_t*>(lua_touserdata(L, 1));
        if (!script) {
            lua_pushnil(L);
            return 1;
        }

        lua_getfield(L, 1, ENV_OBF("ClassName"));
        std::string className = lua_tostring(L, -1);
        lua_pop(L, 1);

        if (className != OBF("LocalScript") && className != OBF("Script")) {
            lua_pushnil(L);
            return 1;
        }

        for (lua_Page* cur = L->global->allgcopages; cur;) {
            lua_Page* next = luaM_getnextpage(cur);

            char* start;
            char* end;
            int busy;
            int block;
            luaM_getpagewalkinfo(cur, &start, &end, &busy, &block);

            for (char* pos = start; pos != end; pos += block) {
                auto gco = reinterpret_cast<GCObject*>(pos);

                if (!gco || isdead(L->global, gco) || gco->gch.tt != LUA_TTHREAD)
                    continue;

                auto thread = reinterpret_cast<lua_State*>(pos);

                if (!thread->userdata || thread->userdata->script.expired())
                    continue;

                if ((uintptr_t)thread->userdata->script.lock().get() != script)
                    continue;

                if (thread->global->mainthread != L->global->mainthread) {
                    lua_pushnil(L);
                    return 1;
                }

                luaC_threadbarrier(L);
                luaC_threadbarrier(thread);

                lua_pushvalue(thread, LUA_GLOBALSINDEX);
                lua_xmove(thread, L, 1);
                return 1;
            }

            cur = next;
        }

        lua_pushnil(L);
        return 1;
    }

    inline int isexecutorclosure(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TFUNCTION);

        Closure* closure = clvalue(luaA_toobject(L, 1));
        if (!closure)
        {
            lua_pushboolean(L, 0);
            return 1;
        }

        if (closure->isC)
        {
            lua_pushboolean(L, closure->c.f == nullptr ? 0 : 1);
            return 1;
        }

        Proto* proto = closure->l.p;
        if (!proto)
        {
            lua_pushboolean(L, 0);
            return 1;
        }

        lua_Debug ar;
        lua_pushvalue(L, 1);
        lua_getinfo(L, -1, OBF("S"), &ar);
        lua_pop(L, 1);

        if (ar.source && (
            strstr(ar.source, OBF("@")) == ar.source ||
            strstr(ar.source, OBF("=[C]")) == ar.source
            ))
        {
            lua_pushboolean(L, 0);
            return 1;
        }

        lua_pushboolean(L, 1);
        return 1;
    }

    struct HookRecord
    {
        int OriginalRef = LUA_NOREF;
        int HookRef = LUA_NOREF;
    };

    inline std::unordered_map<Closure*, HookRecord> HookRecords;
    inline std::unordered_map<Closure*, int> NewCClosureRefs;
    inline std::unordered_set<Closure*> ExecutorClosures;

    inline int FinishYieldableCall(lua_State* L)
    {
        if (L->status == SCHEDULED_REENTRY || L->status == LUA_YIELD || L->status == LUA_BREAK)
            return C_CALL_YIELD;

        return lua_gettop(L);
    }

    inline int CallReferencedFunction(lua_State* L, int Ref)
    {
        lua_getref(L, Ref);
        lua_insert(L, 1);

        luaD_callint(L, L->base, LUA_MULTRET, lua_isyieldable(L) != 0);
        return FinishYieldableCall(L);
    }

    int DispatchContinuation(lua_State* L, int Status)
    {
        return lua_gettop(L);
    }

    int NewCClosureDispatcher(lua_State* L)
    {
        Closure* Current = curr_func(L);
        auto It = NewCClosureRefs.find(Current);
        if (It == NewCClosureRefs.end())
            luaL_error(L, OBF("newcclosure: missing wrapped function"));

        return CallReferencedFunction(L, It->second);
    }

    inline Closure* ToClosure(lua_State* L, int Index)
    {
        luaL_checktype(L, Index, LUA_TFUNCTION);
        return clvalue(luaA_toobject(L, Index));
    }

    inline void PushClosure(lua_State* L, Closure* ClosureObject)
    {
        luaC_threadbarrier(L);
        setclvalue(L, L->top, ClosureObject);
        incr_top(L);
    }

    inline Closure* CloneClosure(lua_State* L, Closure* Source)
    {
        Closure* Clone = nullptr;

        if (Source->isC)
        {
            Clone = luaF_newCclosure(L, Source->nupvalues, Source->env);
            Clone->stacksize = Source->stacksize;
            Clone->preload = Source->preload;
            Clone->c.f = Source->c.f;
            Clone->c.cont = static_cast<lua_Continuation>(Source->c.cont);
            Clone->c.debugname = static_cast<const char*>(Source->c.debugname);

            for (int i = 0; i < Source->nupvalues; ++i)
                setobj2n(L, &Clone->c.upvals[i], &Source->c.upvals[i]);
        }
        else
        {
            Clone = luaF_newLclosure(L, Source->nupvalues, Source->env, Source->l.p);
            Clone->stacksize = Source->stacksize;
            Clone->preload = Source->preload;

            for (int i = 0; i < Source->nupvalues; ++i)
                setobj2n(L, &Clone->l.uprefs[i], &Source->l.uprefs[i]);
        }

        return Clone;
    }

    inline void PushClone(lua_State* L, Closure* Source)
    {
        PushClosure(L, CloneClosure(L, Source));
    }

    inline bool CopyClosureBody(lua_State* L, Closure* Target, Closure* Source)
    {
        if (Target->isC != Source->isC || Source->nupvalues > Target->nupvalues)
            return false;

        Target->stacksize = Source->stacksize;
        Target->preload = Source->preload;
        Target->nupvalues = Source->nupvalues;
        Target->env = Source->env;

        if (Source->isC)
        {
            Target->c.f = Source->c.f;
            Target->c.cont = static_cast<lua_Continuation>(Source->c.cont);
            Target->c.debugname = static_cast<const char*>(Source->c.debugname);

            for (int i = 0; i < Source->nupvalues; ++i)
                setobj2n(L, &Target->c.upvals[i], &Source->c.upvals[i]);
        }
        else
        {
            Target->l.p = Source->l.p;

            for (int i = 0; i < Source->nupvalues; ++i)
                setobj2n(L, &Target->l.uprefs[i], &Source->l.uprefs[i]);
        }

        return true;
    }

    int HookCDispatcher(lua_State* L)
    {
        Closure* Current = curr_func(L);
        auto It = HookRecords.find(Current);
        if (It == HookRecords.end())
            luaL_error(L, OBF("hookfunction: missing hook"));

        return CallReferencedFunction(L, It->second.HookRef);
    }

    inline int HookFunctionAt(lua_State* L, int TargetIndex, int HookIndex)
    {
        TargetIndex = lua_absindex(L, TargetIndex);
        HookIndex = lua_absindex(L, HookIndex);

        Closure* Target = ToClosure(L, TargetIndex);
        Closure* Hook = ToClosure(L, HookIndex);

        if (!Target->isC && (Hook->isC || Hook->nupvalues > Target->nupvalues))
            luaL_error(L, OBF("hookfunction: incompatible Luau closure layout"));

        HookRecord& Record = HookRecords[Target];
        if (Record.OriginalRef == LUA_NOREF)
        {
            PushClone(L, Target);
            Record.OriginalRef = lua_ref(L, -1);
            lua_pop(L, 1);
        }
        else
        {
            lua_getref(L, Record.OriginalRef);
            Closure* Original = ToClosure(L, -1);

            if (Hook == Original)
            {
                if (!CopyClosureBody(L, Target, Original))
                {
                    lua_pop(L, 1);
                    luaL_error(L, OBF("hookfunction: incompatible Luau closure layout"));
                }

                if (Record.HookRef != LUA_NOREF)
                    lua_unref(L, Record.HookRef);

                lua_unref(L, Record.OriginalRef);
                HookRecords.erase(Target);
                ExecutorClosures.erase(Target);
                return 1;
            }

            lua_pop(L, 1);

            if (Record.HookRef != LUA_NOREF)
            {
                lua_unref(L, Record.HookRef);
                Record.HookRef = LUA_NOREF;
            }
        }

        lua_pushvalue(L, HookIndex);
        Record.HookRef = lua_ref(L, -1);
        lua_pop(L, 1);

        if (Target->isC)
        {
            Target->c.f = HookCDispatcher;
            Target->c.cont = DispatchContinuation;
            Target->c.debugname = OBF("hookfunction");
        }
        else
        {
            if (!CopyClosureBody(L, Target, Hook))
                luaL_error(L, OBF("hookfunction: failed to apply Lua hook wrapper"));
        }

        SharedVariables::ExecutorClosures.insert(Target);
        lua_getref(L, Record.OriginalRef);
        return 1;
    }

    int hookmetamethod(lua_State* L)
    {
        luaL_checkany(L, 1);
        const char* Method = luaL_checkstring(L, 2);
        luaL_checktype(L, 3, LUA_TFUNCTION);
        if (!lua_getmetatable(L, 1))
            luaL_error(L, OBF("hookmetamethod: object has no metatable"));
        lua_getfield(L, -1, Method);
        if (!lua_isfunction(L, -1))
            luaL_error(L, OBF("hookmetamethod: metamethod is not a function"));
        return HookFunctionAt(L, -1, 3);
    }

    int checkcaller(lua_State* L) {
        if (SharedVariables::ExploitThread && L == SharedVariables::ExploitThread) {
            lua_pushboolean(L, true);
            return 1;
        }
        if (L && L->userdata &&
            (L->userdata->script.expired() ||
                L->userdata->capabilities == MaxCapabilities)) {
            lua_pushboolean(L, true);
            return 1;
        }
        lua_Debug ar;
        for (int level = 1; level <= 10; level++) {
            if (!lua_getinfo(L, level, OBF("f"), &ar))
                break;
            if (lua_isfunction(L, -1)) {
                Closure* cl = clvalue(index2addr(L, -1));
                if (cl->isC) {
                    for (auto func : Environment::function_array)
                        if (func == cl || func->c.f == cl->c.f) {
                            lua_pop(L, 1);
                            lua_pushboolean(L, true);
                            return 1;
                        }
                }
                else if (cl->l.p && cl->l.p->source) {
                    const char* src = getstr(cl->l.p->source);
                    if (src && (strcmp(src, ENV_OBF("=loadstring")) == 0 ||
                        strcmp(src, ENV_OBF("@Nam")) == 0 || strcmp(src, ENV_OBF("@Arona")) == 0)) {
                        lua_pop(L, 1);
                        lua_pushboolean(L, true);
                        return 1;
                    }
                }
                if (Closures::WrappedClosures.count(cl)) {
                    lua_pop(L, 1);
                    lua_pushboolean(L, true);
                    return 1;
                }
            }
            lua_pop(L, 1);
        }
        lua_pushboolean(L, false);
        return 1;
    }

    int getscriptclosure(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TUSERDATA);

        uintptr_t Script = *reinterpret_cast<uintptr_t*>(lua_touserdata(L, 1));
        if (!Script) {
            lua_pushnil(L);
            return 1;
        }

        lua_getfield(L, 1, ENV_OBF("ClassName"));
        const char* ClassName = lua_tolstring(L, -1, nullptr);
        lua_pop(L, 1);

        uintptr_t ProtectedString = 0;
        if (strcmp(ClassName, ENV_OBF("ModuleScript")) == 0) {
            ProtectedString = *reinterpret_cast<uintptr_t*>(Script + Offsets::Scripts::ModuleScriptByteCode);
        }
        else {
            ProtectedString = *reinterpret_cast<uintptr_t*>(Script + Offsets::Scripts::LocalScriptByteCode);
        }

        if (!ProtectedString) {
            lua_pushnil(L);
            return 1;
        }

        std::string Encrypted;
        uintptr_t dataPtr = *reinterpret_cast<uintptr_t*>(ProtectedString + Bytecode::Pointer);
        size_t dataSize = *reinterpret_cast<size_t*>(ProtectedString + Bytecode::Size);

        if (dataPtr && dataSize > 0 && dataSize < 64 * 1024 * 1024) {
            Encrypted = std::string(reinterpret_cast<const char*>(dataPtr), dataSize);
        }
        else {
            lua_pushnil(L);
            return 1;
        }

        if (Encrypted.empty()) {
            lua_pushnil(L);
            return 1;
        }

        lua_State* Thread = lua_newthread(L);
        lua_pop(L, 1);

        luaL_sandboxthread(Thread);
        TaskScheduler::SetIdentity(Thread, 8, false);

        lua_pushvalue(L, 1);
        lua_xmove(L, Thread, 1);
        lua_setglobal(Thread, ENV_OBF("script"));

        int result = Roblox::LuaVMLoad(Thread, &Encrypted, OBF("getscriptclosure"), 0);
        if (result != LUA_OK) {
            lua_pushnil(L);
            return 1;
        }

        Closure* cl = clvalue(luaA_toobject(Thread, -1));
        TaskScheduler::SetProtoCapabilities(cl->l.p, &MaxCapabilities);

        lua_pop(Thread, lua_gettop(Thread));

        lua_rawcheckstack(L, 1);
        luaC_threadbarrier(L);

        L->top->value.gc = reinterpret_cast<GCObject*>(cl);
        L->top->tt = LUA_TFUNCTION;
        L->top++;

        return 1;
    }

    typedef void(__fastcall* PushInstanceWeakPtrT)(lua_State* L, std::weak_ptr<uintptr_t>);
    static PushInstanceWeakPtrT PushInstanceWeakPtr = (PushInstanceWeakPtrT)Roblox::PushInstance;
    inline int getscriptfromthread(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TTHREAD);

        lua_State* thread = lua_tothread(L, 1);

        if (!thread || !thread->userdata || thread->userdata->script.expired()) {
            lua_pushnil(L);
            return 1;
        }

        auto script = thread->userdata->script.lock();
        PushInstanceWeakPtr(L, script);

        return 1;
    }

    inline int getrunningscriptsv2(lua_State* L)
    {
        lua_newtable(L);
        int tableIndex = lua_gettop(L);
        int i = 0;
        std::unordered_map<std::shared_ptr<std::uintptr_t*>, bool> running_scripts = { };
        lua_rawcheckstack(L, 5);
        luaC_threadbarrier(L);
        lua_pushvalue(L, LUA_REGISTRYINDEX);
        lua_pushnil(L);
        while (lua_next(L, -2)) {
            if (lua_isthread(L, -1)) {
                lua_State* thread = lua_tothread(L, -1);
                if (thread && thread->userdata != nullptr && !thread->userdata->script.expired()) {
                    if (thread->global->mainthread == L->global->mainthread) {
                        const auto script = *reinterpret_cast<std::shared_ptr<std::uintptr_t*>*>(&thread->userdata->script);
                        if (!running_scripts.contains(script)) {
                            Roblox::InstanceBridge::Shared(L, script);
                            lua_getfield(L, -1, ENV_OBF("ClassName"));
                            const char* className = lua_tostring(L, -1);
                            lua_pop(L, 1);

                            bool isValidScript = false;

                            if (className) {
                                if (strcmp(className, ENV_OBF("LocalScript")) == 0 || strcmp(className, ENV_OBF("ModuleScript")) == 0) {
                                    isValidScript = true;
                                }
                                else if (strcmp(className, ENV_OBF("Script")) == 0) {
                                    lua_getfield(L, -1, ENV_OBF("RunContext"));
                                    if (lua_type(L, -1) != LUA_TNIL) {
                                        if (lua_isnumber(L, -1)) {
                                            int runContext = lua_tointeger(L, -1);
                                            isValidScript = (runContext == 2);
                                        }
                                        else {
                                            lua_getfield(L, -1, ENV_OBF("Value"));
                                            if (lua_isnumber(L, -1)) {
                                                int runContext = lua_tointeger(L, -1);
                                                isValidScript = (runContext == 2);
                                            }
                                            lua_pop(L, 1);
                                        }
                                    }
                                    lua_pop(L, 1);
                                }
                            }

                            if (isValidScript) {
                                running_scripts[script] = true;
                                lua_rawseti(L, tableIndex, ++i);
                            }
                            else {
                                lua_pop(L, 1);
                            }
                        }
                    }
                }
            }
            lua_pop(L, 1);
        }
        lua_pop(L, 1);
        return 1;
    }

    int getloadedmodulesv3(lua_State* L)
    {
        lua_newtable(L);

        typedef struct {
            lua_State* pLua;
            int itemsFound;
            std::map< uintptr_t, bool > map;
        } GCOContext;

        auto gcCtx = GCOContext{ L, 0 };

        const auto ullOldThreshold = L->global->GCthreshold;
        L->global->GCthreshold = SIZE_MAX;

        luaM_visitgco(L, &gcCtx, [](void* ctx, lua_Page* pPage, GCObject* pGcObj) -> bool {
            const auto pCtx = static_cast<GCOContext*>(ctx);
            const auto ctxL = pCtx->pLua;

            if (isdead(ctxL->global, pGcObj))
                return false;

            if (const auto gcObjType = pGcObj->gch.tt;
                gcObjType == LUA_TFUNCTION) {
                ctxL->top->value.gc = pGcObj;
                ctxL->top->tt = gcObjType;
                ctxL->top++;

                lua_getfenv(ctxL, -1);

                if (!lua_isnil(ctxL, -1)) {
                    lua_getfield(ctxL, -1, ENV_OBF("script"));

                    if (lua_isuserdata(ctxL, -1)) {
                        uintptr_t script_addr = *static_cast<uintptr_t*>(lua_touserdata(ctxL, -1));

                        lua_getfield(ctxL, -1, ENV_OBF("ClassName"));
                        const char* class_name = lua_isstring(ctxL, -1) ? lua_tostring(ctxL, -1) : nullptr;
                        const bool is_module = class_name && strcmp(class_name, ENV_OBF("ModuleScript")) == 0;
                        lua_pop(ctxL, 1);

                        if (script_addr && pCtx->map.find(script_addr) == pCtx->map.end() && is_module) {
                            pCtx->map.insert({ script_addr, true });
                            lua_rawseti(ctxL, -4, ++pCtx->itemsFound);
                        }
                        else {
                            lua_pop(ctxL, 1);
                        }
                    }
                    else {
                        lua_pop(ctxL, 1);
                    }
                }

                lua_pop(ctxL, 2);
            }
            return false;
            });

        L->global->GCthreshold = ullOldThreshold;

        return 1;
    }




    inline void RegisterLibrary(lua_State* L)
    {
        if (!L) return;

        Utils::AddFunction(L, ENV_OBF("getloadedmodules"), getloadedmodules);
        Utils::AddFunction(L, ENV_OBF("getrunningscripts"), getrunningscriptsv2);
        Utils::AddFunction(L, ENV_OBF("checkcaller"), checkcaller);
        Utils::AddFunction(L, ENV_OBF("getscriptfromthread"), getscriptfromthread);
        Utils::AddFunction(L, ENV_OBF("getscripts"), getscripts);
        Utils::AddFunction(L, ENV_OBF("getrenv"), getrenv);
        Utils::AddFunction(L, ENV_OBF("getscripthash"), getscripthash);
        Utils::AddFunction(L, ENV_OBF("getcallingscript"), getcallingscript);
        Utils::AddFunction(L, ENV_OBF("getgc"), getgc);
        Utils::AddFunction(L, ENV_OBF("getsenv"), getsenv);
        Utils::AddFunction(L, ENV_OBF("getmenv"), getsenv);
        Utils::AddFunction(L, ENV_OBF("getscriptclosure"), getscriptclosure);
        Utils::AddFunction(L, ENV_OBF("getscriptfunction"), getscriptclosure);
        Utils::AddFunction(L, ENV_OBF("getscriptbytecode"), getscriptbytecode);
        Utils::AddFunction(L, ENV_OBF("dumpstring"), getscriptbytecode);
    }
}
