#pragma once

#include <lgc.h>
#include <lstate.h>
#include <lualib.h>

#include <Utils.hpp>
#include <Globals.hpp>
#include <Exploit/Execution/Execution.hpp>
#include <Main/Yield/Yield.hpp>
#include <Roblox/FFlags.hpp>

#include <Windows.h>
#include <cstdio>
#include <string>

namespace Miscellaneous
{
    template<typename T>
    inline bool read_fast_flag(uintptr_t address, T& value) noexcept
    {
        __try { value = *reinterpret_cast<T*>(address); return true; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    template<typename T>
    inline bool write_fast_flag(uintptr_t address, const T& value) noexcept
    {
        __try { *reinterpret_cast<T*>(address) = value; return true; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }
    using luaH_clone_t = LuaTable * (__cdecl*)(lua_State* L, LuaTable* t);
    const auto luaH_clone = reinterpret_cast<luaH_clone_t>(0x7ef210);

    int SetIdentity(lua_State* L) {
        lua_normalisestack(L, 1);

        if (lua_type(L, 1) != LUA_TNUMBER)
            luaL_typeerrorL(L, 1, lua_typename(L, LUA_TNUMBER));

        int identity = (int)lua_tointeger(L, 1);
        TaskScheduler::SetThreadCapabilities(L, identity, identity == 8 ? MaxCapabilities : identity);
        return 0;
    }

    int setthreadidentity(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TNUMBER);
        int identity = (int)lua_tointeger(L, 1);

        if (!L->userdata)
            return 0;

        uint64_t caps = 0xFFFFFFFFFFFFFF00 | Roblox::GetCapabilities(&identity);

        if (identity == 8)
        {
            caps = MaxCapabilities;
        }

        L->userdata->identity = identity;
        L->userdata->capabilities = caps;

        const uintptr_t identity_ptr = Roblox::GetIdentityStruct(*reinterpret_cast<uintptr_t*>(Offsets::RobloxThread::IdentityPtr));

        if (identity_ptr) {
            *reinterpret_cast<uint64_t*>(identity_ptr) = identity;
            *reinterpret_cast<uint64_t*>(identity_ptr + Offsets::Capabilities::Capabilities) = caps;
        }

        return 0;
    }

    int getthreadidentity(lua_State* L)
    {
        if (!L->userdata)
        {
            lua_pushinteger(L, 0);
            return 1;
        }
        lua_pushinteger(L, L->userdata->identity);
        return 1;
    }

    int getgenv(lua_State* L)
    {
        if (SharedVariables::ExploitThread == L)
        {
            lua_pushvalue(L, LUA_GLOBALSINDEX);
            return 1;
        }

        lua_rawcheckstack(L, 1);
        luaC_threadbarrier(L);
        luaC_threadbarrier(SharedVariables::ExploitThread);
        lua_pushvalue(SharedVariables::ExploitThread, LUA_GLOBALSINDEX);
        lua_xmove(SharedVariables::ExploitThread, L, 1);

        return 1;
    }

    int identifyexecutor(lua_State* L)
    {
        lua_pushstring(L, OBF("Lumium"));
        lua_pushstring(L, OBF("1.0.0"));

        return 2;
    }

    int getexecutorname(lua_State* L)
    {
        lua_pushstring(L, OBF("Lumium/1.0.0"));

        return 1;
    }

    int GetObjects(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TUSERDATA);
        luaL_checktype(L, 2, LUA_TSTRING);

        lua_getglobal(L, ENV_OBF("game"));
        lua_getfield(L, -1, ENV_OBF("GetService"));
        if (!lua_isfunction(L, -1))
        {
            lua_pop(L, 2);
            luaL_error(L, OBF("game:GetService is unavailable"));
            return 0;
        }
        lua_pushvalue(L, -2);
        lua_pushstring(L, OBF("InsertService"));
        if (lua_pcall(L, 2, 1, 0) != LUA_OK)
        {
            const char* err = lua_tostring(L, -1);
            char message[512];
            strncpy_s(message, err ? err : OBF("failed to get InsertService"), _TRUNCATE);
            luaL_error(L, OBF("%s"), message);
            return 0;
        }
        lua_remove(L, -2);

        lua_getfield(L, -1, ENV_OBF("LoadLocalAsset"));
        if (!lua_isfunction(L, -1))
        {
            lua_pop(L, 2);
            luaL_error(L, OBF("InsertService:LoadLocalAsset is unavailable"));
            return 0;
        }

        lua_pushvalue(L, -2);
        lua_pushvalue(L, 2);
        if (lua_pcall(L, 2, 1, NULL) != LUA_OK)
        {
            const char* err = lua_tostring(L, -1);
            char message[512];
            strncpy_s(message, err ? err : OBF("LoadLocalAsset failed"), _TRUNCATE);
            luaL_error(L, OBF("%s"), message);
            return 0;
        }

        if (lua_type(L, -1) == LUA_TSTRING)
            luaL_error(L, lua_tostring(L, -1));

        lua_createtable(L, 1, NULL);
        lua_pushvalue(L, -2);
        lua_rawseti(L, -2, 1);

        lua_remove(L, -3);
        lua_remove(L, -2);

        return 1;
    }

    int setfpscap(lua_State* L) {
        luaL_checkstack(L, 1, NULL);

        if (lua_gettop(L) < 1 || !lua_isnumber(L, 1))
            return 0;

        double cap = lua_tonumber(L, 1);
        if (cap <= 0) cap = 999;

        __try {
            *reinterpret_cast<double*>(Offsets::Flags::TaskSchedulerTargetFps) = cap;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
        }

        return 0;
    }


    inline int getfpscap(lua_State* L)
    {
        __try {
            double cap = *reinterpret_cast<double*>(Offsets::Flags::TaskSchedulerTargetFps);
            lua_pushnumber(L, cap);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            lua_pushnumber(L, 60);
        }
        return 1;
    }

    int getfflagtype(lua_State* L)
    {
        const char* name = luaL_checkstring(L, 1);
        if (_stricmp(name, ENV_OBF("TaskSchedulerTargetFps")) == 0)
            lua_pushstring(L, OBF("int"));
        else if (_stricmp(name, ENV_OBF("FixDPIScaling")) == 0)
            lua_pushstring(L, OBF("flag"));
        else if (_stricmp(name, ENV_OBF("InstanceDirectAccess")) == 0)
            lua_pushstring(L, OBF("flag"));
        else if (_stricmp(name, ENV_OBF("LuauUdataDirectAccess6")) == 0)
            lua_pushstring(L, OBF("flag"));
        else
        {
            luaL_error(L, OBF("unsupported or unknown Fast Flag '%s'"), name);
            return 0;
        }
        return 1;
    }


    int queueonteleport(lua_State* L)
    {
        size_t length = 0;
        const char* code = luaL_checklstring(L, 1, &length);
        std::lock_guard<std::mutex> lock(SharedVariables::TeleportQueueMutex);
        SharedVariables::TeleportQueue.emplace_back(code, length);
        return 0;
    }

    int clearteleportqueue(lua_State*)
    {
        std::lock_guard<std::mutex> lock(SharedVariables::TeleportQueueMutex);
        SharedVariables::TeleportQueue.clear();
        return 0;
    }

    static std::string escape_string(const char* s) {
        if (!s) return "";
        std::string result;
        for (const char* p = s; *p; ++p) {
            switch (*p) {
            case '\\': result += OBF("\\\\"); break;
            case '"': result += OBF("\\\""); break;
            case '\n': result += OBF("\\n"); break;
            case '\r': result += OBF("\\r"); break;
            case '\t': result += OBF("\\t"); break;
            default: result += *p; break;
            }
        }
        return result;
    }
    static void serialize_instance(lua_State* L, int instanceIdx, int depth, std::string& out) {
        if (!lua_isuserdata(L, instanceIdx)) return;

        lua_getglobal(L, ENV_OBF("typeof"));
        lua_pushvalue(L, instanceIdx);
        lua_call(L, 1, 1);
        const char* tp = lua_tostring(L, -1);
        lua_pop(L, 1);
        if (!tp || strcmp(tp, ENV_OBF("Instance")) != 0) return;

        lua_getfield(L, instanceIdx, ENV_OBF("ClassName"));
        const char* className = lua_isstring(L, -1) ? lua_tostring(L, -1) : OBF("Instance");
        lua_pop(L, 1);

        lua_getfield(L, instanceIdx, ENV_OBF("Name"));
        const char* instName = lua_isstring(L, -1) ? lua_tostring(L, -1) : "";
        lua_pop(L, 1);

        std::string indent(depth * 4, ' ');
        std::string varName = std::string(OBF("inst_")) + std::to_string(reinterpret_cast<uintptr_t>(lua_touserdata(L, instanceIdx)));

        out += indent + OBF("local ") + varName + OBF(" = Instance.new(\"") + className + OBF("\")\n");
        out += indent + varName + OBF(".Name = \"") + escape_string(instName) + OBF("\"\n");

        lua_getfield(L, instanceIdx, ENV_OBF("ClassName"));
        const char* cn = lua_isstring(L, -1) ? lua_tostring(L, -1) : "";
        lua_pop(L, 1);

        if (strcmp(cn, ENV_OBF("Part")) == 0 || strcmp(cn, ENV_OBF("MeshPart")) == 0 || strcmp(cn, ENV_OBF("UnionOperation")) == 0 ||
            strcmp(cn, ENV_OBF("SpawnLocation")) == 0 || strcmp(cn, ENV_OBF("WedgePart")) == 0 || strcmp(cn, ENV_OBF("CornerWedgePart")) == 0) {
            lua_getfield(L, instanceIdx, ENV_OBF("Position"));
            if (lua_istable(L, -1)) {
                lua_getfield(L, -1, ENV_OBF("X")); double px = lua_tonumber(L, -1); lua_pop(L, 1);
                lua_getfield(L, -1, ENV_OBF("Y")); double py = lua_tonumber(L, -1); lua_pop(L, 1);
                lua_getfield(L, -1, ENV_OBF("Z")); double pz = lua_tonumber(L, -1); lua_pop(L, 1);
                lua_pop(L, 1);
                char buf[256];
                snprintf(buf, sizeof(buf), OBF("%s%s.Position = Vector3.new(%g, %g, %g)\n"), indent.c_str(), varName.c_str(), px, py, pz);
                out += buf;
            }
            else { lua_pop(L, 1); }

            lua_getfield(L, instanceIdx, ENV_OBF("Size"));
            if (lua_istable(L, -1)) {
                lua_getfield(L, -1, ENV_OBF("X")); double sx = lua_tonumber(L, -1); lua_pop(L, 1);
                lua_getfield(L, -1, ENV_OBF("Y")); double sy = lua_tonumber(L, -1); lua_pop(L, 1);
                lua_getfield(L, -1, ENV_OBF("Z")); double sz = lua_tonumber(L, -1); lua_pop(L, 1);
                lua_pop(L, 1);
                char buf[256];
                snprintf(buf, sizeof(buf), OBF("%s%s.Size = Vector3.new(%g, %g, %g)\n"), indent.c_str(), varName.c_str(), sx, sy, sz);
                out += buf;
            }
            else { lua_pop(L, 1); }

            lua_getfield(L, instanceIdx, ENV_OBF("BrickColor"));
            if (!lua_isnil(L, -1) && !lua_isnone(L, -1)) {
                lua_getfield(L, -1, ENV_OBF("Name"));
                const char* bc = lua_isstring(L, -1) ? lua_tostring(L, -1) : nullptr;
                lua_pop(L, 1);
                lua_pop(L, 1);
                if (bc) {
                    out += indent + varName + OBF(".BrickColor = BrickColor.new(\"") + bc + OBF("\")\n");
                }
            }
            else { lua_pop(L, 1); }

            lua_getfield(L, instanceIdx, ENV_OBF("Anchored"));
            if (!lua_isnil(L, -1)) {
                out += indent + varName + OBF(".Anchored = ") + (lua_toboolean(L, -1) ? OBF("true") : OBF("false")) + OBF("\n");
            }
            lua_pop(L, 1);
        }

        lua_getfield(L, instanceIdx, ENV_OBF("Parent"));
        lua_pop(L, 1);

        out += OBF("\n");
    }

    static void serialize_children(lua_State* L, int instanceIdx, int depth, std::string& out) {
        lua_getfield(L, instanceIdx, ENV_OBF("GetChildren"));
        if (!lua_isfunction(L, -1)) { lua_pop(L, 1); return; }
        lua_pushvalue(L, instanceIdx);
        if (lua_pcall(L, 1, 1, 0) != LUA_OK) { lua_pop(L, 1); return; }
        if (!lua_istable(L, -1)) { lua_pop(L, 1); return; }

        int tableIdx = lua_gettop(L);
        int len = (int)lua_objlen(L, tableIdx);
        for (int i = 1; i <= len; ++i) {
            lua_rawgeti(L, tableIdx, i);
            if (lua_isuserdata(L, -1)) {
                serialize_instance(L, -1, depth, out);
                serialize_children(L, lua_gettop(L), depth + 1, out);
            }
            lua_pop(L, 1);
        }
        lua_pop(L, 1);
    }
    int saveinstance(lua_State* L) {
        const char* savePath = nullptr;
        int top = lua_gettop(L);

        if (top >= 2 && lua_istable(L, 2)) {
            lua_getfield(L, 2, ENV_OBF("FileName"));
            if (lua_isstring(L, -1)) {
                savePath = lua_tostring(L, -1);
            }
            lua_pop(L, 1);
        }
        else if (top >= 1 && lua_isstring(L, 1)) {
            savePath = lua_tostring(L, 1);
        }

        lua_getglobal(L, ENV_OBF("game"));
        if (!lua_isuserdata(L, -1)) {
            lua_pop(L, 1);
            luaL_error(L, ENV_OBF("game not found"));
            return 0;
        }
        int gameIdx = lua_gettop(L);

        std::string output;
        output += OBF("-- Generated by executor saveinstance\n");
        output += OBF("local game = game\n");

        lua_getfield(L, gameIdx, ENV_OBF("PlaceId"));
        char buf[256];
        snprintf(buf, sizeof(buf), OBF("local PlaceId = %g\n"), lua_tonumber(L, -1));
        output += buf;
        lua_pop(L, 1);

        lua_getfield(L, gameIdx, ENV_OBF("JobId"));
        lua_pop(L, 1);

        output += OBF("\n");

        serialize_instance(L, gameIdx, 0, output);
        serialize_children(L, gameIdx, 1, output);

        lua_pop(L, 1);

        wchar_t pathBuf[MAX_PATH] = {};
        if (savePath && savePath[0]) {
            if (!SharedVariables::workspace_folder.empty()) {
                std::wstring wsFolder = SharedVariables::workspace_folder.wstring();
                wcscpy_s(pathBuf, MAX_PATH, wsFolder.c_str());
                wchar_t fileName[MAX_PATH] = {};
                MultiByteToWideChar(CP_UTF8, 0, savePath, -1, fileName, MAX_PATH);
                wcscat_s(pathBuf, MAX_PATH, L"\\");
                wcscat_s(pathBuf, MAX_PATH, fileName);
            }
            else {
                MultiByteToWideChar(CP_UTF8, 0, savePath, -1, pathBuf, MAX_PATH);
            }
        }
        else {
            if (!SharedVariables::workspace_folder.empty()) {
                std::wstring wsFolder = SharedVariables::workspace_folder.wstring();
                wcscpy_s(pathBuf, MAX_PATH, wsFolder.c_str());
                wcscat_s(pathBuf, MAX_PATH, L"\\savefile.lua");
            }
            else {
                wchar_t desktop[MAX_PATH] = {};
                SHGetFolderPathW(NULL, CSIDL_DESKTOP, NULL, 0, desktop);
                wcscpy_s(pathBuf, MAX_PATH, desktop);
                wcscat_s(pathBuf, MAX_PATH, L"\\savefile.lua");
            }
        }

        std::ofstream file(pathBuf);
        if (file.is_open()) {
            file << output;
            file.close();
            lua_pushboolean(L, true);
        }
        else {
            lua_pushboolean(L, false);
        }
        return 1;
    }








    int gethui(lua_State* L)
    {
        lua_getglobal(L, ENV_OBF("game"));
        if (!lua_isuserdata(L, -1)) { lua_pop(L, 1); lua_pushnil(L); return 1; }

        lua_getfield(L, -1, ENV_OBF("GetService"));
        if (!lua_isfunction(L, -1)) { lua_pop(L, 2); lua_pushnil(L); return 1; }

        lua_pushvalue(L, -2);
        lua_pushstring(L, ENV_OBF("CoreGui"));
        if (lua_pcall(L, 2, 1, 0) != LUA_OK) {
            lua_pop(L, 1);
            lua_pushnil(L);
            return 1;
        }

        if (!lua_isuserdata(L, -1)) { lua_pop(L, 1); lua_pushnil(L); return 1; }
        int coreGuiIdx = lua_gettop(L);

        lua_getfield(L, -1, ENV_OBF("FindFirstChildOfClass"));
        if (!lua_isfunction(L, -1)) { lua_pop(L, 1); lua_pushnil(L); return 1; }

        lua_pushvalue(L, coreGuiIdx);
        lua_pushstring(L, ENV_OBF("ScreenGui"));
        if (lua_pcall(L, 2, 1, 0) == LUA_OK && lua_isuserdata(L, -1)) {
            return 1;
        }

        lua_getglobal(L, ENV_OBF("Instance"));
        lua_getfield(L, -1, ENV_OBF("new"));
        lua_pushstring(L, ENV_OBF("ScreenGui"));
        lua_call(L, 1, 1);
        lua_remove(L, -2);

        if (lua_isuserdata(L, -1)) {
            lua_pushvalue(L, -1);
            lua_setfield(L, coreGuiIdx, ENV_OBF("Name"));
            lua_pushvalue(L, -1);
            lua_setfield(L, coreGuiIdx, ENV_OBF("Parent"));
            return 1;
        }

        lua_pop(L, 1);
        lua_pushnil(L);
        return 1;
    }

    static std::mutex CommChannelMutex;
    static int NextCommChannelId = 1;

    struct CommChannelData {
        int id;
        int selfRef;
    };
    static std::unordered_map<int, CommChannelData> CommChannels;

    int get_comm_channel(lua_State* L) {
        if (!lua_isnumber(L, 1)) { lua_pushnil(L); return 1; }
        int id = (int)lua_tointeger(L, 1);

        std::lock_guard<std::mutex> lock(CommChannelMutex);
        auto it = CommChannels.find(id);
        if (it == CommChannels.end()) { lua_pushnil(L); return 1; }

        lua_rawgeti(L, LUA_REGISTRYINDEX, it->second.selfRef);
        return 1;
    }


    void RegisterLibrary(lua_State* L)
    {
        
        Utils::AddFunction(L, ENV_OBF("getgenv"), Miscellaneous::getgenv);
        Utils::AddFunction(L, ENV_OBF("identifyexecutor"), Miscellaneous::identifyexecutor);
        Utils::AddFunction(L, ENV_OBF("getexecutorname"), Miscellaneous::getexecutorname);
        Utils::AddFunction(L, ENV_OBF("setthreadidentity"), Miscellaneous::setthreadidentity);
        Utils::AddFunction(L, ENV_OBF("setidentity"), Miscellaneous::setthreadidentity);
        Utils::AddFunction(L, ENV_OBF("setthreadcontext"), Miscellaneous::setthreadidentity);
        Utils::AddFunction(L, ENV_OBF("getthreadidentity"), Miscellaneous::getthreadidentity);
        Utils::AddFunction(L, ENV_OBF("getidentity"), Miscellaneous::getthreadidentity);
        Utils::AddFunction(L, ENV_OBF("getthreadcontext"), Miscellaneous::getthreadidentity);
        Utils::AddFunction(L, ENV_OBF("setfpscap"), Miscellaneous::setfpscap);
        Utils::AddFunction(L, ENV_OBF("getfpscap"), Miscellaneous::getfpscap);
        Utils::AddFunction(L, ENV_OBF("GetObjects"), Miscellaneous::GetObjects);
        Utils::AddFunction(L, ENV_OBF("queueonteleport"), Miscellaneous::queueonteleport);
        Utils::AddFunction(L, ENV_OBF("queue_on_teleport"), Miscellaneous::queueonteleport);
        Utils::AddFunction(L, ENV_OBF("clearteleportqueue"), Miscellaneous::clearteleportqueue);
        Utils::AddFunction(L, ENV_OBF("clear_teleport_queue"), Miscellaneous::clearteleportqueue);
        Utils::AddFunction(L, ENV_OBF("clearqueueonteleport"), Miscellaneous::clearteleportqueue);
        Utils::AddFunction(L, ENV_OBF("gethui"), Miscellaneous::gethui);
        Utils::AddFunction(L, ENV_OBF("get_comm_channel"), Miscellaneous::get_comm_channel);
        Utils::AddFunction(L, ENV_OBF("saveinstance"), Miscellaneous::saveinstance);


    }
}
