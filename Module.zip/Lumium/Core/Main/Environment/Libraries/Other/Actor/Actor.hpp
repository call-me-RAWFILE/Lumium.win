#pragma once

#include <Utils.hpp>
#include <Main/Environment/Environment.hpp>
#include <Exploit/TaskScheduler/TaskScheduler.hpp>

static std::mutex g_actor_scan_mutex;
static std::unordered_set<lua_State*> g_tracked_actor_threads;
static std::vector<std::shared_ptr<uintptr_t>> g_tracked_actors;

inline bool IsValidPtr(uintptr_t Address) {
    constexpr uintptr_t MinUserAddress = 0x10000;
    constexpr uintptr_t MaxUserAddress = 0x7FFFFFFF0000ULL;

    if (!Address || Address < MinUserAddress || Address > MaxUserAddress)
        return false;

    MEMORY_BASIC_INFORMATION mbi{};
    if (!VirtualQuery(reinterpret_cast<LPCVOID>(Address), &mbi, sizeof(mbi)))
        return false;

    if (mbi.State != MEM_COMMIT)
        return false;

    return mbi.Protect != PAGE_NOACCESS && mbi.Protect != PAGE_GUARD;
}

static void TrackActor(uintptr_t actorPointer)
{
    if (!actorPointer || !IsValidPtr(actorPointer))
        return;

    std::lock_guard<std::mutex> lock(g_actor_scan_mutex);
    for (const auto& tracked : g_tracked_actors) {
        if (tracked && *tracked == actorPointer)
            return;
    }

    g_tracked_actors.emplace_back(std::make_shared<uintptr_t>(actorPointer));
}

static void RegisterActorThread(lua_State* thread)
{
    if (!thread)
        return;

    std::lock_guard<std::mutex> lock(g_actor_scan_mutex);
    g_tracked_actor_threads.insert(thread);
}

namespace Actors
{
    int getactors(lua_State* L) {
        lua_newtable(L);
        int idx = 1;

        lua_getglobal(L, ENV_OBF("game"));
        if (lua_isuserdata(L, -1)) {
            lua_getfield(L, -1, ENV_OBF("GetDescendants"));
            if (lua_isfunction(L, -1)) {
                lua_pushvalue(L, -2);
                if (lua_pcall(L, 1, 1, 0) == 0 && lua_istable(L, -1)) {
                    lua_pushnil(L);
                    while (lua_next(L, -2)) {
                        if (lua_isuserdata(L, -1)) {
                            lua_getfield(L, -1, ENV_OBF("ClassName"));
                            if (lua_isstring(L, -1) &&
                                strcmp(lua_tostring(L, -1), ENV_OBF("Actor")) == 0) {
                                lua_pop(L, 1);
                                lua_pushvalue(L, -1);
                                lua_rawseti(L, 1, idx++);
                            }
                            else {
                                lua_pop(L, 1);
                            }
                        }
                        lua_pop(L, 1);
                    }
                }
                lua_pop(L, 1);
            }
            else {
                lua_pop(L, 1);
            }
        }
        lua_pop(L, 1);

        return 1;
    }

    inline int isparallel(lua_State* L)
    {
        if (!L)
            return 0;

        lua_check(L, 0);

        const auto extra = reinterpret_cast<RobloxExtraSpace*>(reinterpret_cast<std::uintptr_t>(L->userdata));

        if (!extra)
        {
            lua_pushboolean(L, false);
            return 1;
        }

        auto actorPtr = extra->Actor.lock();
        if (!actorPtr)
        {
            lua_pushboolean(L, false);
            return 1;
        }

        const auto actor = reinterpret_cast<std::uintptr_t>(actorPtr.get());
        if (!actor)
        {
            lua_pushboolean(L, false);
            return 1;
        }

        std::uintptr_t inner = 0;
        if (!signal_safe_read(
            reinterpret_cast<const void*>(actor + 0x18),
            &inner, sizeof(inner)) || !inner)
        {
            lua_pushboolean(L, false);
            return 1;
        }

        std::uintptr_t v8 = 0;
        if (!signal_safe_read(
            reinterpret_cast<const void*>(inner + 0x28),
            &v8, sizeof(v8)) || !v8)
        {
            lua_pushboolean(L, false);
            return 1;
        }

        std::uint8_t parallel = 0;
        if (!signal_safe_read(
            reinterpret_cast<const void*>(v8 + 0x100),
            &parallel, sizeof(parallel)))
        {
            lua_pushboolean(L, false);
            return 1;
        }

        lua_pushboolean(L, parallel != 0);
        return 1;
    }

    int run_on_actor(lua_State* L) {
        luaL_checktype(L, 1, LUA_TUSERDATA);
        luaL_checktype(L, 2, LUA_TSTRING);

        lua_getfield(L, 1, ENV_OBF("ClassName"));
        const auto class_name = std::string_view(lua_tolstring(L, -1, nullptr));
        lua_pop(L, 1);

        if (class_name != ENV_OBF("Actor")) {
            luaL_argerrorL(L, 1, ENV_OBF("Actor expected"));
            return 0;
        }

        auto actor = *reinterpret_cast<__int64*>(lua_touserdata(L, 1));
        TrackActor(static_cast<uintptr_t>(actor));
        auto Code = lua_tostring(L, 2);

        lua_remove(L, 2);
        lua_remove(L, 1);

        int Args = lua_gettop(L);

        lua_getglobal(L, ENV_OBF("Instance"));
        lua_getfield(L, -1, ENV_OBF("new"));
        lua_pushstring(L, ENV_OBF("LocalScript"));
        lua_call(L, 1, 1);

        auto LocalScript = *reinterpret_cast<uintptr_t*>(lua_touserdata(L, -1));

        *reinterpret_cast<std::uintptr_t*>(LocalScript + Offsets::Actor::Parent) = actor;

        const std::uintptr_t ScriptContext = L->userdata->shared->scriptContext;

        uintptr_t unused = 0;
        lua_State* ActorState = reinterpret_cast<lua_State*>(TaskScheduler::GetLuaState(ScriptContext, unused, LocalScript));

        auto NL = lua_newthread(ActorState);
        RegisterActorThread(NL);

        lua_pop(ActorState, 1);

        NL->userdata->Actor = std::make_shared<uintptr_t>(static_cast<uintptr_t>(actor));

        TaskScheduler::SetThreadCapabilities(NL, 8, MaxCapabilities);
        luaL_sandboxthread(NL);

        lua_settop(NL, 0);

        lua_newtable(NL);
        lua_setglobal(NL, ENV_OBF("_G"));

        lua_newtable(NL);
        lua_setglobal(NL, ENV_OBF("shared"));
        Http::RegisterLibrary(L);
        Crypt::RegisterLibrary(L);
        Input::RegisterLibrary(L);
        Debug::RegisterLibrary(L);
        Cache::RegisterLibrary(L);
        Signals::RegisterLibrary(L);
        Script::RegisterLibrary(L);
        Closures::RegisterLibrary(L);
        Instance::RegisterLibrary(L);
        Websocket::Start(L);
        Metatable::RegisterLibrary(L);
        Filesystem::RegisterLibrary(L);
        Reflection::RegisterLibrary(L);
        Miscellaneous::RegisterLibrary(L);
        Regex::RegisterLibrary(L);
        FileDialog::RegisterLibrary(L);

        std::function<void(lua_State*, lua_State*, int)> deepCopy = [&](lua_State* src, lua_State* dst, int idx)
            {
                int absIdx = idx < 0 ? lua_gettop(src) + idx + 1 : idx;

                switch (lua_type(src, absIdx))
                {
                case LUA_TTABLE:
                {
                    lua_newtable(dst);
                    lua_pushnil(src);
                    while (lua_next(src, absIdx))
                    {
                        deepCopy(src, dst, -2);
                        deepCopy(src, dst, -1);
                        lua_settable(dst, -3);
                        lua_pop(src, 1);
                    }
                    break;
                }
                case LUA_TUSERDATA:
                {
                    if (strcmp(luaL_typename(src, absIdx), ENV_OBF("Instance")) == 0)
                    {
                        Roblox::Void2(dst, lua_touserdata(src, absIdx));
                    }
                    else
                    {
                        lua_pushvalue(src, absIdx);
                        lua_xmove(src, dst, 1);
                    }
                    break;
                }
                case LUA_TSTRING:
                {
                    size_t len = 0;
                    const char* str = lua_tolstring(src, absIdx, &len);
                    lua_pushlstring(dst, str, len);
                    break;
                }
                case LUA_TNUMBER:
                    lua_pushnumber(dst, lua_tonumber(src, absIdx));
                    break;
                case LUA_TBOOLEAN:
                    lua_pushboolean(dst, lua_toboolean(src, absIdx));
                    break;
                case LUA_TNIL:
                    lua_pushnil(dst);
                    break;
                default:
                    lua_pushvalue(src, absIdx);
                    lua_xmove(src, dst, 1);
                    break;
                }
            };

        std::string Bytecode = Execution::CompileScript(Code);


        int LoadResult = luau_load(NL, OBF("Xploits"), Bytecode.c_str(), Bytecode.size(), 0);
        if (LoadResult == LUA_OK) {
            if (Closure* Cl = clvalue(luaA_toobject(NL, -1))) {
                if (Cl && Cl->l.p) {
                    TaskScheduler::SetProtoCapabilities(Cl->l.p, &MaxCapabilities);
                }
            }
            for (int i{ 1 }; i <= Args; i++)
            {
                deepCopy(L, NL, i);
            }

            Roblox::TaskDefer(NL);
        }
        else {
            const char* err = lua_tostring(NL, -1);
            lua_pop(NL, 1);

            luaL_error(L, OBF("%s"), err);
            return 0;
        }
        return 0;
    }

    int run_on_thread(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TSTRING);
        const char* Code = lua_tostring(L, 1);

        lua_State* NL = lua_newthread(L);
        lua_pop(L, 1);

        TaskScheduler::SetThreadCapabilities(NL, 8, MaxCapabilities);
        luaL_sandboxthread(NL);
        lua_settop(NL, 0);

        std::string Bytecode = Execution::CompileScript(Code);
        int LoadResult = luau_load(NL, OBF("Xploits"), Bytecode.c_str(), Bytecode.size(), 0);

        if (LoadResult != LUA_OK)
        {
            const char* err = lua_tostring(NL, -1);
            lua_pop(NL, 1);
            luaL_error(L, OBF("%s"), err);
            return 0;
        }

        if (Closure* Cl = clvalue(luaA_toobject(NL, -1)))
            if (Cl && Cl->l.p)
                TaskScheduler::SetProtoCapabilities(Cl->l.p, &MaxCapabilities);

        lua_pushcfunction(L, [](lua_State* innerL) -> int
            {
                lua_State* NL = reinterpret_cast<lua_State*>(lua_tolightuserdata(innerL, lua_upvalueindex(1)));

                Roblox::TaskDefer(NL);
                return 0;
            }, nullptr, 1);

        lua_pushlightuserdata(L, reinterpret_cast<void*>(NL));
        lua_pushcclosure(L, [](lua_State* innerL) -> int
            {
                lua_State* NL = reinterpret_cast<lua_State*>(lua_tolightuserdata(innerL, lua_upvalueindex(1)));

                Roblox::TaskDefer(NL);
                return 0;
            }, ENV_OBF("run_on_thread_closure"), 1);

        return 1;
    }

    void RegisterLibrary(lua_State* L)
    {
        if (!L) return;

        Utils::AddFunction(L, ENV_OBF("getactors"), getactors);
        Utils::AddFunction(L, ENV_OBF("isparallel"), isparallel);
        Utils::AddFunction(L, ENV_OBF("checkparallel"), isparallel);
        Utils::AddFunction(L, ENV_OBF("run_on_actor"), run_on_actor);
        Utils::AddFunction(L, ENV_OBF("runonactor"), run_on_actor);
        Utils::AddFunction(L, ENV_OBF("runonthread"), run_on_thread);
    }
}