#include "raknet.hpp"
#include <Globals.hpp>

#include <cstring>
#include <string>
#include <vector>
#include <memory>
#include <new>
#include <algorithm>
#include <unordered_map>
#include "lua.h"
#include "lualib.h"

#include <Utils.hpp>

#ifndef lua_objlen
#define lua_objlen lua_objlen
#endif

#ifndef lua_equal
#define lua_equal(L, a, b) lua_rawequal((L), (a), (b))
#endif

#ifndef LUA_NOREF
#define LUA_NOREF (-2)
#endif



namespace raknet {
    namespace {

        const char* kPacketMt = OBF("RakNetPacket");
        const char* kHookRegistry = OBF("RakNetSendHooks");

        struct PacketUserdata {
            PacketSnapshot snap;
        };

        PacketUserdata* check_packet(lua_State* L, int idx) {
            return static_cast<PacketUserdata*>(luaL_checkudata(L, idx, kPacketMt));
        }

        void push_packet(lua_State* L, const PacketSnapshot& snap) {
            auto* ud = static_cast<PacketUserdata*>(lua_newuserdata(L, sizeof(PacketUserdata)));
            new (ud) PacketUserdata{ snap };
            luaL_getmetatable(L, kPacketMt);
            lua_setmetatable(L, -2);
        }

        int packet_gc(lua_State* L) {
            auto* ud = check_packet(L, 1);
            ud->~PacketUserdata();
            return 0;
        }

        int packet_set_data(lua_State* L) {
            auto* ud = check_packet(L, 1);
            std::vector<std::uint8_t> bytes;

            const int t = lua_type(L, 2);
            if (t == LUA_TSTRING) {
                std::size_t n = 0;
                const char* s = lua_tolstring(L, 2, &n);
                bytes.assign(s, s + n);
            }
            else if (t == LUA_TTABLE) {
                const std::size_t n = static_cast<std::size_t>(lua_objlen(L, 2));
                bytes.resize(n);
                for (std::size_t i = 0; i < n; ++i) {
                    lua_rawgeti(L, 2, static_cast<int>(i + 1));
                    const lua_Number v = lua_tonumber(L, -1);
                    lua_pop(L, 1);
                    if (v != v || v < 0 || v > 255 || v != static_cast<int>(v))
                        lua_pushstring(L, OBF("byte array values must be integers 0..255"));
                    bytes[i] = static_cast<std::uint8_t>(v);
                }
            }
            else {
                lua_pushstring(L, OBF("SetData expects string or {number}"));
            }

            if (bytes.empty())
                lua_pushstring(L, OBF("empty payload"));
            if (bytes.size() > raknet::ver::d66094bc9ae84754::kMaxSendBytes)
                lua_pushstring(L, OBF("payload too large"));

            ud->snap.data = std::move(bytes);
            ud->snap.size = static_cast<std::uint32_t>(ud->snap.data.size());
            ud->snap.captured_size = static_cast<std::uint32_t>(
                (std::min)(ud->snap.data.size(), raknet::ver::d66094bc9ae84754::kMaxCaptureBytes));
            ud->snap.truncated = ud->snap.size > ud->snap.captured_size;
            ud->snap.packet_id = ud->snap.data[0];
            ud->snap.item_id = ud->snap.data.size() > 1 ? ud->snap.data[1] : 0;
            ud->snap.modified = true;

            if (ud->snap.live && ud->snap.live_bytes && ud->snap.live_size) {
                const std::uint32_t n = static_cast<std::uint32_t>(ud->snap.data.size());
                const std::uint32_t cap = ud->snap.live_capacity ? ud->snap.live_capacity : *ud->snap.live_size;
                if (n <= cap) {
                    std::memcpy(ud->snap.live_bytes, ud->snap.data.data(), n);
                    *ud->snap.live_size = n;
                }
            }
            return 0;
        }

        int packet_block(lua_State* L) {
            auto* ud = check_packet(L, 1);
            ud->snap.blocked = true;
            return 0;
        }

        int packet_index(lua_State* L) {
            auto* ud = check_packet(L, 1);
            const char* key = luaL_checkstring(L, 2);
            const PacketSnapshot& s = ud->snap;

            if (std::strcmp(key, ENV_OBF("Direction")) == 0) {
                lua_pushstring(L, s.direction == Direction::Outgoing ? OBF("Outgoing") : OBF("Incoming"));
                return 1;
            }
            if (std::strcmp(key, ENV_OBF("PacketId")) == 0) {
                lua_pushinteger(L, s.packet_id);
                return 1;
            }
            if (std::strcmp(key, ENV_OBF("ItemId")) == 0) {
                lua_pushinteger(L, s.item_id);
                return 1;
            }
            if (std::strcmp(key, ENV_OBF("Priority")) == 0) {
                lua_pushinteger(L, s.priority);
                return 1;
            }
            if (std::strcmp(key, ENV_OBF("Reliability")) == 0) {
                lua_pushinteger(L, s.reliability);
                return 1;
            }
            if (std::strcmp(key, ENV_OBF("OrderingChannel")) == 0) {
                lua_pushinteger(L, s.ordering_channel);
                return 1;
            }
            if (std::strcmp(key, ENV_OBF("Size")) == 0) {
                lua_pushinteger(L, static_cast<lua_Integer>(s.size));
                return 1;
            }
            if (std::strcmp(key, ENV_OBF("CapturedSize")) == 0) {
                lua_pushinteger(L, static_cast<lua_Integer>(s.captured_size));
                return 1;
            }
            if (std::strcmp(key, ENV_OBF("Truncated")) == 0) {
                lua_pushboolean(L, s.truncated ? 1 : 0);
                return 1;
            }
            if (std::strcmp(key, ENV_OBF("Sequence")) == 0) {
                lua_pushnumber(L, static_cast<lua_Number>(s.sequence));
                return 1;
            }
            if (std::strcmp(key, ENV_OBF("Timestamp")) == 0) {
                lua_pushnumber(L, static_cast<lua_Number>(s.timestamp));
                return 1;
            }
            if (std::strcmp(key, ENV_OBF("Modified")) == 0) {
                lua_pushboolean(L, s.modified ? 1 : 0);
                return 1;
            }
            if (std::strcmp(key, ENV_OBF("Blocked")) == 0) {
                lua_pushboolean(L, s.blocked ? 1 : 0);
                return 1;
            }
            if (std::strcmp(key, ENV_OBF("Data")) == 0 || std::strcmp(key, ENV_OBF("AsString")) == 0) {
                lua_pushlstring(L, reinterpret_cast<const char*>(s.data.data()), s.data.size());
                return 1;
            }
            if (std::strcmp(key, ENV_OBF("AsArray")) == 0) {
                lua_createtable(L, static_cast<int>(s.data.size()), 0);
                for (std::size_t i = 0; i < s.data.size(); ++i) {
                    lua_pushinteger(L, s.data[i]);
                    lua_rawseti(L, -2, static_cast<int>(i + 1));
                }
                return 1;
            }
            if (std::strcmp(key, ENV_OBF("AsBuffer")) == 0) {
                lua_pushlstring(L, reinterpret_cast<const char*>(s.data.data()), s.data.size());
                return 1;
            }
            if (std::strcmp(key, ENV_OBF("SetData")) == 0) {
                lua_pushcfunction(L, packet_set_data, OBF("packet_set_data"));
                return 1;
            }
            if (std::strcmp(key, ENV_OBF("Block")) == 0) {
                lua_pushcfunction(L, packet_block, OBF("packet_block"));
                return 1;
            }
            return 0;
        }

        void ensure_packet_mt(lua_State* L) {
            if (luaL_newmetatable(L, kPacketMt)) {
                lua_pushcfunction(L, packet_index, OBF("packet_index"));
                lua_setfield(L, -2, ENV_OBF("__index"));
                lua_pushcfunction(L, packet_gc, OBF("packet_gc"));
                lua_setfield(L, -2, ENV_OBF("__gc"));
            }
            lua_pop(L, 1);
        }

        struct LuaHookBridge {
            lua_State* L = nullptr;
            int func_ref = LUA_NOREF;
            std::uint64_t hook_id = 0;
            bool receive = false;
        };

        std::unordered_map<int, LuaHookBridge> g_send_bridges;
        LuaHookBridge g_recv_bridge;

        void invoke_lua_packet(lua_State* L, int func_ref, PacketSnapshot& snap, bool allow_mutate) {
            if (!L || func_ref == LUA_NOREF)
                return;
            lua_rawgeti(L, LUA_REGISTRYINDEX, func_ref);
            if (!lua_isfunction(L, -1)) {
                lua_pop(L, 1);
                return;
            }
            push_packet(L, snap);
            if (lua_pcall(L, 1, 0, 0) != 0) {
                lua_pop(L, 1);
                return;
            }
            (void)allow_mutate;
        }

        struct PacketUserdataLive {
            PacketSnapshot* live = nullptr;
            PacketSnapshot owned;
            bool uses_live = false;
        };

        thread_local PacketSnapshot* g_callback_snap = nullptr;

        int packet_index_v2(lua_State* L);
        int packet_set_data_v2(lua_State* L);
        int packet_block_v2(lua_State* L);

        PacketSnapshot& packet_ref(lua_State* L, int idx) {
            auto* ud = static_cast<PacketUserdata*>(luaL_checkudata(L, idx, kPacketMt));
            if (g_callback_snap)
                return *g_callback_snap;
            return ud->snap;
        }

        int packet_set_data_v2(lua_State* L) {
            PacketSnapshot& snap = packet_ref(L, 1);
            std::vector<std::uint8_t> bytes;
            const int t = lua_type(L, 2);
            if (t == LUA_TSTRING) {
                std::size_t n = 0;
                const char* s = lua_tolstring(L, 2, &n);
                bytes.assign(s, s + n);
            }
            else if (t == LUA_TTABLE) {
                const std::size_t n = static_cast<std::size_t>(lua_objlen(L, 2));
                bytes.resize(n);
                for (std::size_t i = 0; i < n; ++i) {
                    lua_rawgeti(L, 2, static_cast<int>(i + 1));
                    const lua_Number v = lua_tonumber(L, -1);
                    lua_pop(L, 1);
                    if (v < 0 || v > 255 || static_cast<int>(v) != v)
                        lua_pushstring(L, OBF("byte array values must be integers 0..255"));
                    bytes[i] = static_cast<std::uint8_t>(v);
                }
            }
            else {
                lua_pushstring(L, OBF("SetData expects string or {number}"));
            }
            if (bytes.empty())
                lua_pushstring(L, OBF("empty payload"));

            snap.data = std::move(bytes);
            snap.size = static_cast<std::uint32_t>(snap.data.size());
            snap.captured_size = static_cast<std::uint32_t>(
                (std::min<std::size_t>)(snap.data.size(),
                    static_cast<std::size_t>(raknet::ver::d66094bc9ae84754::kMaxCaptureBytes)));
            snap.truncated = snap.size > snap.captured_size;
            snap.packet_id = snap.data[0];
            snap.item_id = snap.data.size() > 1 ? snap.data[1] : 0;
            snap.modified = true;

            if (snap.live && snap.live_bytes && snap.live_size) {
                const std::uint32_t n = static_cast<std::uint32_t>(snap.data.size());
                const std::uint32_t cap = snap.live_capacity ? snap.live_capacity : *snap.live_size;
                if (n <= cap) {
                    std::memcpy(snap.live_bytes, snap.data.data(), n);
                    *snap.live_size = n;
                }
            }
            return 0;
        }

        int packet_block_v2(lua_State* L) {
            packet_ref(L, 1).blocked = true;
            return 0;
        }

        int packet_index_v2(lua_State* L) {
            PacketSnapshot& s = packet_ref(L, 1);
            const char* key = luaL_checkstring(L, 2);

            auto push_bool = [&](bool v) {
                lua_pushboolean(L, v ? 1 : 0);
                return 1;
                };

            if (!std::strcmp(key, ENV_OBF("Direction"))) {
                lua_pushstring(L, s.direction == Direction::Outgoing ? OBF("Outgoing") : OBF("Incoming"));
                return 1;
            }
            if (!std::strcmp(key, ENV_OBF("PacketId"))) {
                lua_pushinteger(L, s.packet_id);
                return 1;
            }
            if (!std::strcmp(key, ENV_OBF("ItemId"))) {
                lua_pushinteger(L, s.item_id);
                return 1;
            }
            if (!std::strcmp(key, ENV_OBF("Priority"))) {
                lua_pushinteger(L, s.priority);
                return 1;
            }
            if (!std::strcmp(key, ENV_OBF("Reliability"))) {
                lua_pushinteger(L, s.reliability);
                return 1;
            }
            if (!std::strcmp(key, ENV_OBF("OrderingChannel"))) {
                lua_pushinteger(L, s.ordering_channel);
                return 1;
            }
            if (!std::strcmp(key, ENV_OBF("Size"))) {
                lua_pushinteger(L, (lua_Integer)s.size);
                return 1;
            }
            if (!std::strcmp(key, ENV_OBF("CapturedSize"))) {
                lua_pushinteger(L, (lua_Integer)s.captured_size);
                return 1;
            }
            if (!std::strcmp(key, ENV_OBF("Truncated")))
                return push_bool(s.truncated);
            if (!std::strcmp(key, ENV_OBF("Sequence"))) {
                lua_pushnumber(L, (lua_Number)s.sequence);
                return 1;
            }
            if (!std::strcmp(key, ENV_OBF("Timestamp"))) {
                lua_pushnumber(L, (lua_Number)s.timestamp);
                return 1;
            }
            if (!std::strcmp(key, ENV_OBF("Modified")))
                return push_bool(s.modified);
            if (!std::strcmp(key, ENV_OBF("Blocked")))
                return push_bool(s.blocked);
            if (!std::strcmp(key, ENV_OBF("Data")) || !std::strcmp(key, ENV_OBF("AsString")) || !std::strcmp(key, ENV_OBF("AsBuffer"))) {
                lua_pushlstring(L, reinterpret_cast<const char*>(s.data.data()), s.data.size());
                return 1;
            }
            if (!std::strcmp(key, ENV_OBF("AsArray"))) {
                lua_createtable(L, (int)s.data.size(), 0);
                for (std::size_t i = 0; i < s.data.size(); ++i) {
                    lua_pushinteger(L, s.data[i]);
                    lua_rawseti(L, -2, (int)i + 1);
                }
                return 1;
            }
            if (!std::strcmp(key, ENV_OBF("SetData"))) {
                lua_pushcfunction(L, packet_set_data_v2, OBF("packet_set_data_v2"));
                return 1;
            }
            if (!std::strcmp(key, ENV_OBF("Block"))) {
                lua_pushcfunction(L, packet_block_v2, OBF("packet_block_v2"));
                return 1;
            }
            return 0;
        }

        void call_lua_hook(lua_State* L, int func_ref, PacketSnapshot& snap) {
            if (!L || func_ref == LUA_NOREF)
                return;
            lua_rawgeti(L, LUA_REGISTRYINDEX, func_ref);
            if (!lua_isfunction(L, -1)) {
                lua_pop(L, 1);
                return;
            }

            g_callback_snap = &snap;
            push_packet(L, snap);
            const int err = lua_pcall(L, 1, 0, 0);
            g_callback_snap = nullptr;
            if (err != 0)
                lua_pop(L, 1);
        }

        std::vector<std::uint8_t> read_payload_arg(lua_State* L, int idx) {
            std::vector<std::uint8_t> bytes;
            const int t = lua_type(L, idx);
            if (t == LUA_TSTRING) {
                std::size_t n = 0;
                const char* s = lua_tolstring(L, idx, &n);
                bytes.assign(s, s + n);
            }
            else if (t == LUA_TTABLE) {
                const std::size_t n = static_cast<std::size_t>(lua_objlen(L, idx));
                bytes.resize(n);
                for (std::size_t i = 0; i < n; ++i) {
                    lua_rawgeti(L, idx, static_cast<int>(i + 1));
                    const lua_Number v = lua_tonumber(L, -1);
                    lua_pop(L, 1);
                    if (v < 0 || v > 255 || static_cast<int>(v) != v)
                        luaL_error(L, OBF("byte array values must be integers 0..255"));
                    bytes[i] = static_cast<std::uint8_t>(v);
                }
            }
            else {
                luaL_error(L, OBF("payload must be string or {number}"));
            }
            return bytes;
        }

        int l_hooked(lua_State* L) {
            lua_pushboolean(L, Library::instance().hooked() ? 1 : 0);
            return 1;
        }

        int l_add_send_hook(lua_State* L) {
            luaL_checktype(L, 1, LUA_TFUNCTION);
            lua_pushvalue(L, 1);
            const int ref = lua_ref(L, LUA_REGISTRYINDEX);

            auto& lib = Library::instance();
            const std::uint64_t id = lib.add_send_hook_tracked([ref](PacketSnapshot& snap) {
                auto it = g_send_bridges.find(ref);
                if (it == g_send_bridges.end() || !it->second.L)
                    return;
                call_lua_hook(it->second.L, ref, snap);
                });

            g_send_bridges[ref] = LuaHookBridge{ L, ref, id, false };
            return 0;
        }

        int l_remove_send_hook(lua_State* L) {
            luaL_checktype(L, 1, LUA_TFUNCTION);
            for (auto it = g_send_bridges.begin(); it != g_send_bridges.end(); ++it) {
                lua_rawgeti(L, LUA_REGISTRYINDEX, it->second.func_ref);
                const bool eq = lua_equal(L, 1, -1) != 0;
                lua_pop(L, 1);
                if (eq) {
                    Library::instance().remove_send_hook_id(it->second.hook_id);
                    lua_unref(L, it->second.func_ref);
                    g_send_bridges.erase(it);
                    break;
                }
            }
            return 0;
        }

        int l_add_receive_hook(lua_State* L) {
            luaL_checktype(L, 1, LUA_TFUNCTION);
            if (g_recv_bridge.func_ref != LUA_NOREF)
                lua_unref(L, g_recv_bridge.func_ref);

            lua_pushvalue(L, 1);
            const int ref = lua_ref(L, LUA_REGISTRYINDEX);
            g_recv_bridge = LuaHookBridge{ L, ref, 0, true };

            Library::instance().add_receive_hook([ref](const PacketSnapshot& snap) {
                if (!g_recv_bridge.L)
                    return;
                PacketSnapshot copy = snap;
                call_lua_hook(g_recv_bridge.L, ref, copy);
                });
            return 0;
        }

        int l_remove_receive_hook(lua_State* L) {
            (void)L;
            Library::instance().remove_receive_hook();
            if (g_recv_bridge.func_ref != LUA_NOREF) {
                lua_unref(L, g_recv_bridge.func_ref);
                g_recv_bridge = {};
                g_recv_bridge.func_ref = LUA_NOREF;
            }
            return 0;
        }

        int l_send(lua_State* L) {
            auto bytes = read_payload_arg(L, 1);
            const int priority = lua_isnoneornil(L, 2) ? 1 : static_cast<int>(luaL_checkinteger(L, 2));
            const int reliability = lua_isnoneornil(L, 3) ? 3 : static_cast<int>(luaL_checkinteger(L, 3));
            const int channel = lua_isnoneornil(L, 4) ? 0 : static_cast<int>(luaL_checkinteger(L, 4));

            std::string err;
            if (!Library::instance().send(bytes.data(), bytes.size(), priority, reliability, channel, &err))
                lua_pushstring(L,  err.c_str());
            return 0;
        }

        int l_stats(lua_State* L) {
            Library::instance().drain_async_queue();
            const Statistics s = Library::instance().stats();
            lua_createtable(L, 0, 24);
            auto setb = [&](const char* k, bool v) {
                lua_pushboolean(L, v ? 1 : 0);
                lua_setfield(L, -2, k);
                };
            auto setn = [&](const char* k, lua_Number v) {
                lua_pushnumber(L, v);
                lua_setfield(L, -2, k);
                };
            auto sets = [&](const char* k, const std::string& v) {
                lua_pushlstring(L, v.data(), v.size());
                lua_setfield(L, -2, k);
                };

            setb(ENV_OBF("ready"), s.ready);
            setb(ENV_OBF("hooked"), s.hooked);
            setb(ENV_OBF("send"), s.send);
            setb(ENV_OBF("receive"), s.receive);
            setb(ENV_OBF("send_hooked"), s.send);
            setb(ENV_OBF("receive_hooked"), s.receive);
            setb(ENV_OBF("desync"), s.desync);
            sets(ENV_OBF("status"), s.status);
            sets(ENV_OBF("build"), s.build);
            setn(ENV_OBF("captured"), (lua_Number)s.captured);
            setn(ENV_OBF("dispatched"), (lua_Number)s.dispatched);
            setn(ENV_OBF("duplicates"), (lua_Number)s.duplicates);
            setn(ENV_OBF("dropped"), (lua_Number)s.dropped);
            setn(ENV_OBF("blocked_packets"), (lua_Number)s.blocked_packets);
            setn(ENV_OBF("mutated_packets"), (lua_Number)s.mutated_packets);
            setn(ENV_OBF("queued"), (lua_Number)s.queued);
            setn(ENV_OBF("capacity"), (lua_Number)s.capacity);
            setn(ENV_OBF("maximum_capture_size"), (lua_Number)s.maximum_capture_size);
            setn(ENV_OBF("send_callback_count"), (lua_Number)s.send_callback_count);
            setb(ENV_OBF("receive_callback"), s.receive_callback);
            setn(ENV_OBF("rule_count"), (lua_Number)s.rule_count);
            setn(ENV_OBF("blocked_count"), (lua_Number)s.blocked_count);

            lua_createtable(L, (int)s.rules.size(), 0);
            int i = 1;
            for (const auto& r : s.rules) {
                lua_createtable(L, 0, 5);
                lua_pushinteger(L, r.packet_id);
                lua_setfield(L, -2, ENV_OBF("id"));
                lua_pushinteger(L, r.value);
                lua_setfield(L, -2, ENV_OBF("value"));
                lua_pushinteger(L, r.start);
                lua_setfield(L, -2, ENV_OBF("start"));
                lua_pushinteger(L, r.stop);
                lua_setfield(L, -2, ENV_OBF("stop"));
                lua_pushboolean(L, r.enabled ? 1 : 0);
                lua_setfield(L, -2, ENV_OBF("enabled"));
                lua_rawseti(L, -2, i++);
            }
            lua_setfield(L, -2, ENV_OBF("rules"));

            lua_createtable(L, (int)s.blocked.size(), 0);
            for (std::size_t b = 0; b < s.blocked.size(); ++b) {
                lua_pushinteger(L, s.blocked[b]);
                lua_rawseti(L, -2, (int)b + 1);
            }
            lua_setfield(L, -2, ENV_OBF("blocked"));
            return 1;
        }

        int l_clear(lua_State* L) {
            (void)L;
            Library::instance().clear();
            return 0;
        }

        int l_desync(lua_State* L) {
            const bool en = lua_toboolean(L, 1) != 0;
            lua_pushboolean(L, Library::instance().desync(en) ? 1 : 0);
            return 1;
        }

        int l_set(lua_State* L) {
            const auto id = static_cast<std::uint8_t>(luaL_checkinteger(L, 1));
            const auto value = static_cast<std::uint8_t>(luaL_checkinteger(L, 2));
            const int start = lua_isnoneornil(L, 3) ? 0 : static_cast<int>(luaL_checkinteger(L, 3));
            const int stop = lua_isnoneornil(L, 4) ? 5 : static_cast<int>(luaL_checkinteger(L, 4));
            if (luaL_checkinteger(L, 1) < 0 || luaL_checkinteger(L, 1) > 255 ||
                luaL_checkinteger(L, 2) < 0 || luaL_checkinteger(L, 2) > 255)
                lua_pushstring(L, OBF("packetId/value must be 0..255"));
            Library::instance().set_rule(id, value, start, stop);
            return 0;
        }

        int l_toggle(lua_State* L) {
            const auto id = static_cast<std::uint8_t>(luaL_checkinteger(L, 1));
            const bool en = lua_toboolean(L, 2) != 0;
            Library::instance().toggle_rule(id, en);
            return 0;
        }

        int l_remove(lua_State* L) {
            const auto id = static_cast<std::uint8_t>(luaL_checkinteger(L, 1));
            Library::instance().remove_rule(id);
            return 0;
        }

        int l_block(lua_State* L) {
            const auto id = static_cast<std::uint8_t>(luaL_checkinteger(L, 1));
            const bool en = lua_isnoneornil(L, 2) ? true : (lua_toboolean(L, 2) != 0);
            lua_pushboolean(L, Library::instance().block(id, en) ? 1 : 0);
            return 1;
        }

        int l_unblock(lua_State* L) {
            const auto id = static_cast<std::uint8_t>(luaL_checkinteger(L, 1));
            Library::instance().unblock(id);
            return 0;
        }

        int l_drain(lua_State* L) {
            (void)L;
            Library::instance().drain_async_queue();
            return 0;
        }

    }

    void register_lua(lua_State* L) {
            ensure_packet_mt(L);

            luaL_getmetatable(L, kPacketMt);

            lua_pushcclosurek(L, packet_index_v2, OBF("__index"), 0, nullptr);
            lua_setfield(L, -2, ENV_OBF("__index"));

            lua_pushcclosurek(L, packet_gc, OBF("__gc"), 0, nullptr);
            lua_setfield(L, -2, ENV_OBF("__gc"));

            lua_pop(L, 1);

            lua_newtable(L);

            Utils::AddTableFunction(L, ENV_OBF("add_send_hook"), l_add_send_hook);
            Utils::AddTableFunction(L, ENV_OBF("remove_send_hook"), l_remove_send_hook);

            Utils::AddTableFunction(L, ENV_OBF("add_receive_hook"), l_add_receive_hook);
            Utils::AddTableFunction(L, ENV_OBF("remove_receive_hook"), l_remove_receive_hook);

            Utils::AddTableFunction(L, ENV_OBF("send"), l_send);
            Utils::AddTableFunction(L, ENV_OBF("hooked"), l_hooked);
            Utils::AddTableFunction(L, ENV_OBF("stats"), l_stats);
            Utils::AddTableFunction(L, ENV_OBF("clear"), l_clear);
            Utils::AddTableFunction(L, ENV_OBF("desync"), l_desync);

            Utils::AddTableFunction(L, ENV_OBF("set"), l_set);
            Utils::AddTableFunction(L, ENV_OBF("toggle"), l_toggle);
            Utils::AddTableFunction(L, ENV_OBF("remove"), l_remove);

            Utils::AddTableFunction(L, ENV_OBF("block"), l_block);
            Utils::AddTableFunction(L, ENV_OBF("unblock"), l_unblock);

            Utils::AddTableFunction(L, ENV_OBF("drain"), l_drain);

            lua_setglobal(L, ENV_OBF("raknet"));
    }
    
}
