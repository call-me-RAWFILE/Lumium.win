#pragma once

#include <cstdint>
#include <cstddef>

namespace raknet::ver::d66094bc9ae84754 {

	inline constexpr const char* kNetPeerSendJobName = "Net Peer Send";
	inline constexpr std::uint32_t kJobPeerSharedPtr = 0x1D0;
	inline constexpr std::uint32_t kJobPeerSharedPtrRep = 0x1D8;
	inline constexpr std::uint32_t kJobPeerRawFallback = 0x218;

	inline constexpr std::uintptr_t kRakPeerVftableRva = 0x653FC80;
	inline constexpr int kSendSharedVtableIndex = 0x14;
	inline constexpr int kDistributeVtableIndex = 0x19;
	inline constexpr int kVftableCloneSlots = 160;

	inline constexpr std::uintptr_t kSendSharedRva = 0x40C2D80;
	inline constexpr std::uintptr_t kDistributeRva = 0x40C7340;
	inline constexpr std::uintptr_t kNetworkStreamVftableRva = 0x64859F0;
	inline constexpr std::uintptr_t kNetPeerSendJobStepRva = 0x2454800;

	inline constexpr std::uint32_t kStreamDataPtr = 0x10;
	inline constexpr std::uint32_t kStreamBytesUsed = 0x30;
	inline constexpr std::uint32_t kStreamBytesAlloc = 0x34;
	inline constexpr std::uint32_t kStreamReadOffset = 0x38;
	inline constexpr std::uint32_t kStreamOwnedData = 0x3E;
	inline constexpr std::size_t kNetworkStreamSize = 0x40;

	inline constexpr std::uint32_t kPacketLength = 0x30;
	inline constexpr std::uint32_t kPacketData = 0x38;

	inline constexpr std::uint32_t kReturnQueueCs = 0x928;
	inline constexpr std::uint32_t kReturnQueueBuf = 0x950;
	inline constexpr std::uint32_t kReturnQueueRead = 0x958;
	inline constexpr std::uint32_t kReturnQueueWrite = 0x95C;
	inline constexpr std::uint32_t kReturnQueueCap = 0x960;

	inline constexpr std::size_t kMaxCaptureBytes = 4096;
	inline constexpr std::size_t kMaxSendBytes = 1024 * 1024;
	inline constexpr std::size_t kCaptureQueueCapacity = 2048;
	inline constexpr std::size_t kDedupWindow = 64;

	inline constexpr std::uint8_t kIdPhysics = 0x1B;
	inline constexpr std::uint8_t kIdData = 0x83;

}
