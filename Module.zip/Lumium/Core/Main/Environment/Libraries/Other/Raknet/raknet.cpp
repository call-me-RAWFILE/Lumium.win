#include "raknet.hpp"
#include <Globals.hpp>

#include <cstring>
#include <stdexcept>
#include <chrono>
#include <algorithm>

#if defined(_WIN32)
#  ifndef WIN32_LEAN_AND_MEAN
#    define WIN32_LEAN_AND_MEAN
#  endif
#  include <Windows.h>
#endif

using namespace raknet::ver::d66094bc9ae84754;

namespace raknet {
    namespace {

        using SendFn = std::int64_t(__fastcall*)(std::int64_t*, std::int64_t*, int, int, char,
            std::int64_t*, bool, std::uint32_t, std::uint64_t);
        using DistributeFn = const char* (__fastcall*)(std::int64_t, char);

        thread_local bool g_in_manual_send = false;

#pragma pack(push, 1)
        struct NetworkStream {
            void* vftable = nullptr;
            std::uint8_t flag = 0;
            std::uint8_t pad0[7]{};
            std::uint8_t* data = nullptr;
            std::uint64_t vec_begin = 0;
            std::uint64_t vec_mid = 0;
            std::uint64_t vec_end = 0;
            std::uint32_t bytes_used = 0;
            std::uint32_t bytes_alloc = 0;
            std::uint32_t read_offset = 0;
            std::uint8_t b3c = 0;
            std::uint8_t b3d = 0;
            std::uint8_t owned = 0;
            std::uint8_t b3f = 0;
        };
#pragma pack(pop)

        static_assert(sizeof(NetworkStream) == kNetworkStreamSize, "NetworkStream size mismatch");

        std::uint64_t tick64() {
#if defined(_WIN32)
            return static_cast<std::uint64_t>(::GetTickCount64());
#else
            using namespace std::chrono;
            return duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();
#endif
        }

        std::uint64_t hash_payload(const std::uint8_t* p, std::size_t n, Direction dir) {
            std::uint64_t h = 14695981039346656037ull ^ (static_cast<std::uint64_t>(dir) << 56);
            const std::size_t lim = (std::min)(n, std::size_t{ 64 });
            for (std::size_t i = 0; i < lim; ++i) {
                h ^= p[i];
                h *= 1099511628211ull;
            }
            h ^= n;
            return h;
        }

        std::int64_t __fastcall trampoline_send(std::int64_t* self, std::int64_t* bs, int prio, int rel,
            char ch, std::int64_t* sys, bool broadcast,
            std::uint32_t receipt, std::uint64_t unk) {
            return Library::instance().on_send_shared(self, bs, prio, rel, ch, sys, broadcast, receipt, unk);
        }

        const char* __fastcall trampoline_distribute(std::int64_t self, char flag) {
            return Library::instance().on_distribute(self, flag);
        }

    }

    Library& Library::instance() {
        static Library g;
        return g;
    }

    void Library::set_host(HostHooks host) {
        std::lock_guard lock(mu_);
        host_ = std::move(host);
    }

    bool Library::is_hooked() const {
        std::lock_guard lock(mu_);
        return send_hooked_ && recv_hooked_;
    }

    bool Library::desync() const {
        std::lock_guard lock(mu_);
        return desync_;
    }

    std::uintptr_t Library::resolve_peer() const {
        if (!host_.get_job_by_name)
            return 0;

        const std::uintptr_t job = host_.get_job_by_name(kNetPeerSendJobName);
        if (!job)
            return 0;

        std::uintptr_t peer = *reinterpret_cast<std::uintptr_t*>(job + kJobPeerSharedPtr);
        if (peer) {
            void** vt = *reinterpret_cast<void***>(peer);
            if (vt) {
                return peer;
            }
        }

        peer = *reinterpret_cast<std::uintptr_t*>(job + kJobPeerRawFallback);
        if (peer && *reinterpret_cast<void***>(peer))
            return peer;

        return 0;
    }

    bool Library::install_hooks() {
        const std::uintptr_t peer = resolve_peer();
        if (!peer) {
            status_ = std::string(OBF("peer_not_found"));
            ready_ = false;
            return false;
        }

        void** original_vt = *reinterpret_cast<void***>(peer);
        if (!original_vt) {
            status_ = std::string(OBF("vftable_missing"));
            return false;
        }

        if (hooked_vftable_ && peer_ == peer) {
            original_send_ = original_vt[kSendSharedVtableIndex];
            original_distribute_ = original_vt[kDistributeVtableIndex];
            if (*reinterpret_cast<void***>(peer) == hooked_vftable_) {
                send_hooked_ = true;
                recv_hooked_ = true;
                ready_ = true;
                status_ = std::string(OBF("ok"));
                return true;
            }
        }

        auto* clone = new void* [kVftableCloneSlots];
        std::memcpy(clone, original_vt, sizeof(void*) * kVftableCloneSlots);

        original_send_ = original_vt[kSendSharedVtableIndex];
        original_distribute_ = original_vt[kDistributeVtableIndex];

        clone[kSendSharedVtableIndex] = reinterpret_cast<void*>(&trampoline_send);
        clone[kDistributeVtableIndex] = reinterpret_cast<void*>(&trampoline_distribute);

        *reinterpret_cast<void***>(peer) = clone;

        (void)kRakPeerVftableRva;

        peer_ = peer;
        original_vftable_ = original_vt;
        hooked_vftable_ = clone;
        send_hooked_ = true;
        recv_hooked_ = true;
        ready_ = true;
        status_ = std::string(OBF("ok"));
        return true;
    }

    bool Library::hooked() {
        std::lock_guard lock(mu_);
        if (send_hooked_ && recv_hooked_)
            return true;
        return install_hooks();
    }

    void Library::add_send_hook(SendHookFn cb) {
        std::lock_guard lock(mu_);
        send_hooks_.emplace_back(next_send_hook_id_++, std::move(cb));
    }

    std::uint64_t Library::add_send_hook_tracked(SendHookFn cb) {
        std::lock_guard lock(mu_);
        const std::uint64_t id = next_send_hook_id_++;
        send_hooks_.emplace_back(id, std::move(cb));
        return id;
    }

    bool Library::remove_send_hook_id(std::uint64_t id) {
        std::lock_guard lock(mu_);
        const auto it = std::remove_if(send_hooks_.begin(), send_hooks_.end(),
            [id](const auto& p) { return p.first == id; });
        if (it == send_hooks_.end())
            return false;
        send_hooks_.erase(it, send_hooks_.end());
        return true;
    }

    bool Library::remove_send_hook(const void*) {
        return false;
    }

    void Library::add_receive_hook(ReceiveHookFn cb) {
        std::lock_guard lock(mu_);
        receive_hook_ = std::move(cb);
    }

    void Library::remove_receive_hook() {
        std::lock_guard lock(mu_);
        receive_hook_ = nullptr;
    }

    bool Library::desync(bool enabled) {
        std::lock_guard lock(mu_);
        desync_ = enabled;
        return desync_;
    }

    void Library::set_rule(std::uint8_t packet_id, std::uint8_t value, int start, int stop) {
        std::lock_guard lock(mu_);
        PatchRule rule;
        rule.packet_id = packet_id;
        rule.value = value;
        rule.start = start;
        rule.stop = stop;
        rule.enabled = true;
        rules_[packet_id] = rule;
    }

    bool Library::toggle_rule(std::uint8_t packet_id, bool enabled) {
        std::lock_guard lock(mu_);
        auto it = rules_.find(packet_id);
        if (it == rules_.end())
            return false;
        it->second.enabled = enabled;
        return true;
    }

    bool Library::remove_rule(std::uint8_t packet_id) {
        std::lock_guard lock(mu_);
        return rules_.erase(packet_id) > 0;
    }

    bool Library::block(std::uint8_t packet_id, bool enabled) {
        std::lock_guard lock(mu_);
        if (enabled)
            blocked_ids_.insert(packet_id);
        else
            blocked_ids_.erase(packet_id);
        return enabled;
    }

    void Library::unblock(std::uint8_t packet_id) {
        std::lock_guard lock(mu_);
        blocked_ids_.erase(packet_id);
    }

    void Library::clear() {
        std::lock_guard lock(mu_);
        async_queue_.clear();
        recent_hashes_.clear();
        rules_.clear();
        blocked_ids_.clear();
        desync_ = false;
        blocked_packets_ = 0;
        mutated_packets_ = 0;
    }

    Statistics Library::stats() const {
        std::lock_guard lock(mu_);
        Statistics s;
        s.ready = ready_;
        s.hooked = send_hooked_ && recv_hooked_;
        s.send = send_hooked_;
        s.receive = recv_hooked_;
        s.desync = desync_;
        s.status = status_;
        s.captured = captured_;
        s.dispatched = dispatched_;
        s.duplicates = duplicates_;
        s.dropped = dropped_;
        s.blocked_packets = blocked_packets_;
        s.mutated_packets = mutated_packets_;
        s.queued = async_queue_.size();
        s.capacity = kCaptureQueueCapacity;
        s.maximum_capture_size = kMaxCaptureBytes;
        s.send_callback_count = send_hooks_.size();
        s.receive_callback = static_cast<bool>(receive_hook_);
        s.rule_count = rules_.size();
        s.blocked_count = blocked_ids_.size();
        for (const auto& [id, rule] : rules_) {
            (void)id;
            s.rules.push_back(rule);
        }
        for (auto id : blocked_ids_)
            s.blocked.push_back(id);
        return s;
    }

    PacketSnapshot Library::make_snapshot(Direction dir, const std::uint8_t* bytes, std::uint32_t size,
        int priority, int reliability, int channel, bool live,
        std::uint8_t* live_bytes, std::uint32_t* live_size,
        std::uint32_t live_capacity) {
        PacketSnapshot snap;
        snap.direction = dir;
        snap.priority = priority;
        snap.reliability = reliability;
        snap.ordering_channel = channel;
        snap.size = size;
        snap.sequence = ++sequence_;
        snap.timestamp = tick64();
        snap.live = live;
        snap.live_bytes = live_bytes;
        snap.live_size = live_size;
        snap.live_capacity = live_capacity;

        const std::uint32_t capture = static_cast<std::uint32_t>((std::min)(static_cast<std::size_t>(size), kMaxCaptureBytes));
        snap.captured_size = capture;
        snap.truncated = size > capture;
        if (bytes && capture) {
            snap.data.assign(bytes, bytes + capture);
            snap.packet_id = bytes[0];
            snap.item_id = capture > 1 ? bytes[1] : 0;
        }
        return snap;
    }

    void Library::enqueue_async(PacketSnapshot snap) {
        const auto h = hash_payload(snap.data.data(), snap.data.size(), snap.direction);
        for (auto old : recent_hashes_) {
            if (old == h) {
                ++duplicates_;
                return;
            }
        }
        recent_hashes_.push_back(h);
        while (recent_hashes_.size() > kDedupWindow)
            recent_hashes_.pop_front();

        if (async_queue_.size() >= kCaptureQueueCapacity) {
            ++dropped_;
            return;
        }
        async_queue_.push_back(std::move(snap));
        ++captured_;
    }

    bool Library::apply_rules_and_blocks(PacketSnapshot& snap, std::uint8_t*& bytes, std::uint32_t& size) {
        if (!bytes || size == 0)
            return false;

        const std::uint8_t id = bytes[0];

        if (blocked_ids_.count(id)) {
            snap.blocked = true;
            ++blocked_packets_;
            return true;
        }

        if (desync_ && id == kIdPhysics) {
            const std::uint32_t n = (std::min)(size, 6u);
            for (std::uint32_t i = 0; i < n; ++i)
                bytes[i] = 0xFF;
            snap.modified = true;
            ++mutated_packets_;
            ++blocked_packets_;
            snap.blocked = true;
            return true;
        }

        auto it = rules_.find(id);
        if (it != rules_.end() && it->second.enabled) {
            const PatchRule& r = it->second;
            for (int i = r.start; i < r.stop; ++i) {
                const int idx = 1 + i;
                if (idx >= 0 && static_cast<std::uint32_t>(idx) < size) {
                    bytes[static_cast<std::size_t>(idx)] = r.value;
                    snap.modified = true;
                }
            }
            if (snap.modified)
                ++mutated_packets_;
        }

        return snap.blocked;
    }

    void Library::cache_system_address(std::int64_t* system_identifier) {
        if (!system_identifier)
            return;
        std::memcpy(cached_address_, system_identifier, sizeof(cached_address_));
        have_cached_address_ = true;
    }

    std::int64_t Library::on_send_shared(std::int64_t* self, std::int64_t* bitstream_sp, int priority,
        int reliability, char ordering_channel,
        std::int64_t* system_identifier, bool broadcast,
        std::uint32_t force_receipt, std::uint64_t unk) {
        SendFn original = nullptr;
        std::vector<SendHookFn> hooks_copy;
        bool should_block = false;

        PacketSnapshot live_snap;

        {
            std::lock_guard lock(mu_);
            original = reinterpret_cast<SendFn>(original_send_);
            cache_system_address(system_identifier);

            if (!bitstream_sp || !bitstream_sp[0]) {
            }
            else {
                const std::uintptr_t stream = static_cast<std::uintptr_t>(bitstream_sp[0]);
                auto* bytes = *reinterpret_cast<std::uint8_t**>(stream + kStreamDataPtr);
                auto& size = *reinterpret_cast<std::uint32_t*>(stream + kStreamBytesUsed);
                const auto alloc = *reinterpret_cast<std::uint32_t*>(stream + kStreamBytesAlloc);

                if (bytes && size) {
                    live_snap = make_snapshot(Direction::Outgoing, bytes, size, priority, reliability,
                        ordering_channel, true, bytes, &size, alloc ? alloc : size);

                    should_block = apply_rules_and_blocks(live_snap, bytes, size);

                    if (live_snap.modified && bytes) {
                        const std::uint32_t capture =
                            static_cast<std::uint32_t>((std::min)(static_cast<std::size_t>(size), kMaxCaptureBytes));
                        live_snap.data.assign(bytes, bytes + capture);
                        live_snap.captured_size = capture;
                        live_snap.packet_id = bytes[0];
                        live_snap.item_id = capture > 1 ? bytes[1] : 0;
                        live_snap.size = size;
                    }

                    if (g_in_manual_send) {
                        for (auto& [id, fn] : send_hooks_) {
                            (void)id;
                            hooks_copy.push_back(fn);
                        }
                    }
                    else {
                        PacketSnapshot async_copy = live_snap;
                        async_copy.live = false;
                        async_copy.live_bytes = nullptr;
                        async_copy.live_size = nullptr;
                        enqueue_async(std::move(async_copy));
                    }
                }
            }
        }

        for (auto& fn : hooks_copy) {
            if (!fn)
                continue;
            fn(live_snap);
            if (live_snap.blocked)
                should_block = true;

            if (live_snap.modified && live_snap.live && live_snap.live_bytes && live_snap.live_size) {
                const std::uint32_t n = static_cast<std::uint32_t>(live_snap.data.size());
                const std::uint32_t cap =
                    live_snap.live_capacity ? live_snap.live_capacity : *live_snap.live_size;
                if (n <= cap) {
                    std::memcpy(live_snap.live_bytes, live_snap.data.data(), n);
                    *live_snap.live_size = n;
                }
            }
        }

        if (should_block || live_snap.blocked) {
            std::lock_guard lock(mu_);
            ++blocked_packets_;
            return 0;
        }

        if (!original)
            return 0;

        return original(self, bitstream_sp, priority, reliability, ordering_channel, system_identifier,
            broadcast, force_receipt, unk);
    }

    const char* Library::on_distribute(std::int64_t self, char debug_flag) {
        DistributeFn original = nullptr;

        {
            std::lock_guard lock(mu_);
            original = reinterpret_cast<DistributeFn>(original_distribute_);

            const auto* peer = reinterpret_cast<const std::uint8_t*>(self);
            const int read = *reinterpret_cast<const int*>(peer + kReturnQueueRead);
            const int write = *reinterpret_cast<const int*>(peer + kReturnQueueWrite);
            const int cap = *reinterpret_cast<const int*>(peer + kReturnQueueCap);
            const auto* buf = *reinterpret_cast<std::uint64_t* const*>(peer + kReturnQueueBuf);

            if (buf && cap > 0 && read != write) {
                int idx = read;
                int guard = 0;
                while (idx != write && guard++ < cap) {
                    const std::uint64_t pkt = buf[static_cast<std::size_t>(idx)];
                    idx = (idx + 1 == cap) ? 0 : (idx + 1);
                    if (!pkt)
                        continue;

                    const auto size = *reinterpret_cast<const std::uint32_t*>(pkt + kPacketLength);
                    const auto* bytes = *reinterpret_cast<std::uint8_t* const*>(pkt + kPacketData);
                    if (!bytes || !size)
                        continue;

                    auto snap = make_snapshot(Direction::Incoming, bytes, size, 1, 3, 0, false,
                        nullptr, nullptr, 0);
                    enqueue_async(std::move(snap));
                }
            }
        }

        if (original)
            return original(self, debug_flag);
        return nullptr;
    }

    void Library::drain_async_queue() {
        std::deque<PacketSnapshot> local;
        ReceiveHookFn recv;
        std::vector<SendHookFn> send_hooks;
        {
            std::lock_guard lock(mu_);
            local.swap(async_queue_);
            recv = receive_hook_;
            for (auto& [id, fn] : send_hooks_) {
                (void)id;
                send_hooks.push_back(fn);
            }
        }

        for (auto& snap : local) {
            {
                std::lock_guard lock(mu_);
                ++dispatched_;
            }
            if (snap.direction == Direction::Incoming) {
                if (recv)
                    recv(snap);
            }
            else {
                for (auto& fn : send_hooks) {
                    if (fn)
                        fn(snap);
                }
            }
        }
    }

    bool Library::send(const std::uint8_t* data, std::size_t size, int priority, int reliability,
        int ordering_channel, std::string* error) {
        if (!data || size == 0) {
            if (error) *error = std::string(OBF("empty payload"));
            return false;
        }
        if (size > kMaxSendBytes) {
            if (error) *error = std::string(OBF("payload exceeds 1 MiB"));
            return false;
        }
        for (std::size_t i = 0; i < size; ++i) {
            (void)i;
        }

        if (!hooked()) {
            if (error) *error = std::string(OBF("hooks inactive"));
            return false;
        }

        std::uintptr_t peer = 0;
        SendFn original = nullptr;
        std::uintptr_t base = 0;
        alignas(8) std::uint8_t addr_copy[32]{};
        bool have_addr = false;

        {
            std::lock_guard lock(mu_);
            peer = peer_;
            original = reinterpret_cast<SendFn>(original_send_);
            have_addr = have_cached_address_;
            if (have_addr)
                std::memcpy(addr_copy, cached_address_, sizeof(addr_copy));
            if (host_.module_base)
                base = host_.module_base();
        }

        if (!peer || !original) {
            if (error) *error = std::string(OBF("peer/send missing"));
            return false;
        }

        auto storage = std::make_shared<std::vector<std::uint8_t>>(data, data + size);

        auto* stream = new NetworkStream();
        stream->vftable = reinterpret_cast<void*>(base + kNetworkStreamVftableRva);
        stream->data = storage->data();
        stream->bytes_used = static_cast<std::uint32_t>(storage->size());
        stream->bytes_alloc = static_cast<std::uint32_t>(storage->size());
        stream->owned = 0;

        std::shared_ptr<NetworkStream> sp(stream, [storage](NetworkStream* p) {
            (void)storage;
            delete p;
            });

        std::int64_t* sp_as_qwords = reinterpret_cast<std::int64_t*>(&sp);

        std::int64_t* sys = have_addr ? reinterpret_cast<std::int64_t*>(addr_copy) : nullptr;
        if (!sys && host_.unassigned_system_address) {
            sys = reinterpret_cast<std::int64_t*>(host_.unassigned_system_address());
        }
        if (!sys) {
            if (error) *error = std::string(OBF("no SystemAddress (connect first so a send can cache one)"));
            return false;
        }

        struct ManualSendGuard {
            ManualSendGuard() { g_in_manual_send = true; }
            ~ManualSendGuard() { g_in_manual_send = false; }
        } guard;

        original(reinterpret_cast<std::int64_t*>(peer), sp_as_qwords, priority, reliability,
            static_cast<char>(ordering_channel), sys, false, 0, 0);
        return true;
    }

}
