#pragma once

#include "types.hpp"
#include "raknet.hpp"

struct lua_State;

namespace raknet {

    class Library {
    public:
        static Library& instance();

        void set_host(HostHooks host);

        bool hooked();
        bool is_hooked() const;

        void add_send_hook(SendHookFn cb);
        bool remove_send_hook(const void* token);
        std::uint64_t add_send_hook_tracked(SendHookFn cb);
        bool remove_send_hook_id(std::uint64_t id);

        void add_receive_hook(ReceiveHookFn cb);
        void remove_receive_hook();

        bool send(const std::uint8_t* data, std::size_t size,
            int priority = 1, int reliability = 3, int ordering_channel = 0,
            std::string* error = nullptr);

        Statistics stats() const;
        void clear();

        bool desync(bool enabled);
        bool desync() const;

        void set_rule(std::uint8_t packet_id, std::uint8_t value, int start = 0, int stop = 5);
        bool toggle_rule(std::uint8_t packet_id, bool enabled);
        bool remove_rule(std::uint8_t packet_id);

        bool block(std::uint8_t packet_id, bool enabled = true);
        void unblock(std::uint8_t packet_id);

        void drain_async_queue();

        std::int64_t on_send_shared(std::int64_t* self, std::int64_t* bitstream_sp,
            int priority, int reliability, char ordering_channel,
            std::int64_t* system_identifier, bool broadcast,
            std::uint32_t force_receipt, std::uint64_t unk);

        const char* on_distribute(std::int64_t self, char debug_flag);

        std::uintptr_t peer() const { return peer_; }

    private:
        Library() = default;

        bool install_hooks();
        std::uintptr_t resolve_peer() const;
        PacketSnapshot make_snapshot(Direction dir, const std::uint8_t* bytes, std::uint32_t size,
            int priority, int reliability, int channel, bool live,
            std::uint8_t* live_bytes, std::uint32_t* live_size,
            std::uint32_t live_capacity);
        void enqueue_async(PacketSnapshot snap);
        bool apply_rules_and_blocks(PacketSnapshot& snap, std::uint8_t*& bytes, std::uint32_t& size);
        void cache_system_address(std::int64_t* system_identifier);

        HostHooks host_{};
        mutable std::mutex mu_;

        std::uintptr_t peer_ = 0;
        void** original_vftable_ = nullptr;
        void** hooked_vftable_ = nullptr;
        void* original_send_ = nullptr;
        void* original_distribute_ = nullptr;

        bool send_hooked_ = false;
        bool recv_hooked_ = false;
        bool ready_ = false;
        std::string status_ = "uninitialized";

        bool desync_ = false;
        std::uint64_t sequence_ = 0;

        std::vector<std::pair<std::uint64_t, SendHookFn>> send_hooks_;
        std::uint64_t next_send_hook_id_ = 1;
        ReceiveHookFn receive_hook_;

        std::unordered_map<std::uint8_t, PatchRule> rules_;
        std::unordered_set<std::uint8_t> blocked_ids_;

        std::deque<PacketSnapshot> async_queue_;
        std::deque<std::uint64_t> recent_hashes_;

        std::uint64_t captured_ = 0;
        std::uint64_t dispatched_ = 0;
        std::uint64_t duplicates_ = 0;
        std::uint64_t dropped_ = 0;
        std::uint64_t blocked_packets_ = 0;
        std::uint64_t mutated_packets_ = 0;

        alignas(8) std::uint8_t cached_address_[32]{};
        bool have_cached_address_ = false;
    };

    void register_lua(lua_State* L);

}
