#pragma once

#include <cstdint>
#include <string>
#include <vector>
#include <optional>
#include <mutex>
#include <atomic>
#include <unordered_map>
#include <unordered_set>
#include <deque>
#include <functional>
#include <memory>

#include "offsets.hpp"

namespace raknet {

    enum class PacketPriority : int {
        Immediate = 0,
        High = 1,
        Medium = 2,
        Low = 3,
    };

    enum class PacketReliability : int {
        Unreliable = 0,
        UnreliableSequenced = 1,
        Reliable = 2,
        ReliableOrdered = 3,
        ReliableSequenced = 4,
        UnreliableWithReceipt = 5,
        ReliableWithReceipt = 6,
        ReliableOrderedWithReceipt = 7,
    };

    enum class Direction : int {
        Outgoing = 0,
        Incoming = 1,
    };

    struct PatchRule {
        std::uint8_t packet_id = 0;
        std::uint8_t value = 0;
        int start = 0;
        int stop = 5;
        bool enabled = true;
    };

    struct PacketSnapshot {
        Direction direction = Direction::Outgoing;
        std::uint8_t packet_id = 0;
        std::uint8_t item_id = 0;
        int priority = static_cast<int>(PacketPriority::High);
        int reliability = static_cast<int>(PacketReliability::ReliableOrdered);
        int ordering_channel = 0;
        std::uint32_t size = 0;
        std::uint32_t captured_size = 0;
        bool truncated = false;
        std::uint64_t sequence = 0;
        std::uint64_t timestamp = 0;
        std::vector<std::uint8_t> data;

        bool modified = false;
        bool blocked = false;
        bool live = false;
        std::uint8_t* live_bytes = nullptr;
        std::uint32_t* live_size = nullptr;
        std::uint32_t live_capacity = 0;
    };

    struct Statistics {
        bool ready = false;
        bool hooked = false;
        bool send = false;
        bool receive = false;
        bool desync = false;
        std::string status;
        std::string build = "version-d66094bc9ae84754";

        std::uint64_t captured = 0;
        std::uint64_t dispatched = 0;
        std::uint64_t duplicates = 0;
        std::uint64_t dropped = 0;
        std::uint64_t blocked_packets = 0;
        std::uint64_t mutated_packets = 0;
        std::uint64_t queued = 0;
        std::uint64_t capacity = raknet::ver::d66094bc9ae84754::kCaptureQueueCapacity;
        std::uint64_t maximum_capture_size = raknet::ver::d66094bc9ae84754::kMaxCaptureBytes;
        std::uint64_t send_callback_count = 0;
        bool receive_callback = false;
        std::uint64_t rule_count = 0;
        std::uint64_t blocked_count = 0;
        std::vector<PatchRule> rules;
        std::vector<std::uint8_t> blocked;
    };

    using SendHookFn = std::function<void(PacketSnapshot&)>;
    using ReceiveHookFn = std::function<void(const PacketSnapshot&)>;

    struct HostHooks {
        std::function<std::uintptr_t(const char* name)> get_job_by_name;
        std::function<std::uintptr_t()> module_base;
        std::function<std::uintptr_t()> unassigned_system_address;
    };

}
