#pragma once
#include <regex>

struct RegexObject {
    uint32_t magic;
    std::regex pattern;
    std::string patternStr;
};

constexpr uint32_t REGEX_MAGIC = 0x52454758;

namespace Regex
{
    static int regex_match(lua_State* L)
    {
        auto* obj = reinterpret_cast<RegexObject*>(lua_touserdata(L, 1));
        if (!obj || obj->magic != REGEX_MAGIC) luaL_error(L, OBF("invalid Regex object"));
        const char* contents = luaL_checkstring(L, 2);
        std::string str(contents);
        std::smatch match;
        if (std::regex_search(str, match, obj->pattern))
            lua_pushstring(L, match[0].str().c_str());
        else
            lua_pushnil(L);
        return 1;
    }

    static int regex_matchmany(lua_State* L)
    {
        auto* obj = reinterpret_cast<RegexObject*>(lua_touserdata(L, 1));
        if (!obj || obj->magic != REGEX_MAGIC) luaL_error(L, OBF("invalid Regex object"));
        const char* contents = luaL_checkstring(L, 2);
        std::string str(contents);
        lua_newtable(L);
        int idx = 1;
        auto begin = std::sregex_iterator(str.begin(), str.end(), obj->pattern);
        auto end = std::sregex_iterator();
        for (auto it = begin; it != end; ++it) {
            lua_pushstring(L, (*it)[0].str().c_str());
            lua_rawseti(L, -2, idx++);
        }
        return 1;
    }

    static int regex_replace(lua_State* L)
    {
        auto* obj = reinterpret_cast<RegexObject*>(lua_touserdata(L, 1));
        if (!obj || obj->magic != REGEX_MAGIC) luaL_error(L, OBF("invalid Regex object"));
        const char* contents = luaL_checkstring(L, 2);
        const char* replacement = luaL_checkstring(L, 3);
        std::string result = std::regex_replace(
            std::string(contents), obj->pattern, std::string(replacement),
            std::regex_constants::format_first_only
        );
        lua_pushstring(L, result.c_str());
        return 1;
    }

    static int regex_index(lua_State* L)
    {
        const char* key = luaL_checkstring(L, 2);
        if (strcmp(key, ENV_OBF("Match")) == 0) { lua_pushcfunction(L, regex_match, OBF("Match")); return 1; }
        if (strcmp(key, ENV_OBF("MatchMany")) == 0) { lua_pushcfunction(L, regex_matchmany, OBF("MatchMany")); return 1; }
        if (strcmp(key, ENV_OBF("Replace")) == 0) { lua_pushcfunction(L, regex_replace, OBF("Replace")); return 1; }
        lua_pushnil(L);
        return 1;
    }

    static int regex_gc(lua_State* L)
    {
        auto* obj = reinterpret_cast<RegexObject*>(lua_touserdata(L, 1));
        if (obj && obj->magic == REGEX_MAGIC) {
            obj->magic = 0;
            obj->~RegexObject();
        }
        return 0;
    }

    int regex_new(lua_State* L)
    {
        const char* pattern = luaL_checkstring(L, 1);
        auto* obj = reinterpret_cast<RegexObject*>(
            lua_newuserdata(L, sizeof(RegexObject))
            );

        try {
            new(obj) RegexObject();
            obj->magic = REGEX_MAGIC;
            obj->patternStr = pattern;
            obj->pattern = std::regex(pattern, std::regex::ECMAScript);
        }
        catch (const std::regex_error& e) {
            obj->magic = 0;
            lua_pushfstring(L, OBF("Regex.new: invalid pattern: %s"), e.what());
            lua_error(L);
        }

        lua_newtable(L);
        lua_pushcfunction(L, regex_index, OBF("__index"));
        lua_setfield(L, -2, ENV_OBF("__index"));
        lua_pushcfunction(L, regex_gc, OBF("__gc"));
        lua_setfield(L, -2, ENV_OBF("__gc"));
        lua_pushstring(L, OBF("Regex"));
        lua_setfield(L, -2, ENV_OBF("__type"));
        lua_setmetatable(L, -2);

        return 1;
    }

    int regex_escape(lua_State* L)
    {
        const char* str = luaL_checkstring(L, 1);
        std::string result;
        for (const char* c = str; *c; ++c)
        {
            if (strchr(OBF(R"(\.^$|?*+()[]{})"), *c))
                result += '\\';
            result += *c;
        }
        lua_pushlstring(L, result.data(), result.size());
        return 1;
    }

    void RegisterLibrary(lua_State* L)
    {
        lua_newtable(L);
        Utils::AddTableFunction(L, ENV_OBF("new"), regex_new);
        Utils::AddTableFunction(L, ENV_OBF("Escape"), regex_escape);
        lua_setglobal(L, ENV_OBF("Regex"));
    }
}