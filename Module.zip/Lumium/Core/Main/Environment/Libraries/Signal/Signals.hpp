#pragma once

#include <Windows.h>
#include <lua.h>
#include <lualib.h>
#include <map>
#include <unordered_map>
#include <unordered_set>
#include <atomic>
#include <string>
#include <vector>
#include <lapi.h>
#include <lobject.h>
#include <ldo.h>
#include <lstate.h>
#include <Utils.hpp>
#include <Globals.hpp>

namespace Signals {
    struct TrackedConnection
    {
        int FunctionRef = -2;
        int ThreadRef = -2;
        uint64_t Generation = 0;
    };
    struct CachedConnectionTable {
        int ref;
        uint64_t generation;
    };
    inline std::unordered_map<uintptr_t, std::vector<TrackedConnection>> TrackedConnectionsBySignal;
    inline std::unordered_map<uintptr_t, TrackedConnection> TrackedConnectionsByConn;
    inline std::unordered_map<std::uintptr_t, CachedConnectionTable> g_connection_cache;

}

template <typename T>
__forceinline static bool IsPtrValid(T value)
{
    const void* ptr = reinterpret_cast<const void*>(value);
    MEMORY_BASIC_INFORMATION buffer{};
    SIZE_T read = VirtualQuery(ptr, &buffer, sizeof(buffer));
    if (read == 0 || read != sizeof(buffer))
        return false;
    if (buffer.RegionSize < sizeof(T))
        return false;
    if ((buffer.State & MEM_FREE) == MEM_FREE)
        return false;
    const DWORD valid_prot = PAGE_READONLY | PAGE_READWRITE | PAGE_WRITECOPY |
        PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY;
    if ((buffer.Protect & valid_prot) != 0)
        return true;
    if ((buffer.Protect & (PAGE_GUARD | PAGE_NOACCESS)) != 0)
        return false;
    return true;
}

inline bool signal_safe_read(const void* address, void* output, size_t size)
{
    if (!address || !output || !size)
        return false;
    MEMORY_BASIC_INFORMATION info{};
    if (!VirtualQuery(address, &info, sizeof(info)) || info.State != MEM_COMMIT ||
        (info.Protect & (PAGE_NOACCESS | PAGE_GUARD)))
        return false;
    const uintptr_t start = reinterpret_cast<uintptr_t>(address);
    const uintptr_t end = reinterpret_cast<uintptr_t>(info.BaseAddress) + info.RegionSize;
    if (start + size < start || start + size > end)
        return false;
    __try
    {
        memcpy(output, address, size);
        return true;
    }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        return false;
    }
}

inline bool signal_safe_write(void* address, const void* value, size_t size)
{
    MEMORY_BASIC_INFORMATION info{};
    if (!address || !value || !VirtualQuery(address, &info, sizeof(info)) ||
        info.State != MEM_COMMIT || (info.Protect & (PAGE_NOACCESS | PAGE_GUARD)))
        return false;
    __try
    {
        memcpy(address, value, size);
        return true;
    }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        return false;
    }
}

namespace ConnOffsets {
    namespace Connection {
        const uintptr_t next = 0x10;
        const uintptr_t enabled = 0x20;
        const uintptr_t slot_wrapper = 0x30;
        const uintptr_t slot_wrapper_self = 0x38;
    }
    namespace SlotWrapper {
        const uintptr_t thread = 0x28;
        const uintptr_t function_id = 0x34;
        const uintptr_t weak_object_ref = 0x60;
        const uintptr_t weak_object_ref_fallback = 0x38;
    }
}

struct connection_struct {
    std::uintptr_t connection;
    std::uintptr_t oldEnabled;
    bool IsValid;
    bool ForeignState;
};

inline std::unordered_map<std::uintptr_t, LuaTable*> g_connection_cache;
inline std::unordered_set<std::uintptr_t> g_fired_connections;

static std::uintptr_t get_weak_object_via_chain(std::uintptr_t signalPtr) {
    std::uintptr_t val0 = 0;
    if (!signal_safe_read(reinterpret_cast<void*>(signalPtr + 0x68), &val0, sizeof(val0)))
        return 0;
    if (!val0 || !IsPtrValid(val0)) return 0;

    std::uintptr_t val1 = 0;
    if (!signal_safe_read(reinterpret_cast<void*>(val0 + 8), &val1, sizeof(val1)))
        return 0;
    if (!val1 || !IsPtrValid(val1)) return 0;

    const auto weak_object_addr = val1 + ConnOffsets::SlotWrapper::weak_object_ref;
    if (!IsPtrValid(weak_object_addr)) return 0;

    std::uintptr_t weak_object_ptr = 0;
    if (!signal_safe_read(reinterpret_cast<void*>(weak_object_addr), &weak_object_ptr, sizeof(weak_object_ptr)))
        return 0;
    if (!weak_object_ptr || !IsPtrValid(weak_object_ptr)) return 0;

    return weak_object_ptr;
}

static std::uintptr_t get_weak_object_ptr(std::uintptr_t signalPtr) {
    std::uintptr_t slot_wrapper = 0;
    if (!signal_safe_read(reinterpret_cast<void*>(signalPtr + ConnOffsets::Connection::slot_wrapper), &slot_wrapper, sizeof(slot_wrapper)))
        return 0;
    if (!slot_wrapper) return 0;

    std::uintptr_t slot_wrapper_self = 0;
    signal_safe_read(reinterpret_cast<void*>(signalPtr + ConnOffsets::Connection::slot_wrapper_self), &slot_wrapper_self, sizeof(slot_wrapper_self));

    const bool is_self = slot_wrapper_self && IsPtrValid(slot_wrapper_self) &&
        (slot_wrapper == (slot_wrapper_self + 0x18));

    if (!is_self)
        return get_weak_object_via_chain(signalPtr);

    std::uintptr_t ptr0 = 0;
    if (signal_safe_read(reinterpret_cast<void*>(slot_wrapper + ConnOffsets::SlotWrapper::weak_object_ref), &ptr0, sizeof(ptr0))) {
        if (ptr0 && IsPtrValid(ptr0)) return ptr0;
    }

    std::uintptr_t ptr1 = 0;
    if (signal_safe_read(reinterpret_cast<void*>(slot_wrapper + 0x48), &ptr1, sizeof(ptr1))) {
        if (ptr1 && IsPtrValid(ptr1)) return ptr1;
    }

    return get_weak_object_via_chain(signalPtr);
}

static lua_State* get_connection_thread(std::uintptr_t weak_obj) {
    lua_State* thread = nullptr;
    if (!signal_safe_read(reinterpret_cast<void*>(weak_obj + ConnOffsets::SlotWrapper::thread), &thread, sizeof(thread)))
        return nullptr;
    if (!thread || !IsPtrValid(reinterpret_cast<uintptr_t>(thread)))
        return nullptr;

    uint8_t tt = 0;
    if (!signal_safe_read(&thread->tt, &tt, sizeof(tt)) || tt != LUA_TTHREAD)
        return nullptr;

    return thread;
}

static Closure* get_connection_function(std::uintptr_t weak_obj) {
    lua_State* thread = get_connection_thread(weak_obj);
    if (!thread) return nullptr;

    auto try_get_closure = [&](int ref) -> Closure* {
        if (ref <= 0) return nullptr;
        lua_getref(thread, ref);
        if (lua_isfunction(thread, -1)) {
            auto cl = clvalue(luaA_toobject(thread, -1));
            lua_pop(thread, 1);
            return cl;
        }
        lua_pop(thread, 1);
        return nullptr;
        };

    std::int32_t function_id = 0;
    if (signal_safe_read(reinterpret_cast<void*>(weak_obj + ConnOffsets::SlotWrapper::function_id), &function_id, sizeof(function_id))) {
        if (auto cl = try_get_closure(function_id))
            return cl;
    }

    std::int32_t base_function_id = 0;
    if (signal_safe_read(reinterpret_cast<void*>(weak_obj), &base_function_id, sizeof(base_function_id))) {
        for (int offset = 0; offset <= 0xffc; ++offset) {
            if (auto cl = try_get_closure(base_function_id + offset))
                return cl;
        }
    }

    return nullptr;
}

static connection_struct* get_con_from_table(lua_State* L, int idx) {
    lua_rawgetfield(L, idx, ENV_OBF("Object"));
    if (!lua_islightuserdata(L, -1)) {
        lua_pop(L, 1);
        return nullptr;
    }
    auto* con = reinterpret_cast<connection_struct*>(lua_tolightuserdata(L, -1));
    lua_pop(L, 1);
    return con;
}

static bool con_enabled(connection_struct* con) {
    if (!con || !con->connection) return false;
    std::uintptr_t val = 0;
    signal_safe_read(reinterpret_cast<void*>(con->connection + ConnOffsets::Connection::enabled), &val, sizeof(val));
    return val > 0;
}

static void set_enabled(connection_struct* con, uintptr_t value) {
    if (!con || !con->connection) return;
    signal_safe_write(reinterpret_cast<void*>(con->connection + ConnOffsets::Connection::enabled), &value, sizeof(value));
}

static int conn_noop(lua_State* L) { return 0; }

static int conn_fire(lua_State* L) {
    luaL_checktype(L, 1, LUA_TTABLE);
    auto* con = get_con_from_table(L, 1);
    if (!con || !con->connection) return 0;

    const auto weak_ref = get_weak_object_ptr(con->connection);
    Closure* function = nullptr;
    if (weak_ref) {
        lua_State* thread = get_connection_thread(weak_ref);
        const bool foreign = thread
            ? (thread->global->mainthread != L->global->mainthread)
            : false;
        if (foreign) return 0;
        function = get_connection_function(weak_ref);
    }

    if (function && function->tt == LUA_TFUNCTION) {
        lua_remove(L, 1);
        const int argc = lua_gettop(L);
        lua_State* co = lua_newthread(L);
        setclvalue(co, co->top, function);
        incr_top(co);
        for (int i = 1; i <= argc; ++i) {
            lua_pushvalue(L, i);
            lua_xmove(L, co, 1);
        }
        lua_resume(co, L, argc);
        lua_settop(L, 0);
        g_fired_connections.insert(con->connection);
        return 0;
    }

    int ref = LUA_NOREF;
    lua_rawgetfield(L, 1, ENV_OBF("_TFR"));
    if (lua_isnumber(L, -1)) {
        ref = (int)lua_tonumber(L, -1);
    }
    lua_pop(L, 1);

    if (ref == LUA_NOREF && con && con->connection) {
        auto found = Signals::TrackedConnectionsByConn.find(con->connection);
        if (found != Signals::TrackedConnectionsByConn.end()) {
            ref = found->second.FunctionRef;
        }
    }

    if (ref != LUA_NOREF) {
        lua_remove(L, 1);
        const int argc = lua_gettop(L);
        lua_getref(L, ref);
        if (lua_isfunction(L, -1)) {
            lua_State* co = lua_newthread(L);
            lua_pushvalue(L, -2);
            lua_xmove(L, co, 1);
            lua_pop(L, 1);
            for (int i = 1; i <= argc; ++i) {
                lua_pushvalue(L, i);
                lua_xmove(L, co, 1);
            }
            lua_resume(co, L, argc);
            lua_settop(L, 0);
            g_fired_connections.insert(con->connection);
            return 0;
        }
        lua_pop(L, 1);
    }
    return 0;
}

static int conn_defer(lua_State* L) {
    luaL_checktype(L, 1, LUA_TTABLE);
    auto* con = get_con_from_table(L, 1);
    if (!con || !con->connection) return 0;

    const auto weak_ref = get_weak_object_ptr(con->connection);
    if (!weak_ref) return 0;

    const auto function = get_connection_function(weak_ref);
    if (!function || function->tt != LUA_TFUNCTION) return 0;

    lua_remove(L, 1);
    const int argc = lua_gettop(L);

    lua_getglobal(L, ENV_OBF("task"));
    lua_getfield(L, -1, ENV_OBF("defer"));
    lua_remove(L, -2);

    setclvalue(L, L->top, function);
    incr_top(L);

    for (int i = 1; i <= argc; ++i)
        lua_pushvalue(L, i);

    lua_call(L, argc + 1, 0);
    return 0;
}

static int conn_disable(lua_State* L) {
    luaL_checktype(L, 1, LUA_TTABLE);
    auto* con = get_con_from_table(L, 1);
    if (con && con->connection) set_enabled(con, 0);
    return 0;
}

static int conn_disconnect(lua_State* L) {
    luaL_checktype(L, 1, LUA_TTABLE);
    auto* con = get_con_from_table(L, 1);
    if (!con || !con->connection) return 0;
    set_enabled(con, 0);
    con->IsValid = false;
    g_connection_cache.erase(con->connection);
    return 0;
}

static int conn_enable(lua_State* L) {
    luaL_checktype(L, 1, LUA_TTABLE);
    auto* con = get_con_from_table(L, 1);
    if (con && con->connection) set_enabled(con, con->oldEnabled ? con->oldEnabled : 1);
    return 0;
}

static lua_State* get_wait_thread(std::uintptr_t signalPtr) {
    uintptr_t slot_wrapper_self = 0;
    signal_safe_read(reinterpret_cast<void*>(signalPtr + ConnOffsets::Connection::slot_wrapper_self), &slot_wrapper_self, sizeof(slot_wrapper_self));
    if (!slot_wrapper_self || !IsPtrValid(slot_wrapper_self)) return nullptr;

    uintptr_t container = 0;
    if (!signal_safe_read(reinterpret_cast<void*>(slot_wrapper_self + 0x50), &container, sizeof(container)))
        return nullptr;
    if (!container || !IsPtrValid(container)) return nullptr;

    lua_State* thread = nullptr;
    if (!signal_safe_read(reinterpret_cast<void*>(container + 0x28), &thread, sizeof(thread)))
        return nullptr;
    if (!thread || !IsPtrValid(reinterpret_cast<uintptr_t>(thread))) return nullptr;

    uint8_t tt = 0;
    if (!signal_safe_read(&thread->tt, &tt, sizeof(tt)) || tt != LUA_TTHREAD)
        return nullptr;

    global_State* g = nullptr;
    if (!signal_safe_read(&thread->global, &g, sizeof(g)) || !g)
        return nullptr;

    return thread;
}

static int connection_index(lua_State* L) {
    luaL_checktype(L, 1, LUA_TTABLE);
    luaL_checktype(L, 2, LUA_TSTRING);

    const char* key = lua_tostring(L, 2);
    auto* con = get_con_from_table(L, 1);

    if (!con || !con->connection) {
        if (strcmp(key, ENV_OBF("Enabled")) == 0 || strcmp(key, ENV_OBF("ForeignState")) == 0 ||
            strcmp(key, ENV_OBF("LuaConnection")) == 0 || strcmp(key, ENV_OBF("Function")) == 0 ||
            strcmp(key, ENV_OBF("Thread")) == 0) {
            lua_pushnil(L);
            return 1;
        }
        lua_pushcfunction(L, conn_noop, OBF("conn_noop"));
        return 1;
    }

    const auto weak_ref = get_weak_object_ptr(con->connection);
    lua_State* nativeThread = nullptr;
    Closure* nativeFunction = nullptr;
    if (weak_ref) {
        nativeThread = get_connection_thread(weak_ref);
        nativeFunction = get_connection_function(weak_ref);
    }

    int trackedFuncRef = LUA_NOREF;
    int trackedThreadRef = LUA_NOREF;
    lua_rawgetfield(L, 1, ENV_OBF("_TFR"));
    if (lua_isnumber(L, -1)) trackedFuncRef = (int)lua_tonumber(L, -1);
    lua_pop(L, 1);
    lua_rawgetfield(L, 1, ENV_OBF("_TTR"));
    if (lua_isnumber(L, -1)) trackedThreadRef = (int)lua_tonumber(L, -1);
    lua_pop(L, 1);

    if (trackedFuncRef == LUA_NOREF && con && con->connection) {
        uintptr_t target_conn = con->connection;
        auto found = Signals::TrackedConnectionsByConn.find(target_conn);
        if (found == Signals::TrackedConnectionsByConn.end()) {
            for (auto& pair : Signals::TrackedConnectionsByConn) {
                uintptr_t tracked_ptr = pair.first;
                for (int offset = 0; offset < 128; offset += 8) {
                    uintptr_t val = 0;
                    if (signal_safe_read(reinterpret_cast<void*>(tracked_ptr + offset), &val, sizeof(val))) {
                        if (val == target_conn) {
                            found = Signals::TrackedConnectionsByConn.find(tracked_ptr);
                            break;
                        }
                    }
                }
                if (found != Signals::TrackedConnectionsByConn.end())
                    break;
            }
        }
        if (found != Signals::TrackedConnectionsByConn.end()) {
            trackedFuncRef = found->second.FunctionRef;
            trackedThreadRef = found->second.ThreadRef;
        }
    }

    if (nativeThread) {
        global_State* nativeGlobal = nullptr;
        global_State* currentGlobal = nullptr;
        signal_safe_read(&nativeThread->global, &nativeGlobal, sizeof(nativeGlobal));
        signal_safe_read(&L->global, &currentGlobal, sizeof(currentGlobal));
        con->ForeignState = (nativeGlobal && currentGlobal && nativeGlobal != currentGlobal);
    }
    else {
        con->ForeignState = false;
    }

    bool hasFuncRef = false;
    if (weak_ref) {
        int32_t func_id = 0;
        if (signal_safe_read(reinterpret_cast<void*>(weak_ref + ConnOffsets::SlotWrapper::function_id), &func_id, sizeof(func_id)))
            hasFuncRef = (func_id > 0);
        if (!hasFuncRef) {
            int32_t base_id = 0;
            if (signal_safe_read(reinterpret_cast<void*>(weak_ref), &base_id, sizeof(base_id)))
                hasFuncRef = (base_id > 0);
        }
    }
    bool isLuaNative = nativeFunction && !nativeFunction->isC;
    if (!isLuaNative && hasFuncRef && !con->ForeignState)
        isLuaNative = true;
    bool isLuaTracked = false;
    if (trackedFuncRef != LUA_NOREF) {
        lua_getref(L, trackedFuncRef);
        int t = lua_type(L, -1);
        if (t == LUA_TFUNCTION) {
            isLuaTracked = true;
        }
        lua_pop(L, 1);
    }
    bool isLua = isLuaNative || isLuaTracked;

    if (strcmp(key, ENV_OBF("Enabled")) == 0) {
        lua_pushboolean(L, con_enabled(con));
    }
    else if (strcmp(key, ENV_OBF("ForeignState")) == 0) {
        lua_pushboolean(L, con->ForeignState);
    }
    else if (strcmp(key, ENV_OBF("LuaConnection")) == 0) {
        lua_pushboolean(L, isLua);
    }
    else if (strcmp(key, ENV_OBF("Function")) == 0) {
        if (nativeFunction && nativeFunction->tt == LUA_TFUNCTION) {
            setclvalue(L, L->top, nativeFunction);
            incr_top(L);
        }
        else if (trackedFuncRef != LUA_NOREF) {
            lua_getref(L, trackedFuncRef);
        }
        else {
            lua_pushnil(L);
        }
    }
    else if (strcmp(key, ENV_OBF("Thread")) == 0) {
        lua_State* thread = nativeThread;

        if (!thread || thread->tt != LUA_TTHREAD)
            thread = get_wait_thread(con->connection);

        if (thread && thread->tt == LUA_TTHREAD) {
            global_State* nativeGlobal = nullptr;
            global_State* currentGlobal = nullptr;
            signal_safe_read(&thread->global, &nativeGlobal, sizeof(nativeGlobal));
            signal_safe_read(&L->global, &currentGlobal, sizeof(currentGlobal));
            if (nativeGlobal == currentGlobal) {
                setthvalue(L, L->top, thread);
                incr_top(L);
            }
            else {
                lua_pushnil(L);
            }
        }
        else if (trackedThreadRef != LUA_NOREF) {
            lua_getref(L, trackedThreadRef);
            if (!lua_isthread(L, -1)) {
                lua_pop(L, 1);
                lua_pushnil(L);
            }
        }
        else {
            lua_pushnil(L);
        }
    }
    else if (strcmp(key, ENV_OBF("Fire")) == 0) {
        lua_pushcfunction(L, conn_fire, OBF("Connection.Fire"));
    }
    else if (strcmp(key, ENV_OBF("Defer")) == 0) {
        lua_pushcfunction(L, conn_defer, OBF("Connection.Defer"));
    }
    else if (strcmp(key, ENV_OBF("Disable")) == 0) {
        lua_pushcfunction(L, conn_disable, OBF("Connection.Disable"));
    }
    else if (strcmp(key, ENV_OBF("Disconnect")) == 0) {
        lua_pushcfunction(L, conn_disconnect, OBF("Connection.Disconnect"));
    }
    else if (strcmp(key, ENV_OBF("Enable")) == 0) {
        lua_pushcfunction(L, conn_enable, OBF("Connection.Enable"));
    }
    else {
        lua_pushnil(L);
    }

    return 1;
}

static int connection_newindex(lua_State* L) {
    return 0;
}

static int push_connection_mt(lua_State* L, uintptr_t signalPtr) {
    auto* conn = static_cast<connection_struct*>(lua_newuserdata(L, sizeof(connection_struct)));
    lua_ref(L, -1);
    lua_pop(L, 1);

    conn->connection = signalPtr;

    std::uintptr_t enabled_val = 0;
    signal_safe_read(reinterpret_cast<void*>(signalPtr + ConnOffsets::Connection::enabled), &enabled_val, sizeof(enabled_val));
    conn->oldEnabled = enabled_val;
    conn->IsValid = true;
    conn->ForeignState = false;

    lua_newtable(L);
    lua_pushlightuserdata(L, conn);
    lua_setfield(L, -2, ENV_OBF("Object"));

    lua_getfield(L, LUA_REGISTRYINDEX, ENV_OBF("connection_signal_object"));
    lua_setmetatable(L, -2);

    return 1;
}

static int push_connection_mt_safe(lua_State* L, uintptr_t signalPtr) {
    __try {
        return push_connection_mt(L, signalPtr);
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        return 0;
    }
}

namespace Signals {

    inline uintptr_t GetSignalIdentity(lua_State* L, int index)
    {
        uintptr_t userdata = reinterpret_cast<uintptr_t>(lua_touserdata(L, index));
        uintptr_t dummy = 0;
        if (!userdata || !signal_safe_read(reinterpret_cast<void*>(userdata), &dummy, sizeof(dummy)))
            return 0;

        uintptr_t signal = 0;
        signal_safe_read(reinterpret_cast<void*>(userdata + 16), &signal, sizeof(signal));

        if (!signal)
            signal_safe_read(reinterpret_cast<void*>(userdata), &signal, sizeof(signal));

        return signal;
    }

    inline void TrackConnection(lua_State* L, int signalIndex, uintptr_t conn_ptr, int funcRef)
    {
        if (!L || !conn_ptr || funcRef == -2)
            return;
        const uintptr_t identity = GetSignalIdentity(L, signalIndex);

        lua_pushthread(L);
        const int threadRef = lua_ref(L, -1);
        lua_pop(L, 1);

        TrackedConnection tc = {
            funcRef,
            threadRef,
            SharedVariables::StateGeneration.load()
        };

        TrackedConnectionsByConn[conn_ptr] = tc;

        if (identity) {
            TrackedConnectionsBySignal[identity].push_back(tc);
        }
    }

    static int tracked_fire_connection(lua_State* ls)
    {
        if (lua_gettop(ls) >= 1 && lua_istable(ls, 1))
            lua_remove(ls, 1);

        const auto nargs = ls->top - ls->base;

        lua_pushvalue(ls, lua_upvalueindex(1));
        if (lua_isfunction(ls, -1))
        {
            lua_State* co = lua_newthread(ls);
            lua_pushvalue(ls, -2);
            lua_xmove(ls, co, 1);
            lua_pop(ls, 1);

            for (int i = 1; i <= nargs; ++i)
                lua_pushvalue(ls, i);
            if (nargs > 0)
                lua_xmove(ls, co, nargs);

            lua_resume(co, ls, nargs);
        }
        lua_pop(ls, 1);

        return 0;
    }

    static int tracked_defer_connection(lua_State* ls)
    {
        if (lua_gettop(ls) >= 1 && lua_istable(ls, 1))
            lua_remove(ls, 1);

        const auto nargs = lua_gettop(ls);

        lua_getglobal(ls, ENV_OBF("task"));
        lua_getfield(ls, -1, ENV_OBF("defer"));
        lua_remove(ls, -2);

        lua_pushvalue(ls, lua_upvalueindex(1));
        if (!lua_isfunction(ls, -1))
            return 0;

        lua_insert(ls, 1);
        lua_insert(ls, 1);

        if (lua_pcall(ls, nargs + 1, 1, 0) != LUA_OK)
            luaL_error(ls, OBF("Error in defer_connection: %s"), lua_tostring(ls, -1));

        return 1;
    }

    inline void PushTrackedConnections(lua_State* L, int signalIndex)
    {
        const uintptr_t identity = GetSignalIdentity(L, signalIndex);
        const uint64_t generation = SharedVariables::StateGeneration.load();
        lua_newtable(L);
        int outputIndex = 1;

        const auto found = TrackedConnectionsBySignal.find(identity);
        if (found == TrackedConnectionsBySignal.end())
            return;
        for (const TrackedConnection& connection : found->second)
        {
            if (connection.Generation != generation)
                continue;

            lua_newtable(L);
            lua_pushboolean(L, true);
            lua_setfield(L, -2, ENV_OBF("Enabled"));
            lua_pushboolean(L, false);
            lua_setfield(L, -2, ENV_OBF("ForeignState"));
            lua_pushboolean(L, true);
            lua_setfield(L, -2, ENV_OBF("LuaConnection"));

            lua_getref(L, connection.FunctionRef);
            lua_setfield(L, -2, ENV_OBF("Function"));
            lua_getref(L, connection.ThreadRef);
            lua_setfield(L, -2, ENV_OBF("Thread"));

            lua_getref(L, connection.FunctionRef);
            lua_pushcclosure(L, tracked_fire_connection, OBF("Connection.Fire"), 1);
            lua_setfield(L, -2, ENV_OBF("Fire"));
            lua_getref(L, connection.FunctionRef);
            lua_pushcclosure(L, tracked_defer_connection, OBF("Connection.Defer"), 1);
            lua_setfield(L, -2, ENV_OBF("Defer"));

            lua_pushcfunction(L, conn_noop, OBF("Connection.Disable"));
            lua_setfield(L, -2, ENV_OBF("Disable"));
            lua_pushcfunction(L, conn_noop, OBF("Connection.Enable"));
            lua_setfield(L, -2, ENV_OBF("Enable"));
            lua_pushcfunction(L, conn_noop, OBF("Connection.Disconnect"));
            lua_setfield(L, -2, ENV_OBF("Disconnect"));

            lua_rawseti(L, -2, outputIndex++);
        }
    }

    void checkIsA(lua_State* L, const char* idk) {
        lua_getfield(L, 1, ENV_OBF("IsA"));
        lua_pushvalue(L, 1);
        lua_pushstring(L, idk);
        lua_call(L, 2, 1);
    }

    int fireproximityprompt(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TUSERDATA);

        lua_getglobal(L, ENV_OBF("typeof"));
        lua_pushvalue(L, 1);
        lua_call(L, 1, 1);
        const bool inst = (strcmp(lua_tolstring(L, -1, 0), ENV_OBF("Instance")) == 0);
        lua_pop(L, 1);

        if (!inst)
            luaL_argerror(L, 1, OBF("Expected an Instance"));

        lua_getfield(L, 1, ENV_OBF("IsA"));
        lua_pushvalue(L, 1);
        lua_pushstring(L, OBF("ProximityPrompt"));
        lua_call(L, 2, 1);
        const bool expected = lua_toboolean(L, -1);
        lua_pop(L, 1);

        if (!expected)
            luaL_argerror(L, 1, OBF("Expected a ProximityPrompt"));

        Roblox::FireProximityPrompt(*reinterpret_cast<std::uintptr_t*>(lua_touserdata(L, 1)));
        return 0;
    }

    int fireclickdetector(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TUSERDATA);

        auto FireDistance = luaL_optnumber(L, 2, 0);
        auto EventName = luaL_optstring(L, 3, OBF("MouseClick"));

        lua_getglobal(L, ENV_OBF("game"));
        lua_getfield(L, -1, ENV_OBF("GetService"));
        lua_insert(L, -2);
        lua_pushstring(L, OBF("Players"));
        lua_pcall(L, 2, 1, 0);
        lua_getfield(L, -1, ENV_OBF("LocalPlayer"));

        if (strcmp(EventName, ENV_OBF("MouseClick")) == 0)
        {
            Roblox::FireMouseClick(*static_cast<void**>(lua_touserdata(L, 1)), FireDistance, *static_cast<void**>(lua_touserdata(L, -1)));
        }
        else if (strcmp(EventName, ENV_OBF("RightMouseClick")) == 0)
        {
            Roblox::FireRightMouseClick(*static_cast<void**>(lua_touserdata(L, 1)), FireDistance, *static_cast<void**>(lua_touserdata(L, -1)));
        }
        else if (strcmp(EventName, ENV_OBF("MouseHoverEnter")) == 0)
        {
            Roblox::FireMouseHover(*static_cast<void**>(lua_touserdata(L, 1)), *static_cast<void**>(lua_touserdata(L, -1)));
        }
        else if (strcmp(EventName, ENV_OBF("MouseHoverLeave")) == 0)
        {
            Roblox::FireMouseHoverLeave(*static_cast<void**>(lua_touserdata(L, 1)), *static_cast<void**>(lua_touserdata(L, -1)));
        }

        return 0;
    }

    struct WalkResult {
        uintptr_t connections[256];
        int count;
    };

    static WalkResult walk_connections_safe(uintptr_t sentinelBase) {
        WalkResult result = {};
        __try {
            uintptr_t cur = *reinterpret_cast<uintptr_t*>(sentinelBase + ConnOffsets::Connection::next);
            while (cur && cur != sentinelBase && result.count < 256) {
                result.connections[result.count++] = cur;
                cur = *reinterpret_cast<uintptr_t*>(cur + ConnOffsets::Connection::next);
            }
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
        }
        return result;
    }

    static WalkResult walk_connections_fast(uintptr_t head) {
        WalkResult result = {};
        result.count = 0;
        uintptr_t regionBase = 0;
        uintptr_t regionEnd = 0;
        __try {
            uintptr_t cur = head;
            while (cur && result.count < 256) {
                if (cur < regionBase || cur + ConnOffsets::Connection::next + sizeof(uintptr_t) > regionEnd) {
                    MEMORY_BASIC_INFORMATION mbi{};
                    if (!VirtualQuery(reinterpret_cast<void*>(cur), &mbi, sizeof(mbi)) ||
                        mbi.State != MEM_COMMIT ||
                        (mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD)))
                        break;
                    regionBase = reinterpret_cast<uintptr_t>(mbi.BaseAddress);
                    regionEnd = regionBase + mbi.RegionSize;
                    if (cur + ConnOffsets::Connection::next + sizeof(uintptr_t) > regionEnd)
                        break;
                }
                result.connections[result.count++] = cur;
                cur = *reinterpret_cast<uintptr_t*>(cur + ConnOffsets::Connection::next);
            }
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
        }
        return result;
    }

    struct SignalHeadLocation {
        int baseKind = -1;
        uintptr_t offset = 0;
        int attempts = 0;
        bool valid = false;
    };
    inline SignalHeadLocation g_signalHead;

    struct HeadCandidate {
        int kind;
        uintptr_t offset;
    };

    static const int kSignalBaseKinds = 9;
    static const int kMaxCalibrationAttempts = 4;

    static uintptr_t resolve_signal_base(uintptr_t ud, int kind) {
        uintptr_t a = 0, b = 0;
        switch (kind) {
        case 0: signal_safe_read(reinterpret_cast<void*>(ud), &a, sizeof(a)); return a;
        case 1: signal_safe_read(reinterpret_cast<void*>(ud + 0x10), &a, sizeof(a)); return a;
        case 2: signal_safe_read(reinterpret_cast<void*>(ud + 0x18), &a, sizeof(a)); return a;
        case 3: signal_safe_read(reinterpret_cast<void*>(ud + 0x08), &a, sizeof(a)); return a;
        case 4:
            signal_safe_read(reinterpret_cast<void*>(ud + 0x10), &a, sizeof(a));
            if (a) signal_safe_read(reinterpret_cast<void*>(a), &b, sizeof(b));
            return b;
        case 5:
            signal_safe_read(reinterpret_cast<void*>(ud), &a, sizeof(a));
            if (a) signal_safe_read(reinterpret_cast<void*>(a + 0x08), &b, sizeof(b));
            return b;
        case 6:
            signal_safe_read(reinterpret_cast<void*>(ud), &a, sizeof(a));
            if (a) signal_safe_read(reinterpret_cast<void*>(a + 0x10), &b, sizeof(b));
            return b;
        case 7:
            signal_safe_read(reinterpret_cast<void*>(ud + 0x10), &a, sizeof(a));
            if (a) signal_safe_read(reinterpret_cast<void*>(a + 0x08), &b, sizeof(b));
            return b;
        case 8:
            signal_safe_read(reinterpret_cast<void*>(ud + 0x10), &a, sizeof(a));
            if (a) signal_safe_read(reinterpret_cast<void*>(a + 0x10), &b, sizeof(b));
            return b;
        }
        return 0;
    }

    static int collect_head_candidates(uintptr_t ud, uintptr_t sentinelBase, HeadCandidate* out, int maxOut) {
        int count = 0;
        for (int kind = 0; kind < kSignalBaseKinds && count < maxOut; kind++) {
            const uintptr_t base = resolve_signal_base(ud, kind);
            if (!base) continue;
            for (uintptr_t off = 0; off < 0x200 && count < maxOut; off += sizeof(uintptr_t)) {
                uintptr_t value = 0;
                if (!signal_safe_read(reinterpret_cast<void*>(base + off), &value, sizeof(value)))
                    break;
                if (value == sentinelBase)
                    out[count++] = { kind, off };
            }
        }
        return count;
    }

    static void finalize_head_calibration(uintptr_t ud, const HeadCandidate* candidates, int candidateCount,
        uintptr_t prevHead, int walkedCount) {
        int verified = 0;
        int verifiedKind = -1;
        uintptr_t verifiedOffset = 0;
        for (int i = 0; i < candidateCount; i++) {
            const uintptr_t base = resolve_signal_base(ud, candidates[i].kind);
            if (!base) continue;
            uintptr_t slot = 0;
            if (!signal_safe_read(reinterpret_cast<void*>(base + candidates[i].offset), &slot, sizeof(slot)))
                continue;
            if (slot != prevHead)
                continue;
            if (walk_connections_fast(slot).count != walkedCount)
                continue;
            verified++;
            verifiedKind = candidates[i].kind;
            verifiedOffset = candidates[i].offset;
        }
        if (verified == 1) {
            g_signalHead.baseKind = verifiedKind;
            g_signalHead.offset = verifiedOffset;
            g_signalHead.valid = true;
        }
    }

    int getconnectionsV2(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TUSERDATA);

        const char* typeName = luaL_typename(L, 1);
        if (strcmp(typeName, ENV_OBF("RBXScriptSignal")) != 0)
            luaL_typeerror(L, 1, OBF("RBXScriptSignal"));

        const uint64_t generation = SharedVariables::StateGeneration.load();

        __try
        {
            WalkResult walked = {};
            bool walkedOk = false;

            if (g_signalHead.valid)
            {
                const uintptr_t ud = reinterpret_cast<uintptr_t>(lua_touserdata(L, 1));
                const uintptr_t base = resolve_signal_base(ud, g_signalHead.baseKind);
                uintptr_t head = 0;
                if (base &&
                    signal_safe_read(reinterpret_cast<void*>(base + g_signalHead.offset), &head, sizeof(head)) &&
                    (!head || IsPtrValid(head)))
                {
                    walked = walk_connections_fast(head);
                    walkedOk = true;
                }
            }

            if (!walkedOk)
            {
                lua_getfield(L, 1, ENV_OBF("Connect"));
                lua_pushvalue(L, 1);
                lua_pushcfunction(L, conn_noop, OBF("getconn_stub"));

                if (lua_pcall(L, 2, 1, 0) != 0) {
                    lua_pop(L, 1);
                    lua_newtable(L);
                    __leave;
                }

                const auto sentinelUD = lua_touserdata(L, -1);
                if (!sentinelUD) {
                    lua_pop(L, 1);
                    PushTrackedConnections(L, 1);
                    __leave;
                }

                std::uintptr_t sentinelBase = 0;
                signal_safe_read(sentinelUD, &sentinelBase, sizeof(sentinelBase));
                if (!sentinelBase || !IsPtrValid(sentinelBase)) {
                    lua_getfield(L, -1, ENV_OBF("Disconnect"));
                    lua_insert(L, -2);
                    lua_pcall(L, 1, 0, 0);
                    PushTrackedConnections(L, 1);
                    __leave;
                }

                walked = walk_connections_safe(sentinelBase);

                const bool canCalibrate = !g_signalHead.valid && g_signalHead.attempts < kMaxCalibrationAttempts;
                uintptr_t prevHead = 0;
                HeadCandidate candidates[16];
                int candidateCount = 0;

                if (canCalibrate) {
                    g_signalHead.attempts++;
                    signal_safe_read(reinterpret_cast<void*>(sentinelBase + ConnOffsets::Connection::next), &prevHead, sizeof(prevHead));
                    candidateCount = collect_head_candidates(
                        reinterpret_cast<uintptr_t>(lua_touserdata(L, 1)), sentinelBase, candidates, 16);
                }

                lua_getfield(L, -1, "Disconnect");
                lua_insert(L, -2);
                lua_pcall(L, 1, 0, 0);

                if (canCalibrate && candidateCount > 0) {
                    finalize_head_calibration(
                        reinterpret_cast<uintptr_t>(lua_touserdata(L, 1)), candidates, candidateCount,
                        prevHead, walked.count);
                }
            }

            lua_createtable(L, walked.count, 0);
            int count = 1;

            const bool firedEmpty = g_fired_connections.empty();
            for (int i = 0; i < walked.count; i++) {
                const uintptr_t signal = walked.connections[i];
                if (!firedEmpty && g_fired_connections.count(signal)) continue;

                bool pushed = false;
                const auto cached = g_connection_cache.find(signal);
                if (cached != g_connection_cache.end()) {
                    if (cached->second.generation == generation && cached->second.ref > 0) {
                        lua_getref(L, cached->second.ref);
                        if (lua_istable(L, -1)) {
                            pushed = true;
                        }
                        else {
                            lua_pop(L, 1);
                            lua_unref(L, cached->second.ref);
                            g_connection_cache.erase(cached);
                        }
                    }
                    else {
                        g_connection_cache.erase(cached);
                    }
                }

                if (!pushed) {
                    if (!push_connection_mt_safe(L, signal))
                        continue;
                    const int ref = lua_ref(L, -1);
                    g_connection_cache[signal] = { ref, generation };
                }

                const auto tracked = TrackedConnectionsByConn.find(signal);
                if (tracked != TrackedConnectionsByConn.end() && tracked->second.Generation == generation) {
                    lua_pushnumber(L, tracked->second.FunctionRef);
                    lua_rawsetfield(L, -2, ENV_OBF("_TFR"));
                    lua_pushnumber(L, tracked->second.ThreadRef);
                    lua_rawsetfield(L, -2, ENV_OBF("_TTR"));
                }

                lua_rawseti(L, -2, count++);
            }

            if (count == 1) {
                lua_pop(L, 1);
                PushTrackedConnections(L, 1);
            }
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            lua_settop(L, lua_gettop(L) - (lua_gettop(L) > 1 ? 1 : 0));
            lua_newtable(L);
            return 1;
        }

        return 1;
    }

















    int firesignal(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TUSERDATA);
        if (strcmp(luaL_typename(L, 1), ENV_OBF("RBXScriptSignal")) != 0)
            luaL_typeerror(L, 1, OBF("RBXScriptSignal"));

        const int argCount = lua_gettop(L);

        getconnectionsV2(L);
        const int conns_idx = lua_gettop(L);

        if (!lua_istable(L, conns_idx)) {
            lua_pop(L, 1);
            return 0;
        }

        int fired = 0;
        lua_pushnil(L);
        while (lua_next(L, conns_idx)) {
            lua_getfield(L, -1, ENV_OBF("Function"));
            bool hasFunction = !lua_isnil(L, -1) && lua_isfunction(L, -1);
            lua_pop(L, 1);

            if (hasFunction) {
                lua_getfield(L, -1, ENV_OBF("Fire"));
                if (lua_isfunction(L, -1)) {
                    lua_pushvalue(L, -2);
                    for (int i = 2; i <= argCount; i++)
                        lua_pushvalue(L, i);
                    lua_pcall(L, argCount, 0, 0);
                    fired++;
                }
                else {
                    lua_pop(L, 1);
                }
            }
            lua_pop(L, 1);
        }

        lua_pop(L, 1);
        return 0;
    }

    int getconnection(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TUSERDATA);
        const int index = luaL_checkinteger(L, 2);
        if (index < 1)
            luaL_argerror(L, 2, OBF("index must be greater than zero"));

        getconnectionsV2(L);
        lua_rawgeti(L, -1, index);
        lua_remove(L, -2);
        return 1;
    }

    inline int setproximitypromptduration(lua_State* L)
    {
        if (!lua_isuserdata(L, 1) || !lua_isnumber(L, 2))
            return 0;

        lua_getfield(L, 1, ENV_OBF("ClassName"));
        const char* cn = lua_isstring(L, -1) ? lua_tostring(L, -1) : nullptr;
        lua_pop(L, 1);

        if (!cn || strcmp(cn, ENV_OBF("ProximityPrompt")) != 0)
            return 0;

        double duration = lua_tonumber(L, 2);
        lua_pushnumber(L, duration);
        lua_setfield(L, 1, ENV_OBF("HoldDuration"));

        return 0;
    }

    inline int getproximitypromptduration(lua_State* L)
    {
        if (!lua_isuserdata(L, 1)) {
            lua_pushnumber(L, 0);
            return 1;
        }

        lua_getfield(L, 1, ENV_OBF("ClassName"));
        const char* cn = lua_isstring(L, -1) ? lua_tostring(L, -1) : nullptr;
        lua_pop(L, 1);

        if (!cn || strcmp(cn, ENV_OBF("ProximityPrompt")) != 0) {
            lua_pushnumber(L, 0);
            return 1;
        }

        lua_getfield(L, 1, ENV_OBF("HoldDuration"));
        if (!lua_isnumber(L, -1)) {
            lua_pop(L, 1);
            lua_pushnumber(L, 0);
            return 1;
        }

        return 1;
    }

    namespace Roadblocks
    {
        struct YieldState
        {
            uintptr_t State;
            uintptr_t TimeUsed;
            uintptr_t Useless;
        };

        struct YieldingLuaThread
        {
            char Pad0[0x28];
            lua_State* L;
        };

        enum class GameLoadedState : int32_t
        {
            Uninitialized = 0,
            Loading = 15,
            Loaded = 31,
        };

        enum MessageType {
            Output = 0,
            Info = 1,
            Warning = 2,
            Error = 3
        };

        struct TypeHolder
        {
            void(*construct)(const char*, char*);
            void(*moveConstruct)(char*, char*);
            void(*destruct)(char*);
        };

        struct RobloxType
        {
            uintptr_t* virtualTable;
            std::string* name;
            uintptr_t paddingZero[4];
            int typeIdentifier;
            uintptr_t paddingOne[2];
        };

        struct Variant
        {
            struct Storage
            {
                const TypeHolder* holder;
                const char data[64];
            };

            const RobloxType* type;
            Storage value;
        };

        enum class EventTargetInclusion : int32_t
        {
            OnlyTarget = 0,
            ExcludeTarget = 1
        };

        struct SystemAddress
        {
            struct PeerIdentifier
            {
                unsigned int peerIdentifier;
            };

            PeerIdentifier remoteIdentifier;
        };

        struct RemoteEventInvocationTargetOptions
        {
            const SystemAddress* target;
            EventTargetInclusion isExcludeTarget;
        };
    }

    inline bool IsPointerValid(const void* ptr, size_t size = sizeof(uintptr_t))
    {
        if (!ptr) return false;
        MEMORY_BASIC_INFORMATION buffer{};
        SIZE_T read = VirtualQuery(ptr, &buffer, sizeof(buffer));
        if (read != sizeof(buffer)) return false;
        if (buffer.State != MEM_COMMIT) return false;
        if ((buffer.Protect & (PAGE_GUARD | PAGE_NOACCESS)) != 0) return false;
        const DWORD valid_prot = PAGE_READONLY | PAGE_READWRITE | PAGE_WRITECOPY |
            PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY;
        if ((buffer.Protect & valid_prot) == 0) return false;
        const uintptr_t region_start = reinterpret_cast<uintptr_t>(buffer.BaseAddress);
        const uintptr_t region_end = region_start + buffer.RegionSize;
        const uintptr_t ptr_value = reinterpret_cast<uintptr_t>(ptr);
        return ptr_value >= region_start && ptr_value + size <= region_end;
    }

    inline bool IsPointerValid(uintptr_t address, size_t size = sizeof(uintptr_t))
    {
        return IsPointerValid(reinterpret_cast<const void*>(address), size);
    }

    int replicatesignal(lua_State* luaState)
    {
        luaL_checktype(luaState, 1, LUA_TUSERDATA);

        if (strcmp(luaL_typename(luaState, 1), ENV_OBF("RBXScriptSignal")) != 0)
            luaL_typeerror(luaState, 1, OBF("RBXScriptSignal"));

        const uintptr_t eventInstance = *static_cast<uintptr_t*>(lua_touserdata(luaState, 1));
        const uintptr_t descriptor = *reinterpret_cast<uintptr_t*>(eventInstance);
        const uintptr_t signature = *reinterpret_cast<uintptr_t*>(descriptor + 0x48);

        std::vector<Roadblocks::RobloxType*> parameterTypes;

        for (uintptr_t current = signature + 0x8; current; current += 0x70)
        {
            if (!IsPointerValid(reinterpret_cast<uintptr_t*>(current)))
                break;

            uintptr_t typePtr = *reinterpret_cast<uintptr_t*>(current);

            if (!typePtr || !IsPointerValid(reinterpret_cast<uintptr_t*>(typePtr)))
                break;

            parameterTypes.push_back(reinterpret_cast<Roadblocks::RobloxType*>(typePtr));
        }

        if (lua_gettop(luaState) > static_cast<int>(parameterTypes.size() + 1))
            lua_settop(luaState, static_cast<int>(parameterTypes.size() + 1));

        std::vector<Roadblocks::Variant> argumentValues;
        argumentValues.reserve(parameterTypes.size());

        int currentArg = 2;

        for (const auto* engineType : parameterTypes)
        {
            Roadblocks::Variant value{};
            Roblox::CastArgs(luaState, currentArg, &value, true, 0);

            if (!value.type || value.type->typeIdentifier != engineType->typeIdentifier)
            {
                switch (engineType->typeIdentifier)
                {
                case 2:
                    value.type = engineType;
                    *reinterpret_cast<int32_t*>(const_cast<char*>(value.value.data)) = static_cast<int32_t>(lua_tonumber(luaState, currentArg));
                    break;
                case 3:
                    value.type = engineType;
                    *reinterpret_cast<int64_t*>(const_cast<char*>(value.value.data)) = llround(lua_tonumber(luaState, currentArg));
                    break;
                case 4:
                    value.type = engineType;
                    *reinterpret_cast<float*>(const_cast<char*>(value.value.data)) = static_cast<float>(lua_tonumber(luaState, currentArg));
                    break;
                default:
                    break;
                }
            }

            argumentValues.push_back(value);
            ++currentArg;
        }

        Roadblocks::RemoteEventInvocationTargetOptions options{};
        options.target = nullptr;
        options.isExcludeTarget = Roadblocks::EventTargetInclusion::OnlyTarget;

        const uintptr_t owningInstance = *reinterpret_cast<uintptr_t*>(eventInstance + 0x18);
        const uintptr_t owningVTable = *reinterpret_cast<uintptr_t*>(owningInstance);

        const auto raiseEventInvocation = *reinterpret_cast<void(**)(
            uintptr_t*,
            uintptr_t*,
            std::vector<Roadblocks::Variant>*,
            Roadblocks::RemoteEventInvocationTargetOptions*
            )>(owningVTable + 0x18);

        raiseEventInvocation(
            reinterpret_cast<uintptr_t*>(owningInstance),
            reinterpret_cast<uintptr_t*>(descriptor),
            &argumentValues,
            &options
        );

        return 0;
    }

    int firetouchinterest(lua_State* LS) {
        luaL_checktype(LS, 1, LUA_TUSERDATA);
        luaL_checktype(LS, 2, LUA_TUSERDATA);

        int Toggle = (int)lua_tonumber(LS, 3);

        uintptr_t BasePart = *reinterpret_cast<uintptr_t*>(lua_touserdata(LS, 1));
        if (!BasePart)
            luaL_argerror(LS, 1, OBF("Invalid basepart"));

        uintptr_t BasePartTouch = *reinterpret_cast<uintptr_t*>(lua_touserdata(LS, 2));
        if (!BasePartTouch)
            luaL_argerror(LS, 2, OBF("Invalid basepart"));

        uintptr_t Touch1 = *reinterpret_cast<uintptr_t*>(BasePart + 0x128);
        if (!Touch1)
            luaL_argerror(LS, 1, OBF("Error getting primitive touch"));

        uintptr_t Touch2 = *reinterpret_cast<uintptr_t*>(BasePartTouch + 0x128);
        if (!Touch2)
            luaL_argerror(LS, 2, OBF("Error getting primitive touch"));

        uintptr_t Overlap = *reinterpret_cast<uintptr_t*>(Touch1 + 0x1f0);
        if (!Overlap)
            luaL_argerror(LS, 1, OBF("Error getting overlap"));

        Roblox::FireTouchInterest(Overlap, Touch1, Touch2, Toggle, true);
        return 0;
    }


    int getsignalwhitelist(lua_State* L)
    {
        lua_newtable(L);
        int idx = 1;

        const char* signals[][2] = {
            {ENV_OBF("Changed"), ENV_OBF("BasePart")},
            {ENV_OBF("Touched"), ENV_OBF("BasePart")},
            {ENV_OBF("TouchEnded"), ENV_OBF("BasePart")},
            {ENV_OBF("ChildAdded"), ENV_OBF("Instance")},
            {ENV_OBF("ChildRemoved"), ENV_OBF("Instance")},
            {ENV_OBF("DescendantAdded"), ENV_OBF("Instance")},
            {ENV_OBF("DescendantRemoving"), ENV_OBF("Instance")},
            {ENV_OBF("AncestryChanged"), ENV_OBF("Instance")},
            {ENV_OBF("PropertyChanged"), ENV_OBF("Instance")},
            {ENV_OBF("GetPropertyChangedSignal"), ENV_OBF("Instance")},
            {ENV_OBF("AttributeChanged"), ENV_OBF("Instance")},
            {ENV_OBF("AttributeChanged"), ENV_OBF("Instance")},
            {ENV_OBF("InputBegan"), ENV_OBF("UserInputService")},
            {ENV_OBF("InputEnded"), ENV_OBF("UserInputService")},
            {ENV_OBF("InputChanged"), ENV_OBF("UserInputService")},
            {ENV_OBF("RenderStepped"), ENV_OBF("RunService")},
            {ENV_OBF("Heartbeat"), ENV_OBF("RunService")},
            {ENV_OBF("Stepped"), ENV_OBF("RunService")},
            {ENV_OBF("Button1Down"), ENV_OBF("Mouse")},
            {ENV_OBF("Button1Up"), ENV_OBF("Mouse")},
            {ENV_OBF("Button2Down"), ENV_OBF("Mouse")},
            {ENV_OBF("Button2Up"), ENV_OBF("Mouse")},
            {ENV_OBF("Idle"), ENV_OBF("Mouse")},
            {ENV_OBF("Move"), ENV_OBF("Mouse")},
            {ENV_OBF("WheelForward"), ENV_OBF("Mouse")},
            {ENV_OBF("WheelBackward"), ENV_OBF("Mouse")},
            {ENV_OBF("CharacterAdded"), ENV_OBF("Players")},
            {ENV_OBF("CharacterRemoving"), ENV_OBF("Players")},
            {ENV_OBF("PlayerAdded"), ENV_OBF("Players")},
            {ENV_OBF("PlayerRemoving"), ENV_OBF("Players")},
            {ENV_OBF("Chatted"), ENV_OBF("Players")},
            {ENV_OBF("MembershipChanged"), ENV_OBF("Players")},
        };

        for (auto& sig : signals) {
            lua_newtable(L);
            lua_pushstring(L, sig[0]);
            lua_setfield(L, -2, ENV_OBF("Event"));
            lua_pushstring(L, sig[1]);
            lua_setfield(L, -2, ENV_OBF("Parent"));
            lua_rawseti(L, -2, idx++);
        }

        return 1;
    }


    int cansignalreplicate(lua_State* L)
    {
        if (!lua_isuserdata(L, 1)) {
            lua_pushboolean(L, false);
            return 1;
        }

        if (strcmp(luaL_typename(L, 1), ENV_OBF("RBXScriptSignal")) != 0) {
            lua_pushboolean(L, false);
            return 1;
        }

        __try {
            uintptr_t userdata = reinterpret_cast<uintptr_t>(lua_touserdata(L, 1));
            uintptr_t eventInstance = 0;
            if (!signal_safe_read(reinterpret_cast<void*>(userdata), &eventInstance, sizeof(eventInstance)) || !eventInstance || !IsPointerValid(eventInstance)) {
                lua_pushboolean(L, false);
                return 1;
            }

            uintptr_t owningInstance = 0;
            if (!signal_safe_read(reinterpret_cast<void*>(eventInstance + 0x18), &owningInstance, sizeof(owningInstance)) || !owningInstance || !IsPointerValid(owningInstance)) {
                lua_pushboolean(L, false);
                return 1;
            }

            Roblox::PushInstance(L, reinterpret_cast<void*>(owningInstance));
            lua_getfield(L, -1, ENV_OBF("ClassName"));
            const char* className = lua_isstring(L, -1) ? lua_tostring(L, -1) : nullptr;
            lua_pop(L, 1);
            lua_pop(L, 1);

            if (!className) {
                lua_pushboolean(L, false);
                return 1;
            }

            bool replicable = (strcmp(className, ENV_OBF("RemoteEvent")) == 0 ||
                strcmp(className, ENV_OBF("RemoteFunction")) == 0 ||
                strcmp(className, ENV_OBF("UnvalidatedRemoteEvent")) == 0);
            lua_pushboolean(L, replicable);
            return 1;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            lua_pushboolean(L, false);
            return 1;
        }
    }

    static const char* GetRobloxTypeName(int typeIdentifier)
    {
        switch (typeIdentifier)
        {
        case 1: return OBF("string");
        case 2: return OBF("bool");
        case 3: return OBF("int");
        case 4: return OBF("float");
        case 5: return OBF("double");
        case 6: return OBF("UDim");
        case 7: return OBF("UDim2");
        case 8: return OBF("BrickColor");
        case 9: return OBF("Color3");
        case 10: return OBF("Vector2");
        case 11: return OBF("Vector3");
        case 12: return OBF("CFrame");
        case 13: return OBF("Ray");
        case 14: return OBF("Enum");
        case 15: return OBF("Axes");
        case 16: return OBF("Faces");
        case 17: return OBF("Instance");
        case 18: return OBF("Dictionary");
        case 19: return OBF("Array");
        case 20: return OBF("NumberSequence");
        case 21: return OBF("NumberSequenceKeypoint");
        case 22: return OBF("ColorSequence");
        case 23: return OBF("ColorSequenceKeypoint");
        case 24: return OBF("NumberRange");
        case 25: return OBF("Rect");
        case 26: return OBF("Region3");
        case 27: return OBF("Region3int16");
        case 28: return OBF("Vector2int16");
        case 29: return OBF("Vector3int16");
        case 30: return OBF("PhysicalProperties");
        case 31: return OBF("DockWidgetPluginGuiInfo");
        case 32: return OBF("NumberSequenceKeypoint");
        case 33: return OBF("rotation");
        case 34: return OBF("PathWaypoint");
        case 35: return OBF("TweenInfo");
        case 36: return OBF("RaycastParams");
        case 37: return OBF("Color3uint8");
        case 38: return OBF("UniqueId");
        case 39: return OBF("Font");
        default: return OBF("Unknown");
        }
    }

    static bool ReadSignalDescriptor(lua_State* L, int index, uintptr_t& outEventInstance, uintptr_t& outDescriptor, uintptr_t& outSignature)
    {
        if (!lua_isuserdata(L, index))
            return false;

        uintptr_t userdata = reinterpret_cast<uintptr_t>(lua_touserdata(L, index));

        uintptr_t eventInstance = 0;
        if (!signal_safe_read(reinterpret_cast<void*>(userdata), &eventInstance, sizeof(eventInstance)))
            return false;
        if (!eventInstance || !IsPointerValid(eventInstance))
            return false;

        uintptr_t descriptor = 0;
        if (!signal_safe_read(reinterpret_cast<void*>(eventInstance), &descriptor, sizeof(descriptor)))
            return false;
        if (!descriptor || !IsPointerValid(descriptor))
            return false;

        uintptr_t signature = 0;
        if (!signal_safe_read(reinterpret_cast<void*>(descriptor + 0x48), &signature, sizeof(signature)))
            return false;
        if (!signature || !IsPointerValid(signature))
            return false;

        outEventInstance = eventInstance;
        outDescriptor = descriptor;
        outSignature = signature;
        return true;
    }
    
    int getsignalargumentsinfo(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TUSERDATA);

        if (strcmp(luaL_typename(L, 1), ENV_OBF("RBXScriptSignal")) != 0)
            luaL_typeerror(L, 1, (ENV_OBF("RBXScriptSignal")));

        uintptr_t eventInstance, descriptor, signature;
        if (!ReadSignalDescriptor(L, 1, eventInstance, descriptor, signature)) {
            lua_newtable(L);
            return 1;
        }

        lua_newtable(L);
        int idx = 1;

        for (uintptr_t current = signature + 0x8; current; current += 0x70)
        {
            if (!IsPointerValid(reinterpret_cast<uintptr_t*>(current)))
                break;

            uintptr_t typePtr = 0;
            if (!signal_safe_read(reinterpret_cast<void*>(current), &typePtr, sizeof(typePtr)))
                break;
            if (!typePtr || !IsPointerValid(typePtr))
                break;

            int typeIdentifier = 0;
            signal_safe_read(reinterpret_cast<void*>(typePtr + 0x30), &typeIdentifier, sizeof(typeIdentifier));

            uintptr_t namePtr = 0;
            signal_safe_read(reinterpret_cast<void*>(typePtr + 0x08), &namePtr, sizeof(namePtr));

            char nameBuf[256] = { 0 };
            if (namePtr && IsPointerValid(namePtr)) {
                signal_safe_read(reinterpret_cast<void*>(namePtr), nameBuf, sizeof(nameBuf) - 1);
            }

            lua_newtable(L);
            lua_pushstring(L, nameBuf[0] ? nameBuf : ENV_OBF("Unknown"));
            lua_setfield(L, -2, ENV_OBF("Name"));
            lua_pushstring(L, GetRobloxTypeName(typeIdentifier));
            lua_setfield(L, -2, ENV_OBF("Type"));
            lua_rawseti(L, -2, idx++);
        }

        return 1;
    }






    int getsignalarguments(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TUSERDATA);

        if (strcmp(luaL_typename(L, 1), ENV_OBF("RBXScriptSignal")) != 0)
            luaL_typeerror(L, 1, (ENV_OBF("RBXScriptSignal")));

        uintptr_t eventInstance, descriptor, signature;
        if (!ReadSignalDescriptor(L, 1, eventInstance, descriptor, signature)) {
            lua_newtable(L);
            return 1;
        }

        lua_newtable(L);
        int idx = 1;

        for (uintptr_t current = signature + 0x8; current; current += 0x70)
        {
            if (!IsPointerValid(reinterpret_cast<uintptr_t*>(current)))
                break;

            uintptr_t typePtr = 0;
            if (!signal_safe_read(reinterpret_cast<void*>(current), &typePtr, sizeof(typePtr)))
                break;
            if (!typePtr || !IsPointerValid(typePtr))
                break;

            uintptr_t namePtr = 0;
            if (!signal_safe_read(reinterpret_cast<void*>(typePtr + 0x08), &namePtr, sizeof(namePtr)))
                break;

            if (namePtr && IsPointerValid(namePtr)) {
                char nameBuf[256] = { 0 };
                if (signal_safe_read(reinterpret_cast<void*>(namePtr), nameBuf, sizeof(nameBuf) - 1)) {
                    lua_pushstring(L, nameBuf);
                    lua_rawseti(L, -2, idx++);
                }
            }
        }

        return 1;
    }








    inline void RegisterLibrary(lua_State* L)
    {
        if (!L) return;

        luaL_newmetatable(L, ENV_OBF("connection_signal_object"));
        lua_pushcfunction(L, connection_index, OBF("connection_index"));
        lua_setfield(L, -2, ENV_OBF("__index"));
        lua_pushcfunction(L, connection_newindex, OBF("connection_newindex"));
        lua_setfield(L, -2, ENV_OBF("__newindex"));
        lua_pushstring(L, OBF("Connection"));
        lua_setfield(L, -2, ENV_OBF("__type"));
        lua_pop(L, 1);

        Utils::AddFunction(L, ENV_OBF("fireproximityprompt"), fireproximityprompt);
        Utils::AddFunction(L, ENV_OBF("fireclickdetector"), fireclickdetector);
        Utils::AddFunction(L, ENV_OBF("firetouchinterest"), firetouchinterest);
        Utils::AddFunction(L, ENV_OBF("getconnections"), getconnectionsV2);
        Utils::AddFunction(L, ENV_OBF("firesignal"), firesignal);
        Utils::AddFunction(L, ENV_OBF("replicatesignal"), replicatesignal);
        Utils::AddFunction(L, ENV_OBF("getsignalwhitelist"), getsignalwhitelist);
        Utils::AddFunction(L, ENV_OBF("cansignalreplicate"), cansignalreplicate);
        Utils::AddFunction(L, ENV_OBF("getsignalargumentsinfo"), getsignalargumentsinfo);
        Utils::AddFunction(L, ENV_OBF("getsignalarguments"), getsignalarguments);
    }

    inline void ResetLibraryState()
    {
        TrackedConnectionsBySignal.clear();
        TrackedConnectionsByConn.clear();
        g_connection_cache.clear();
        g_fired_connections.clear();
    }
}
