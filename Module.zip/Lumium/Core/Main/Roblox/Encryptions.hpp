#pragma once

#include <Roblox/EncryptionsHelper.hpp>

#define PROTO_LINEINFO_ENC VMValue3 
#define PROTO_ABSLINEINFO_ENC VMValue3 
#define PROTO_LOCVARS_ENC VMValue1
#define PROTO_UPVALUES_ENC VMValue2
#define PROTO_SOURCE_ENC VMValue4 

#define PROTO_DEBUGINSN_ENC VMValue2 
#define PROTO_DEBUGNAME_ENC VMValue1 
#define PROTO_TYPEINFO_ENC VMValue3
#define PROTO_USERDATA_ENC VMValue3 

#define LSTATE_STACKSIZE_ENC VMValue4 

#define CLOSURE_CONT_ENC VMValue2 
#define CLOSURE_DEBUGNAME_ENC VMValue1 

#define UDATA_META_ENC VMValue2 

#define TSTRING_HASH_ENC VMValue2