#pragma once

#include <cstddef>
#include <cstdint>
#include <cstring>

namespace security
{
    template <std::size_t N, uint32_t Key>
    class XorString
    {
    private:
        std::uint8_t data_[N];

        static constexpr std::uint8_t xor_byte(std::uint8_t byte, std::size_t index)
        {
            return byte ^ static_cast<std::uint8_t>((Key >> ((index & 3) << 3)) & 0xFF);
        }

    public:
        constexpr XorString(const char (&str)[N]) : data_{}
        {
            for (std::size_t i = 0; i < N; ++i)
            {
                data_[i] = xor_byte(static_cast<std::uint8_t>(str[i]), i);
            }
        }

        const char* decrypt() const
        {
            static char buf[N];
            for (std::size_t i = 0; i < N; ++i)
            {
                buf[i] = static_cast<char>(xor_byte(data_[i], i));
            }
            return buf;
        }
    };
}

#define OBF_KEY(line) ((static_cast<uint32_t>(line) * 2654435761u) ^ 0xDEADBEEFu)
#define OBF(str) (security::XorString<sizeof(str), OBF_KEY(__COUNTER__)>(str).decrypt())
#define ENV_OBF(str) (security::XorString<sizeof(str), OBF_KEY(__COUNTER__ ^ 0x5A5AA5A5)>(str).decrypt())
