#pragma once
#include <thread>
#include <Utils.hpp>
#include <Globals.hpp>
#include <Exploit/TaskScheduler/TaskScheduler.hpp>

namespace
{
    bool g_SetupCrashed;

    inline bool TrySetupExploit(uintptr_t DataModel)
    {
        g_SetupCrashed = false;
        __try
        {
            return TaskScheduler::SetupExploit(DataModel);
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            g_SetupCrashed = true;
            return false;
        }
    }
}

namespace TpHandler
{
    inline void Initialize()
    {
        std::thread([]()
        {
            while (true)
            {
                uintptr_t DataModel = TaskScheduler::GetDataModel();
                if (!DataModel)
                {
                    std::this_thread::sleep_for(std::chrono::milliseconds(1000));
                    continue;
                }

                if (SharedVariables::LastDataModel != DataModel)
                {
                    if (!Utils::IsInGame(DataModel))
                    {
                        SharedVariables::LastDataModel = DataModel;
                        std::this_thread::sleep_for(std::chrono::milliseconds(1000));
                        continue;
                    }

                    if (!TrySetupExploit(DataModel))
                    {
                        if (g_SetupCrashed)
                            SharedVariables::LastDataModel = DataModel;
                        continue;
                    }

                    if (SharedVariables::LastDataModel)
                    {
                        std::vector<std::string> TeleportScripts;
                        {
                            std::lock_guard<std::mutex> lock(SharedVariables::TeleportQueueMutex);
                            TeleportScripts.swap(SharedVariables::TeleportQueue);
                        }
                        for (std::string& Script : TeleportScripts)
                            TaskScheduler::RequestExecution(std::move(Script));
                    }
                    SharedVariables::LastDataModel = DataModel;
                }

                std::this_thread::sleep_for(std::chrono::milliseconds(1000));
            }
        }).detach();
    }
}

template <typename T>
__forceinline static bool IsPtrValid(T value)
{
    const void* ptr = reinterpret_cast<const void*>(value);
    MEMORY_BASIC_INFORMATION buffer{};
    SIZE_T read = VirtualQuery(ptr, &buffer, sizeof(buffer));
    if (read == 0 || read != sizeof(buffer))
        return false;
    if (buffer.RegionSize < sizeof(T))
        return false;
    if ((buffer.State & MEM_FREE) == MEM_FREE)
        return false;
    const DWORD valid_prot = PAGE_READONLY | PAGE_READWRITE | PAGE_WRITECOPY |
        PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY;
    if ((buffer.Protect & valid_prot) != 0)
        return true;
    if ((buffer.Protect & (PAGE_GUARD | PAGE_NOACCESS)) != 0)
        return false;
    return true;
}

uintptr_t GetDataModel()
{
    std::uintptr_t FakeDataModel = *reinterpret_cast<std::uintptr_t*>(Offsets::DataModel::FakeDataModelPointer);
    std::uintptr_t RealDataModel = *reinterpret_cast<std::uintptr_t*>(FakeDataModel + Offsets::DataModel::FakeDataModelToDataModel);


    return RealDataModel;
}


uintptr_t GetPlaceID(uintptr_t DataModel)
{
    std::uintptr_t* PlaceIdPtr = reinterpret_cast<std::uintptr_t*>(DataModel + 0x198);

    if (!PlaceIdPtr || !IsPtrValid(PlaceIdPtr)) return 0;

    return *PlaceIdPtr;
}