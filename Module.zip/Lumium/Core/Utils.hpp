#pragma once

#include <lstate.h>
#include <lualib.h>
#include <vector>
#include <string>
#include <Main/Environment/Environment.hpp>
#include <Globals.hpp>
#include <zstd/xxhash.h>
#include <zstd/zstd.h>

namespace Utils
{
	inline void TrackExecutorClosure(Closure* ClosureObject)
	{
		if (!ClosureObject)
			return;

		SharedVariables::ExecutorClosures.insert(ClosureObject);

		for (Closure* Existing : Environment::function_array)
		{
			if (Existing == ClosureObject)
				return;
		}

		Environment::function_array.push_back(ClosureObject);
	}

	inline void AddFunction(lua_State* L, const char* Name, lua_CFunction Function)
	{
		lua_pushcclosure(L, Function, nullptr, NULL);
		TrackExecutorClosure(clvalue(index2addr(L, -1)));
		lua_setglobal(L, Name);
	}

	inline void AddTableFunction(lua_State* L, const char* Name, lua_CFunction Function)
	{
		lua_pushcclosure(L, Function, nullptr, NULL);
		TrackExecutorClosure(clvalue(index2addr(L, -1)));
		lua_setfield(L, -2, Name);
	}


	inline void RegisterAliases(lua_State* L, lua_CFunction Function, const std::vector<const char*>& Aliases)
	{
		for (const char* alias : Aliases)
		{
			lua_pushcclosure(L, Function, nullptr, 0);
			TrackExecutorClosure(clvalue(index2addr(L, -1)));
			lua_setglobal(L, alias);
		}
	}

	inline bool IsInGame(uintptr_t DataModel)
	{
		if (!DataModel)
			return false;

		__try
		{
			return *reinterpret_cast<const bool*>(DataModel + Offsets::DataModel::GameLoaded);
		}
		__except (EXCEPTION_EXECUTE_HANDLER)
		{
			return false;
		}
	}

	inline std::string decompress_bytecode(const std::string& source)
	{
		const char* bytecode_magic = OBF("RSB1");

		std::string input = source;

		std::uint8_t hash_bytes[4];
		std::memcpy(hash_bytes, &input[0], 4);

		for (auto i = 0u; i < 4; ++i) {
			hash_bytes[i] ^= bytecode_magic[i];
			hash_bytes[i] -= i * 41;
		}

		for (size_t i = 0; i < input.size(); ++i)
			input[i] ^= hash_bytes[i % 4] + i * 41;

		XXH32(&input[0], input.size(), 42);

		std::uint32_t data_size;
		std::memcpy(&data_size, &input[4], 4);

		std::vector<std::uint8_t> data(data_size);
		const size_t result = ZSTD_decompress(&data[0], data_size, &input[8], input.size() - 8);
		if (ZSTD_isError(result))
			return {};

		return std::string(reinterpret_cast<char*>(&data[0]), result);
	}
}
