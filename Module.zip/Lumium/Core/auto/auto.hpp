#pragma once
#include <string>
#include <Exploit/TaskScheduler/TaskScheduler.hpp>
#include <Main/Security/xorstr.hpp>

namespace Auto
{
    inline void RunDecompile()
    {
        TaskScheduler::RequestExecution(
            std::string(R"(loadstring(game:HttpGet('https://lumium-private.vercel.app/decompile.lua'))())")
        );
    }

    inline void RunEnv()
    {
        TaskScheduler::RequestExecution(
            std::string(OBF(R"(loadstring(HttpGet('https://lumium-private.vercel.app/environment.lua'))())"))
        );
    }

    inline void RunDrawing()
    {
        TaskScheduler::RequestExecution(
            std::string(OBF(R"(loadstring(HttpGet('https://lumium-private.vercel.app/drawing.lua'))())"))
        );
    }

    inline void RunFiltergc()
    {
        TaskScheduler::RequestExecution(
            std::string(R"(getgenv().filtergc = newcclosure(function(...)
local args = {...}
local type_or_callback = args[1]
local function valuesEqual(a, b)
if a == b then return true end
return typeof(a) == "number" and typeof(b) == "number" and a ~= a and b ~= b
end
local function safeFind(t, target)
for i, v in t do
if valuesEqual(v, target) then return i end
end
return nil
end
if typeof(type_or_callback) == "function" then
local callback = type_or_callback
local matches = {}
for i, v in getgc(true) do
local success, passed = pcall(callback, v)
if success and passed then table.insert(matches, v) end
end
return matches
end
local filterType = type_or_callback
local filterOptions = args[2] or {}
local returnOne = args[3]
local matches = {}
if filterType == "table" then
for i, v in getgc(true) do
if typeof(v) ~= "table" then continue end
local passed = true
if filterOptions.Keys and typeof(filterOptions.Keys) == "table" and passed then
for _, key in filterOptions.Keys do
if rawget(v, key) == nil then passed = false break end
end
end
if filterOptions.Values and typeof(filterOptions.Values) == "table" and passed then
local tableVals = {}
for _, value in next, v do table.insert(tableVals, value) end
for _, value in filterOptions.Values do
if not safeFind(tableVals, value) then passed = false break end
end
end
if filterOptions.KeyValuePairs and typeof(filterOptions.KeyValuePairs) == "table" and passed then
for key, value in filterOptions.KeyValuePairs do
if not valuesEqual(rawget(v, key), value) then passed = false break end
end
end
if filterOptions.Metatable and passed then
local success, mt = pcall(getrawmetatable, v)
if success then passed = filterOptions.Metatable == mt else passed = false end
end
if passed then
if returnOne then return v else table.insert(matches, v) end
end
end
elseif filterType == "function" then
if filterOptions.IgnoreExecutor == nil then filterOptions.IgnoreExecutor = true end
for i, v in getgc(false) do
if typeof(v) ~= "function" then continue end
local passed = true
local isCClosure = pcall(function() return iscclosure(v) end) and iscclosure(v) or false
if filterOptions.Name and passed then
local success, funcName = pcall(function() return debug.info(v, "n") end)
if success and funcName then passed = funcName == filterOptions.Name
else local s2, fs = pcall(function() return tostring(v) end)
if s2 and fs then passed = string.find(fs, filterOptions.Name) ~= nil else passed = false end
end
end
if filterOptions.IgnoreExecutor == true and passed then
local success, isExec = pcall(function() return isexecutorclosure(v) end)
if success then passed = not isExec else passed = true end
end
if isCClosure and (filterOptions.Hash or filterOptions.Constants or filterOptions.Upvalues) then passed = false end
if not isCClosure and passed then
if filterOptions.Hash and passed then
local success, hash = pcall(function() return getfunctionhash and getfunctionhash(v) or nil end)
if success and hash then passed = hash == filterOptions.Hash else passed = false end
end
if filterOptions.Constants and typeof(filterOptions.Constants) == "table" and passed then
local success, constants = pcall(function() return debug.getconstants and debug.getconstants(v) or {} end)
if success and constants then
local funcConsts = {}
for idx, constant in constants do if constant ~= nil then table.insert(funcConsts, constant) end end
for _, constant in filterOptions.Constants do
if not safeFind(funcConsts, constant) then passed = false break end
end
else passed = false end
end
if filterOptions.Upvalues and typeof(filterOptions.Upvalues) == "table" and passed then
local success, upvalues = pcall(function() return debug.getupvalues and debug.getupvalues(v) or {} end)
if success and upvalues then
local funcUpvals = {}
for idx, upval in upvalues do if upval ~= nil then table.insert(funcUpvals, upval) end end
for _, upval in filterOptions.Upvalues do
if not safeFind(funcUpvals, upval) then passed = false break end
end
else passed = false end
end
end
if passed then
if returnOne then return v else table.insert(matches, v) end
end
end
else
error("Expected type 'function' or 'table', got '" .. tostring(filterType) .. "'")
end
return returnOne and nil or matches
end, 'filtergc'))")
);
    }

    inline void RunRconsole()
    {
        TaskScheduler::RequestExecution(
            std::string(R"(local function noop() end
local function noop_str() return "" end
getgenv().rconsolecreate = noop
getgenv().consolecreate = noop
getgenv().rconsoledestroy = noop
getgenv().consoledestroy = noop
getgenv().rconsoleclear = noop
getgenv().consoleclear = noop
getgenv().rconsoleprint = noop
getgenv().consoleprint = noop
getgenv().rconsolesettitle = noop
getgenv().rconsolename = noop
getgenv().consolesettitle = noop
getgenv().rconsoleinput = noop_str
getgenv().consoleinput = noop_str
getgenv().rconsoleinfo = noop
getgenv().rconsoleshow = noop
getgenv().rconsolehide = noop
getgenv().rconsoleerr = noop_str
getgenv().rconsolewarn = noop_str)")
);
    }

    inline void RunSignal()
    {
        TaskScheduler::RequestExecution(
            std::string(R"(local Signal = {}
Signal.__index = Signal
function Signal.new()
local self = setmetatable({}, Signal)
self._connections = {}
return self
end
function Signal:Connect(callback)
local conn = { _callback = callback, _signal = self, _connected = true }
conn.Disconnect = function(c)
c._connected = false
for i, v in ipairs(self._connections) do
if v == c then table.remove(self._connections, i) break end
end
end
table.insert(self._connections, conn)
return conn
end
function Signal:Once(callback)
local conn
conn = self:Connect(function(...) conn:Disconnect() callback(...) end)
return conn
end
function Signal:Fire(...)
for _, conn in ipairs(table.clone(self._connections)) do
if conn._connected then task.spawn(conn._callback, ...) end
end
end
function Signal:Wait()
local thread = coroutine.running()
local conn
conn = self:Connect(function(...) conn:Disconnect() task.spawn(thread, ...) end)
return coroutine.yield()
end
getgenv().Signal = Signal)")
);
    }

    inline void RunLuarmor()
    {
        TaskScheduler::RequestExecution(
            std::string(R"(local pid = game.PlaceId
if pid == 109983668079237 or pid == 96342491571673 then
local s, r = pcall(function()
return game:HttpGet("https://api.luarmor.net/files/v4/loaders/f3e8142cd7f821e91b33a5b99fb9fa66.lua")
end)
if s and type(r) == "string" then
local fn = loadstring(r)
if fn then fn() end
end
end)")
);
    }

    inline void RunConstant()
    {
        TaskScheduler::RequestExecution(
            std::string(R"(local common = game:GetService("CoreGui").RobloxGui.Modules.Common
local commonutil = common.CommonUtil
local constants = commonutil:Clone()
constants.Name = "Constants"
constants.Parent = common)")
);
    }

    inline void Execute()
    {
        RunLuarmor();
        RunDecompile();
        RunEnv();
        RunDrawing();
        RunFiltergc();
        RunRconsole();
        RunSignal();
        RunConstant();
    }
}