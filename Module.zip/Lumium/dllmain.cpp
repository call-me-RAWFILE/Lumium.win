#include <Utils.hpp>
#include <Globals.hpp>
#include <Exploit/Communication/Communication.hpp>
#include <Exploit/TaskScheduler/TaskScheduler.hpp>
#include <Main/TpHandler/TpHandler.hpp>

#include <filesystem>
#include <windows.h>

void MainThread(HMODULE hModule)
{
    
    char appdata[MAX_PATH] = {};
    if (GetEnvironmentVariableA(OBF("LOCALAPPDATA"), appdata, MAX_PATH) && appdata[0] != '\0')
        SharedVariables::workspace_folder = std::filesystem::path(appdata) / OBF("Lumium") / OBF("workspace");
    else
        SharedVariables::workspace_folder = std::filesystem::path(OBF("workspace"));

    {
        std::error_code ec;
        if (!std::filesystem::exists(SharedVariables::workspace_folder, ec))
            std::filesystem::create_directories(SharedVariables::workspace_folder, ec);
    }

    Communication::Initialize();
  

    TpHandler::Initialize();
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved)
{
    if (ul_reason_for_call == DLL_PROCESS_ATTACH)
    {
        DisableThreadLibraryCalls(hModule);
        
        std::thread(MainThread, hModule).detach();
    }

    return TRUE;
}